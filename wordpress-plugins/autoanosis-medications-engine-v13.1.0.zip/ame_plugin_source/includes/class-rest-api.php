<?php
/**
 * AME_REST_API — v13.0.0
 *
 * REST API for Medications Engine.
 * All reads from mm_medications + mm_doses ONLY.
 * mm_adherence is NEVER read.
 *
 * Endpoints:
 *   GET  /wp-json/ame/v1/medications           — list active medications
 *   GET  /wp-json/ame/v1/medications/{id}       — single medication
 *   GET  /wp-json/ame/v1/doses/today            — today's schedule
 *   GET  /wp-json/ame/v1/doses/stats            — adherence stats
 *   GET  /wp-json/ame/v1/ai-context             — unified AI context payload
 *   POST /wp-json/ame/v1/doses/{id}/taken       — mark taken (for mobile/external)
 *   POST /wp-json/ame/v1/doses/{id}/skipped     — mark skipped (for mobile/external)
 *
 * Also registers legacy namespace aliases (amm/v1) for backwards compat.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_REST_API {

    const NAMESPACE_V1 = 'ame/v1';
    const NAMESPACE_LEGACY = 'amm/v1';

    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes() {
        $ns     = self::NAMESPACE_V1;
        $ns_leg = self::NAMESPACE_LEGACY;

        // ── Medications ──────────────────────────────────────────────────────
        register_rest_route( $ns, '/medications', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_medications' ),
            'permission_callback' => array( __CLASS__, 'check_auth' ),
        ) );
        register_rest_route( $ns_leg, '/medications', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_medications' ),
            'permission_callback' => array( __CLASS__, 'check_auth' ),
        ) );

        register_rest_route( $ns, '/medications/(?P<id>\d+)', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_medication' ),
            'permission_callback' => array( __CLASS__, 'check_auth' ),
        ) );

        // ── Doses ────────────────────────────────────────────────────────────
        register_rest_route( $ns, '/doses/today', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_today_doses' ),
            'permission_callback' => array( __CLASS__, 'check_auth' ),
        ) );
        register_rest_route( $ns_leg, '/doses/today', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_today_doses' ),
            'permission_callback' => array( __CLASS__, 'check_auth' ),
        ) );

        register_rest_route( $ns, '/doses/stats', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_stats' ),
            'permission_callback' => array( __CLASS__, 'check_auth' ),
        ) );

        register_rest_route( $ns, '/doses/(?P<id>\d+)/taken', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( __CLASS__, 'mark_taken' ),
            'permission_callback' => array( __CLASS__, 'check_auth' ),
        ) );

        register_rest_route( $ns, '/doses/(?P<id>\d+)/skipped', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( __CLASS__, 'mark_skipped' ),
            'permission_callback' => array( __CLASS__, 'check_auth' ),
        ) );

        // ── AI Context ───────────────────────────────────────────────────────
        register_rest_route( $ns, '/ai-context', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_ai_context' ),
            'permission_callback' => array( __CLASS__, 'check_auth_or_backend' ),
        ) );
        register_rest_route( $ns_leg, '/ai-context', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_ai_context' ),
            'permission_callback' => array( __CLASS__, 'check_auth_or_backend' ),
        ) );

        // Legacy endpoint alias used by old AI backend
        register_rest_route( $ns_leg, '/medications-data', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( __CLASS__, 'get_ai_context' ),
            'permission_callback' => array( __CLASS__, 'check_auth_or_backend' ),
        ) );
    }

    // ─── PERMISSIONS ─────────────────────────────────────────────────────────

    /**
     * Verify an HMAC identity token (same format as autoa_home_snapshot_verify_token).
     * Returns the verified user_id (int > 0) on success, or 0 on failure.
     */
    private static function verify_identity_token( string $token ): int {
        $parts = explode( '.', $token );
        if ( count( $parts ) !== 2 ) {
            return 0;
        }
        [ $payload_b64, $sig_b64 ] = $parts;
        $json = base64_decode( $payload_b64, true );
        if ( $json === false ) {
            return 0;
        }
        $payload = json_decode( $json, true );
        if ( ! is_array( $payload ) ) {
            return 0;
        }
        // Verify expiry
        if ( empty( $payload['exp'] ) || time() > (int) $payload['exp'] ) {
            return 0;
        }
        // Verify issuer
        if ( ( $payload['iss'] ?? '' ) !== 'autoanosis-wordpress' ) {
            return 0;
        }
        // Verify HMAC signature
        $secret = defined( 'AUTOANOSIS_IDENTITY_SECRET' ) ? AUTOANOSIS_IDENTITY_SECRET : '';
        if ( empty( $secret ) ) {
            return 0;
        }
        $expected_sig_raw = hash_hmac( 'sha256', $payload_b64, $secret, true );
        $expected_sig_b64 = base64_encode( $expected_sig_raw );
        if ( ! hash_equals( $expected_sig_b64, $sig_b64 ) ) {
            return 0;
        }
        $uid = (int) ( $payload['uid'] ?? 0 );
        return $uid > 0 ? $uid : 0;
    }

    /**
     * Accepts:
     *   1. Standard WordPress cookie session (is_user_logged_in).
     *   2. X-Identity-Token header (HMAC token issued by /autoa/v1/token).
     *
     * Sets the current user if token auth succeeds so get_current_user_id() works.
     */
    public static function check_auth( $request ) {
        // Path 1 — cookie session (web / same-domain)
        if ( is_user_logged_in() ) {
            return true;
        }
        // Path 2 — X-Identity-Token (mobile app)
        $token = trim( $request->get_header( 'X-Identity-Token' ) ?? '' );
        if ( empty( $token ) ) {
            return new WP_Error( 'rest_forbidden', 'Authentication required.', array( 'status' => 401 ) );
        }
        $user_id = self::verify_identity_token( $token );
        if ( ! $user_id ) {
            return new WP_Error( 'rest_forbidden', 'Invalid or expired identity token.', array( 'status' => 401 ) );
        }
        wp_set_current_user( $user_id );
        return true;
    }

    /**
     * Allow:
     *   1. Logged-in users (cookie session)
     *   2. Mobile app (X-Identity-Token)
     *   3. Backend-to-backend calls (X-AME-Backend-Key)
     */
    public static function check_auth_or_backend( $request ) {
        // Path 1 — cookie session
        if ( is_user_logged_in() ) {
            return true;
        }
        // Path 2 — X-Identity-Token (mobile app)
        $token = trim( $request->get_header( 'X-Identity-Token' ) ?? '' );
        if ( ! empty( $token ) ) {
            $user_id = self::verify_identity_token( $token );
            if ( $user_id ) {
                wp_set_current_user( $user_id );
                return true;
            }
        }
        // Path 3 — backend key
        $key    = $request->get_header( 'X-AME-Backend-Key' );
        $stored = get_option( 'ame_backend_key', '' );
        if ( $key && $stored && hash_equals( $stored, $key ) ) {
            return true;
        }
        return new WP_Error( 'rest_forbidden', 'Authentication required.', array( 'status' => 401 ) );
    }

    // ─── HANDLERS ────────────────────────────────────────────────────────────

    /**
     * GET /medications
     * Returns active medications for the current user.
     * Reads from mm_medications ONLY.
     */
    public static function get_medications( $request ) {
        $user_id = self::resolve_user_id( $request );
        if ( ! $user_id ) {
            return new WP_Error( 'no_user', 'User not found.', array( 'status' => 400 ) );
        }

        $medications = AME_Medications::get_by_patient( $user_id );
        $result      = array();

        foreach ( $medications as $med ) {
            $result[] = self::format_medication( $med );
        }

        return rest_ensure_response( array(
            'success'     => true,
            'count'       => count( $result ),
            'medications' => $result,
        ) );
    }

    /**
     * GET /medications/{id}
     */
    public static function get_medication( $request ) {
        $user_id = self::resolve_user_id( $request );
        $med_id  = intval( $request['id'] );
        $med     = AME_Medications::get( $med_id );

        if ( ! $med || intval( $med->patient_id ) !== $user_id ) {
            return new WP_Error( 'not_found', 'Medication not found.', array( 'status' => 404 ) );
        }

        return rest_ensure_response( array(
            'success'    => true,
            'medication' => self::format_medication( $med ),
        ) );
    }

    /**
     * GET /doses/today
     * Returns today's schedule from mm_doses.
     */
    public static function get_today_doses( $request ) {
        $user_id = self::resolve_user_id( $request );
        if ( ! $user_id ) {
            return new WP_Error( 'no_user', 'User not found.', array( 'status' => 400 ) );
        }

        $doses  = AME_Medications::get_todays_schedule( $user_id );
        $result = array();

        foreach ( $doses as $dose ) {
            $result[] = array(
                'dose_id'              => intval( $dose->id ),
                'medication_id'        => intval( $dose->medication_id ),
                'medication_name'      => $dose->medication_name,
                'dosage'               => $dose->dosage,
                'instructions'         => $dose->instructions,
                'scheduled_local_time' => substr( $dose->scheduled_local_time, 0, 5 ),
                'scheduled_local_date' => $dose->scheduled_local_date,
                'due_at_utc'           => $dose->due_at_utc,
                'status'               => $dose->status,
                'taken_at'             => $dose->taken_at,
                'skipped_at'           => $dose->skipped_at,
            );
        }

        return rest_ensure_response( array(
            'success' => true,
            'date'    => date( 'Y-m-d' ),
            'count'   => count( $result ),
            'doses'   => $result,
        ) );
    }

    /**
     * GET /doses/stats
     * Returns adherence stats from mm_doses.
     */
    public static function get_stats( $request ) {
        $user_id = self::resolve_user_id( $request );
        $days    = intval( $request->get_param( 'days' ) ?: 7 );
        $days    = max( 1, min( $days, 365 ) );

        $stats = AME_Doses::get_stats( $user_id, $days );

        return rest_ensure_response( array(
            'success'        => true,
            'days'           => $days,
            'taken'          => intval( $stats->taken ),
            'missed'         => intval( $stats->missed ),
            'skipped'        => intval( $stats->skipped ),
            'adherence_rate' => intval( $stats->adherence_rate ),
        ) );
    }

    /**
     * POST /doses/{id}/taken
     */
    public static function mark_taken( $request ) {
        $user_id = self::resolve_user_id( $request );
        $dose_id = intval( $request['id'] );
        $note    = sanitize_textarea_field( $request->get_param( 'note' ) ?: '' );

        $result = AME_Doses::mark_taken( $dose_id, $user_id, $note );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( array( 'success' => true, 'dose_id' => $dose_id, 'status' => 'taken' ) );
    }

    /**
     * POST /doses/{id}/skipped
     */
    public static function mark_skipped( $request ) {
        $user_id = self::resolve_user_id( $request );
        $dose_id = intval( $request['id'] );
        $note    = sanitize_textarea_field( $request->get_param( 'note' ) ?: '' );

        $result = AME_Doses::mark_skipped( $dose_id, $user_id, $note );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( array( 'success' => true, 'dose_id' => $dose_id, 'status' => 'skipped' ) );
    }

    /**
     * GET /ai-context
     *
     * Unified AI context payload for the Autoanosis AI backend.
     * Reads from mm_medications + mm_doses ONLY.
     * Fixes the legacy column name mismatch (was reading wrong columns).
     *
     * Payload structure:
     * {
     *   "user_id": ...,
     *   "generated_at": "...",
     *   "active_medications": [ { medication fields } ],
     *   "today_schedule": [ { dose fields } ],
     *   "stats_7d": { taken, missed, skipped, adherence_rate },
     *   "next_dose": { ... } | null
     * }
     */
    public static function get_ai_context( $request ) {
        $user_id = self::resolve_user_id( $request );
        if ( ! $user_id ) {
            return new WP_Error( 'no_user', 'User not found.', array( 'status' => 400 ) );
        }

        // Active medications — reads mm_medications
        $medications = AME_Medications::get_by_patient( $user_id );
        $meds_payload = array();
        foreach ( $medications as $med ) {
            $meds_payload[] = self::format_medication( $med );
        }

        // Today's schedule — reads mm_doses
        $today_doses = AME_Medications::get_todays_schedule( $user_id );
        $today_payload = array();
        foreach ( $today_doses as $dose ) {
            $today_payload[] = array(
                'dose_id'         => intval( $dose->id ),
                'medication_name' => $dose->medication_name,
                'dosage'          => $dose->dosage,
                'time'            => substr( $dose->scheduled_local_time, 0, 5 ),
                'status'          => $dose->status,
                'taken_at'        => $dose->taken_at,
            );
        }

        // Stats — reads mm_doses
        $stats = AME_Doses::get_stats( $user_id, 7 );

        // Next dose — reads mm_doses
        $next = AME_Doses::get_next_dose( $user_id );
        $next_payload = null;
        if ( $next ) {
            $next_payload = array(
                'medication_name' => $next->medication_name,
                'dosage'          => $next->dosage,
                'date'            => $next->scheduled_local_date,
                'time'            => substr( $next->scheduled_local_time, 0, 5 ),
                'due_at_utc'      => $next->due_at_utc,
            );
        }

        return rest_ensure_response( array(
            'success'            => true,
            'user_id'            => $user_id,
            'generated_at'       => current_time( 'c' ),
            'active_medications' => $meds_payload,
            'today_schedule'     => $today_payload,
            'stats_7d'           => array(
                'taken'          => intval( $stats->taken ),
                'missed'         => intval( $stats->missed ),
                'skipped'        => intval( $stats->skipped ),
                'adherence_rate' => intval( $stats->adherence_rate ),
            ),
            'next_dose'          => $next_payload,
        ) );
    }

    // ─── HELPERS ─────────────────────────────────────────────────────────────

    /**
     * Resolve user_id from request.
     * For backend-to-backend calls, accepts ?user_id= param.
     * For user calls, uses current_user_id().
     */
    private static function resolve_user_id( $request ) {
        if ( is_user_logged_in() ) {
            return get_current_user_id();
        }
        // Backend call with user_id param
        $uid = intval( $request->get_param( 'user_id' ) );
        if ( $uid > 0 && get_userdata( $uid ) ) {
            return $uid;
        }
        return 0;
    }

    /**
     * Format a medication row for API output.
     * Uses correct column names from mm_medications schema.
     * Fixes legacy mismatch where old code read non-existent columns.
     */
    private static function format_medication( $med ) {
        return array(
            'id'               => intval( $med->id ),
            'medication_name'  => $med->medication_name,
            'active_ingredient' => $med->active_ingredient,
            'dosage'           => $med->dosage,
            'unit'             => $med->unit,
            'instructions'     => $med->instructions,
            'frequency'        => $med->frequency,
            'frequency_type'   => $med->frequency_type,
            'time_slots'       => json_decode( $med->time_slots, true ) ?: array(),
            'interval_hours'   => $med->interval_hours ? intval( $med->interval_hours ) : null,
            'weekdays'         => json_decode( $med->weekdays, true ) ?: array(),
            'start_date'       => $med->start_date,
            'end_date'         => $med->end_date,
            'status'           => $med->status,
            'is_prn'           => (bool) $med->is_prn,
            'prescribed_by'    => $med->prescribed_by,
            'indication'       => $med->indication,
            'version'          => intval( $med->version ),
        );
    }
}

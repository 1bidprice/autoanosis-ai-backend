<?php
/**
 * Plugin Name: Autoanosis Medications Engine
 * Plugin URI: https://autoanosis.com
 * Description: Production-grade medication tracking engine. Single truth: mm_doses. Supports fixed, PRN, interval, short-course, chronic regimens. Unified UI, cron, notifications, and AI context.
 * Version: 13.1.0
 * Author: Autoanosis Team
 * Author URI: https://autoanosis.com
 * Text Domain: autoanosis-medications-engine
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * ARCHITECTURE CONTRACT v13.0.0:
 * - mm_medications  = master metadata (what the medication is)
 * - mm_doses        = ONE TRUTH for all intake state, schedule, counters, AI context
 * - mm_notification_log = audit trail for all sent reminders
 * - mm_cron_log     = cron execution audit
 * - mm_adherence    = DEPRECATED (read-only quarantine, pending removal)
 * - FastAPI backend = DEPRECATED (quarantined externally)
 *
 * OPERATING CONTRACTS:
 * - UI reads/writes ONLY mm_doses + mm_medications
 * - Cron reads ONLY mm_doses
 * - REST API reads ONLY mm_doses + mm_medications
 * - Doctor Dashboard: NO write access to meds tables
 * - Integration: ONLY via aggregator/read model
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'AME_VERSION', '13.1.0' );
define( 'AME_DB_VERSION', '13.0' );
define( 'AME_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AME_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'AME_PLUGIN_FILE', __FILE__ );

// Load all classes
require_once AME_PLUGIN_DIR . 'includes/class-database.php';
require_once AME_PLUGIN_DIR . 'includes/class-medications.php';
require_once AME_PLUGIN_DIR . 'includes/class-doses.php';
require_once AME_PLUGIN_DIR . 'includes/class-dose-generator.php';
require_once AME_PLUGIN_DIR . 'includes/class-alerts.php';
require_once AME_PLUGIN_DIR . 'includes/class-symptoms.php';
require_once AME_PLUGIN_DIR . 'includes/class-timezone.php';
require_once AME_PLUGIN_DIR . 'includes/class-onesignal.php';
require_once AME_PLUGIN_DIR . 'includes/class-cron.php';
require_once AME_PLUGIN_DIR . 'includes/class-ajax.php';
require_once AME_PLUGIN_DIR . 'includes/class-shortcodes.php';
require_once AME_PLUGIN_DIR . 'includes/class-rest-api.php';
require_once AME_PLUGIN_DIR . 'admin/class-admin.php';
require_once AME_PLUGIN_DIR . 'admin/class-admin-diagnostics.php';

class Autoanosis_Medications_Engine {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        register_activation_hook( __FILE__, array( $this, 'activate' ) );
        register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );

        add_action( 'plugins_loaded', array( $this, 'check_db_version' ) );

        if ( is_admin() ) {
            AME_Admin::init();
        }

        add_action( 'init', array( $this, 'init' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'wp_head', array( $this, 'add_onesignal_script' ) );
    }

    public function activate() {
        AME_Database::create_tables();
        AME_Cron::schedule_events();
        // Generate doses for all existing active medications
        AME_DoseGenerator::regenerate_all( 30 );
        flush_rewrite_rules();
        update_option( 'ame_db_version', AME_DB_VERSION );
    }

    public function deactivate() {
        AME_Cron::deactivate();
    }

    public function check_db_version() {
        $current = get_option( 'ame_db_version', '0' );
        if ( version_compare( $current, AME_DB_VERSION, '<' ) ) {
            AME_Database::create_tables();
            update_option( 'ame_db_version', AME_DB_VERSION );
        }
        // Also check legacy db version key from old plugin
        $legacy = get_option( 'amm_db_version', '0' );
        if ( version_compare( $legacy, '13.0', '<' ) ) {
            AME_Database::quarantine_legacy_adherence();
        }
    }

    public function init() {
        AME_Cron::init();
        AME_Ajax::init();
        AME_Shortcodes::init();
        AME_REST_API::init();
    }

    public function enqueue_scripts() {
        if ( ! is_user_logged_in() ) {
            return;
        }
        global $post;
        if ( ! $post ) {
            return;
        }
        $is_meds_page = is_page( 'my-medications' )
            || has_shortcode( $post->post_content, 'ame_my_medications' )
            || has_shortcode( $post->post_content, 'amm_my_medications' ); // backwards compat

        if ( ! $is_meds_page ) {
            return;
        }

        wp_enqueue_style(
            'ame-dashboard',
            AME_PLUGIN_URL . 'public/assets/css/dashboard.css',
            array(),
            AME_VERSION
        );

        wp_enqueue_script(
            'ame-dashboard',
            AME_PLUGIN_URL . 'public/assets/js/dashboard.js',
            array( 'jquery' ),
            AME_VERSION,
            true
        );

        $tz_info = AME_Timezone::get_timezone_info( get_current_user_id() );

        wp_localize_script( 'ame-dashboard', 'ame_ajax', array(
            'url'     => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'ame_nonce' ),
            'user_id' => get_current_user_id(),
            'timezone' => $tz_info,
        ) );
    }

    public function add_onesignal_script() {
        if ( ! is_user_logged_in() ) {
            return;
        }
        global $post;
        if ( ! $post ) {
            return;
        }
        if ( is_page( 'my-medications' )
            || has_shortcode( $post->post_content, 'ame_my_medications' )
            || has_shortcode( $post->post_content, 'amm_my_medications' ) ) {
            echo AME_OneSignal::get_init_script();
        }
    }
}

Autoanosis_Medications_Engine::get_instance();

/**
 * Medical Memory Dashboard JavaScript
 * Version 9.1.0 - With Timezone/Travel Mode Support
 */
(function($) {
    'use strict';
    
    // Modal handling
    var modal = $('#amm-medication-modal');
    var timezoneModal = $('#amm-timezone-modal');
    
    // ========================================
    // TIMEZONE FUNCTIONALITY
    // ========================================
    
    // Auto-detect timezone on page load
    function detectBrowserTimezone() {
        try {
            var tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
            return tz;
        } catch(e) {
            return null;
        }
    }
    
    // Send detected timezone to server
    function sendDetectedTimezone() {
        var detectedTz = detectBrowserTimezone();
        if (!detectedTz) return;
        
        $.post(amm_ajax.url, {
            action: 'amm_detect_timezone',
            nonce: amm_ajax.nonce,
            timezone: detectedTz
        }, function(response) {
            if (response.success && response.data.suggest_travel_mode) {
                // Show travel mode suggestion
                showTravelModeSuggestion(response.data);
            }
        });
    }
    
    // Show travel mode suggestion popup
    function showTravelModeSuggestion(data) {
        var homeTz = data.info.home_label;
        var currentTz = data.info.current_label;
        
        var msg = 'Φαίνεται ότι βρίσκεστε σε διαφορετική ζώνη ώρας!\n\n' +
                  '🏠 Σπίτι: ' + homeTz + '\n' +
                  '📍 Τώρα: ' + currentTz + '\n\n' +
                  'Θέλετε να ενεργοποιήσετε τη Λειτουργία Ταξιδιού;\n' +
                  'Οι υπενθυμίσεις φαρμάκων θα προσαρμοστούν στην τοπική ώρα.';
        
        if (confirm(msg)) {
            enableTravelMode(data.detected);
        }
    }
    
    // Enable travel mode
    function enableTravelMode(timezone) {
        $.post(amm_ajax.url, {
            action: 'amm_toggle_travel_mode',
            nonce: amm_ajax.nonce,
            enabled: 'true',
            timezone: timezone
        }, function(response) {
            if (response.success) {
                location.reload();
            }
        });
    }
    
    // Disable travel mode
    function disableTravelMode() {
        $.post(amm_ajax.url, {
            action: 'amm_toggle_travel_mode',
            nonce: amm_ajax.nonce,
            enabled: 'false'
        }, function(response) {
            if (response.success) {
                location.reload();
            }
        });
    }
    
    // Toggle travel mode button
    $('#amm-toggle-travel').on('click', function() {
        var isActive = $(this).hasClass('active');
        
        if (isActive) {
            if (confirm('Απενεργοποίηση Λειτουργίας Ταξιδιού;\n\nΟι υπενθυμίσεις θα επιστρέψουν στην ώρα σπιτιού σας.')) {
                disableTravelMode();
            }
        } else {
            // Open timezone modal to select travel timezone
            timezoneModal.addClass('active');
            $('#amm-travel-mode-checkbox').prop('checked', true).trigger('change');
        }
    });
    
    // Timezone settings button
    $('#amm-timezone-settings').on('click', function() {
        timezoneModal.addClass('active');
    });
    
    // Close timezone modal
    timezoneModal.find('.amm-modal-close, .amm-modal-cancel').on('click', function() {
        timezoneModal.removeClass('active');
    });
    
    timezoneModal.on('click', function(e) {
        if (e.target === this) timezoneModal.removeClass('active');
    });
    
    // Travel mode checkbox toggle
    $('#amm-travel-mode-checkbox').on('change', function() {
        var isChecked = $(this).is(':checked');
        $('.amm-travel-timezone-group').toggle(isChecked);
        updateTimezonePreview();
    });
    
    // Auto-detect timezone button
    $('#amm-detect-timezone').on('click', function() {
        var detectedTz = detectBrowserTimezone();
        if (detectedTz) {
            $('#amm-current-timezone').val(detectedTz);
            updateTimezonePreview();
            alert('Ανιχνεύτηκε: ' + detectedTz);
        } else {
            alert('Δεν ήταν δυνατή η αυτόματη ανίχνευση.');
        }
    });
    
    // Update preview when timezone changes
    $('#amm-home-timezone, #amm-current-timezone').on('change', function() {
        updateTimezonePreview();
    });
    
    // Update timezone preview
    function updateTimezonePreview() {
        var homeTz = $('#amm-home-timezone').val();
        var currentTz = $('#amm-current-timezone').val();
        var travelMode = $('#amm-travel-mode-checkbox').is(':checked');
        
        if (!travelMode) {
            currentTz = homeTz;
        }
        
        // Get times from server
        $.post(amm_ajax.url, {
            action: 'amm_get_timezone_preview',
            nonce: amm_ajax.nonce,
            home_timezone: homeTz,
            current_timezone: currentTz
        }, function(response) {
            if (response.success) {
                $('#amm-preview-home-time').text(response.data.home_time);
                $('#amm-preview-current-time').text(response.data.current_time);
                var diff = response.data.offset_hours;
                var diffText = (diff >= 0 ? '+' : '') + diff + ' ώρες';
                $('#amm-preview-diff').text(diffText);
            }
        });
    }
    
    // Save timezone settings
    $('#amm-save-timezone').on('click', function() {
        var homeTz = $('#amm-home-timezone').val();
        var currentTz = $('#amm-current-timezone').val();
        var travelMode = $('#amm-travel-mode-checkbox').is(':checked');
        
        // Save home timezone
        $.post(amm_ajax.url, {
            action: 'amm_update_timezone',
            nonce: amm_ajax.nonce,
            timezone: homeTz,
            type: 'home'
        }, function() {
            // Toggle travel mode
            $.post(amm_ajax.url, {
                action: 'amm_toggle_travel_mode',
                nonce: amm_ajax.nonce,
                enabled: travelMode ? 'true' : 'false',
                timezone: currentTz
            }, function(response) {
                if (response.success) {
                    location.reload();
                }
            });
        });
    });
    
    // Update current time display
    function updateCurrentTimeDisplay() {
        var now = new Date();
        var timeStr = now.toLocaleTimeString('el-GR', { hour: '2-digit', minute: '2-digit' });
        $('#amm-current-time').text(timeStr);
    }
    
    // Update time every minute
    setInterval(updateCurrentTimeDisplay, 60000);
    
    // ========================================
    // MEDICATION FUNCTIONALITY
    // ========================================
    
    $('#amm-add-medication').on('click', function() {
        $('#amm-modal-title').text('Προσθήκη Φαρμάκου');
        $('#amm-medication-form')[0].reset();
        $('input[name="medication_id"]').val('');
        $('input[name="start_date"]').val(new Date().toISOString().split('T')[0]);
        modal.addClass('active');
    });
    
    $('.amm-modal-close, .amm-modal-cancel').on('click', function() {
        modal.removeClass('active');
    });
    
    modal.on('click', function(e) {
        if (e.target === this) modal.removeClass('active');
    });
    
    // Add time slot
    $('#amm-add-time-slot').on('click', function() {
        var html = '<div class="amm-time-slot"><input type="time" name="time_slot[]" required><button type="button" class="amm-btn-remove-time">&times;</button></div>';
        $('#amm-time-slots').append(html);
    });
    
    $(document).on('click', '.amm-btn-remove-time', function() {
        if ($('.amm-time-slot').length > 1) {
            $(this).closest('.amm-time-slot').remove();
        }
    });
    
    // Save medication
    $('#amm-medication-form').on('submit', function(e) {
        e.preventDefault();
        
        var timeSlots = [];
        $('input[name="time_slot[]"]').each(function() {
            if ($(this).val()) timeSlots.push($(this).val());
        });
        
        var data = {
            action: 'amm_save_medication',
            nonce: amm_ajax.nonce,
            medication_id: $('input[name="medication_id"]').val(),
            medication_name: $('input[name="medication_name"]').val(),
            dosage: $('input[name="dosage"]').val(),
            frequency: $('select[name="frequency"]').val(),
            time_slots: JSON.stringify(timeSlots),
            start_date: $('input[name="start_date"]').val(),
            end_date: $('input[name="end_date"]').val(),
            instructions: $('textarea[name="instructions"]').val()
        };
        
        $.post(amm_ajax.url, data, function(response) {
            if (response.success) {
                location.reload();
            } else {
                alert(response.data || 'Error saving medication');
            }
        });
    });
    
    // Edit medication
    $(document).on('click', '.amm-btn-edit', function() {
        var card = $(this).closest('.amm-medication-card');
        var id = card.data('medication-id');
        
        $.post(amm_ajax.url, {
            action: 'amm_get_medication',
            nonce: amm_ajax.nonce,
            medication_id: id
        }, function(response) {
            if (response.success) {
                var med = response.data;
                $('#amm-modal-title').text('Επεξεργασία Φαρμάκου');
                $('input[name="medication_id"]').val(med.id);
                $('input[name="medication_name"]').val(med.medication_name);
                $('input[name="dosage"]').val(med.dosage);
                $('select[name="frequency"]').val(med.frequency);
                $('input[name="start_date"]').val(med.start_date);
                $('input[name="end_date"]').val(med.end_date);
                $('textarea[name="instructions"]').val(med.instructions);
                
                // Set time slots
                var timeSlots = JSON.parse(med.time_slots || '[]');
                $('#amm-time-slots').empty();
                if (timeSlots.length === 0) timeSlots = [''];
                timeSlots.forEach(function(time) {
                    var html = '<div class="amm-time-slot"><input type="time" name="time_slot[]" value="' + time + '" required><button type="button" class="amm-btn-remove-time">&times;</button></div>';
                    $('#amm-time-slots').append(html);
                });
                
                modal.addClass('active');
            }
        });
    });
    
    // Delete medication
    $(document).on('click', '.amm-btn-delete', function() {
        if (!confirm('Είστε σίγουροι ότι θέλετε να διαγράψετε αυτό το φάρμακο;')) return;
        
        var card = $(this).closest('.amm-medication-card');
        var id = card.data('medication-id');
        
        $.post(amm_ajax.url, {
            action: 'amm_delete_medication',
            nonce: amm_ajax.nonce,
            medication_id: id
        }, function(response) {
            if (response.success) {
                card.fadeOut(function() { $(this).remove(); });
            } else {
                alert(response.data || 'Error deleting medication');
            }
        });
    });
    
    // Mark dose as taken/skipped
    $(document).on('click', '.amm-dose-actions .amm-btn', function() {
        var btn = $(this);
        var doseItem = btn.closest('.amm-dose-item');
        var doseId = doseItem.data('dose-id');
        var action = btn.data('action');
        
        $.post(amm_ajax.url, {
            action: 'amm_mark_dose',
            nonce: amm_ajax.nonce,
            dose_id: doseId,
            status: action
        }, function(response) {
            if (response.success) {
                location.reload();
            } else {
                alert(response.data || 'Error updating dose');
            }
        });
    });
    
    // Log symptom
    $('#amm-symptom-form').on('submit', function(e) {
        e.preventDefault();
        
        var data = {
            action: 'amm_log_symptom',
            nonce: amm_ajax.nonce,
            symptom_type: $('input[name="symptom_type"]').val(),
            severity: $('select[name="severity"]').val(),
            description: $('textarea[name="description"]').val()
        };
        
        $.post(amm_ajax.url, data, function(response) {
            if (response.success) {
                alert('Το σύμπτωμα καταγράφηκε!');
                $('#amm-symptom-form')[0].reset();
            } else {
                alert(response.data || 'Error logging symptom');
            }
        });
    });
    
    // Mark all alerts as read
    $('#amm-mark-all-read').on('click', function() {
        $.post(amm_ajax.url, {
            action: 'amm_mark_alerts_read',
            nonce: amm_ajax.nonce
        }, function(response) {
            if (response.success) {
                $('.amm-alert-item').addClass('amm-alert-read');
                $('.amm-stat-alerts .amm-stat-number').text('0');
            }
        });
    });
    
    // Enable push notifications
    $('#amm-enable-push').on('click', function() {
        if (typeof OneSignal === 'undefined') {
            alert('OneSignal δεν είναι διαθέσιμο');
            return;
        }
        
        OneSignal.Notifications.requestPermission().then(function() {
            OneSignal.login('amm_user_' + amm_ajax.user_id);
            alert('Οι ειδοποιήσεις ενεργοποιήθηκαν!');
        });
    });
    
    // Test push notification
    $('#amm-test-push').on('click', function() {
        $.post(amm_ajax.url, {
            action: 'amm_test_push',
            nonce: amm_ajax.nonce
        }, function(response) {
            if (response.success) {
                alert('Δοκιμαστική ειδοποίηση στάλθηκε!');
            } else {
                alert(response.data || 'Error sending test push');
            }
        });
    });
    
    // ========================================
    // INITIALIZATION
    // ========================================
    
    // On page load, detect timezone
    $(document).ready(function() {
        // Only auto-detect if user hasn't set timezone before
        if (amm_ajax.timezone && !amm_ajax.timezone.home_timezone) {
            sendDetectedTimezone();
        } else {
            // Check if current location differs from home
            var detectedTz = detectBrowserTimezone();
            if (detectedTz && amm_ajax.timezone && 
                amm_ajax.timezone.home_timezone && 
                detectedTz !== amm_ajax.timezone.home_timezone &&
                !amm_ajax.timezone.travel_mode) {
                // Silently update current timezone and suggest travel mode
                sendDetectedTimezone();
            }
        }
    });
    
})(jQuery);

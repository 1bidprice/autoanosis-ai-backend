<?php
/**
 * Admin class for settings and debug
 * Version 11.0.0 - Simplified with better debugging
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Admin {
    
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_menu'));
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('wp_ajax_amm_trigger_cron', array(__CLASS__, 'ajax_trigger_cron'));
        add_action('wp_ajax_amm_send_test_push', array(__CLASS__, 'ajax_send_test_push'));
    }
    
    public static function add_menu() {
        add_menu_page(
            'Medical Memory',
            'Medical Memory',
            'manage_options',
            'medical-memory',
            array(__CLASS__, 'render_settings_page'),
            'dashicons-heart',
            30
        );
        
        add_submenu_page(
            'medical-memory',
            'Debug',
            'Debug',
            'manage_options',
            'medical-memory-debug',
            array(__CLASS__, 'render_debug_page')
        );
        
        // v12: Add diagnostics page
        add_submenu_page(
            'medical-memory',
            'Diagnostics',
            'Diagnostics',
            'manage_options',
            'medical-memory-diagnostics',
            array('AMM_Admin_Diagnostics', 'render_dashboard')
        );
    }
    
    public static function register_settings() {
        register_setting('amm_settings', 'amm_onesignal_app_id');
        register_setting('amm_settings', 'amm_onesignal_api_key');
        register_setting('amm_settings', 'amm_enable_push');
    }
    
    public static function render_settings_page() {
        $cron_status = AMM_Cron::get_status();
        ?>
        <div class="wrap">
            <h1>Medical Memory Settings</h1>
            <p><strong>Version <?php echo AMM_VERSION; ?></strong> - Push-Only Edition</p>
            
            <form method="post" action="options.php">
                <?php settings_fields('amm_settings'); ?>
                
                <h2>OneSignal Configuration</h2>
                <table class="form-table">
                    <tr>
                        <th>App ID</th>
                        <td>
                            <input type="text" name="amm_onesignal_app_id" value="<?php echo esc_attr(get_option('amm_onesignal_app_id')); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th>REST API Key</th>
                        <td>
                            <input type="password" name="amm_onesignal_api_key" value="<?php echo esc_attr(get_option('amm_onesignal_api_key')); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th>Enable Push</th>
                        <td>
                            <input type="checkbox" name="amm_enable_push" value="1" <?php checked(get_option('amm_enable_push', '1'), '1'); ?>>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
            
            <h2>Cron Status</h2>
            <table class="widefat" style="max-width: 600px;">
                <tr>
                    <th>Check Medications</th>
                    <td><?php echo esc_html($cron_status['check_medications'] ? date('Y-m-d H:i:s', $cron_status['check_medications']) : 'Not scheduled'); ?></td>
                </tr>
            </table>
            
            <h2>Shortcode</h2>
            <p>Use <code>[amm_my_medications]</code> on any page to display the patient dashboard.</p>
        </div>
        <?php
    }
    
    public static function render_debug_page() {
        global $wpdb;
        
        // Get current Athens time
        $athens_tz = new DateTimeZone('Europe/Athens');
        $now_athens = new DateTime('now', $athens_tz);
        
        // Get database info using tkc_mm_* tables
        $medications_table = 'tkc_mm_medications';
        $adherence_table = 'tkc_mm_adherence';
        
        $total_medications = $wpdb->get_var("SELECT COUNT(*) FROM {$medications_table} WHERE active = 1");
        
        // Get today's adherence records
        $today_date = $now_athens->format('Y-m-d');
        $today_doses = $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, m.medication_name, m.patient_id 
             FROM {$adherence_table} a
             JOIN {$medications_table} m ON a.medication_id = m.id
             WHERE DATE(a.scheduled_time) = %s
             AND m.active = 1
             ORDER BY a.scheduled_time ASC",
            $today_date
        ));
        
        // Get users with medications
        $users_with_meds = $wpdb->get_col("SELECT DISTINCT patient_id FROM {$medications_table} WHERE active = 1");
        ?>
        <div class="wrap">
            <h1>Medical Memory Debug</h1>
            <p>Version <?php echo AMM_VERSION; ?> - Use this page to diagnose push notification issues.</p>
            
            <h2>Quick Actions</h2>
            <p>
                <label>Target User ID: <input type="number" id="amm-target-user" value="9" style="width: 80px;"></label>
                <button class="button button-primary" id="amm-test-push">Send Test Push</button>
                <button class="button" id="amm-trigger-cron">Trigger Cron Now</button>
                <button class="button" id="amm-refresh">Refresh</button>
            </p>
            
            <div id="amm-debug-result" style="background: #f5f5f5; padding: 15px; margin: 15px 0; border: 1px solid #ccc; display: none;">
                <h3>Result:</h3>
                <pre id="amm-debug-output" style="white-space: pre-wrap; word-wrap: break-word; max-height: 400px; overflow: auto;"></pre>
            </div>
            
            <h2>Debug Information</h2>
            <table class="widefat" style="max-width: 600px;">
                <tr>
                    <th>OneSignal App ID</th>
                    <td><?php echo get_option('amm_onesignal_app_id') ? 'SET' : '<span style="color:red;">NOT SET</span>'; ?></td>
                </tr>
                <tr>
                    <th>OneSignal API Key</th>
                    <td><?php echo get_option('amm_onesignal_api_key') ? 'SET' : '<span style="color:red;">NOT SET</span>'; ?></td>
                </tr>
                <tr>
                    <th>Push Enabled</th>
                    <td><?php echo get_option('amm_enable_push', '1') === '1' ? 'Yes' : 'No'; ?></td>
                </tr>
                <tr>
                    <th>Your External ID</th>
                    <td><code>amm_user_<?php echo get_current_user_id(); ?></code></td>
                </tr>
                <tr style="background: #ffffcc;">
                    <th>Athens Time (NOW)</th>
                    <td><strong style="font-size: 1.2em;"><?php echo $now_athens->format('Y-m-d H:i:s'); ?></strong></td>
                </tr>
                <tr>
                    <th>UTC Time</th>
                    <td><?php echo gmdate('Y-m-d H:i:s'); ?></td>
                </tr>
                <tr>
                    <th>WordPress Timezone</th>
                    <td><?php echo get_option('timezone_string') ?: 'UTC+' . get_option('gmt_offset'); ?></td>
                </tr>
                <tr>
                    <th>Total Active Medications</th>
                    <td><?php echo $total_medications; ?></td>
                </tr>
                <tr>
                    <th>Today's Doses</th>
                    <td><?php echo count($today_doses); ?></td>
                </tr>
                <tr>
                    <th>Users with Medications</th>
                    <td><?php echo implode(', ', $users_with_meds); ?></td>
                </tr>
            </table>
            
            <h2>Today's Doses (<?php echo $today_date; ?>)</h2>
            <table class="widefat">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient ID</th>
                        <th>Medication</th>
                        <th>Scheduled Time</th>
                        <th>Status</th>
                        <th>Due?</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($today_doses)): ?>
                    <tr>
                        <td colspan="6">No doses scheduled for today</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($today_doses as $dose): 
                        $dose_dt = new DateTime($dose->scheduled_time, $athens_tz);
                        $diff_minutes = ($dose_dt->getTimestamp() - $now_athens->getTimestamp()) / 60;
                        $is_due = abs($diff_minutes) <= 5;
                        $is_past = $diff_minutes < -5;
                        $is_future = $diff_minutes > 5;
                    ?>
                    <tr style="<?php echo $is_due ? 'background: #d4edda;' : ($is_past ? 'background: #f8d7da;' : ''); ?>">
                        <td><?php echo $dose->id; ?></td>
                        <td><?php echo $dose->patient_id; ?></td>
                        <td><?php echo esc_html($dose->medication_name); ?></td>
                        <td><strong><?php echo date('H:i', strtotime($dose->scheduled_time)); ?></strong></td>
                        <td><?php echo esc_html($dose->status); ?></td>
                        <td>
                            <?php 
                            if ($is_due) {
                                echo '<span style="color: green; font-weight: bold;">DUE NOW (' . round($diff_minutes) . ' min)</span>';
                            } elseif ($is_past) {
                                echo '<span style="color: red;">Passed (' . round(abs($diff_minutes)) . ' min ago)</span>';
                            } else {
                                echo '<span style="color: blue;">In ' . round($diff_minutes) . ' min</span>';
                            }
                            ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <script>
            jQuery(document).ready(function($) {
                function showResult(data) {
                    $('#amm-debug-result').show();
                    $('#amm-debug-output').text(JSON.stringify(data, null, 2));
                }
                
                $('#amm-test-push').on('click', function() {
                    var userId = $('#amm-target-user').val();
                    var btn = $(this);
                    btn.prop('disabled', true).text('Sending...');
                    
                    $.post(ajaxurl, {
                        action: 'amm_send_test_push',
                        user_id: userId,
                        _wpnonce: '<?php echo wp_create_nonce('amm_debug'); ?>'
                    }, function(response) {
                        showResult(response);
                        btn.prop('disabled', false).text('Send Test Push');
                    }).fail(function(xhr) {
                        showResult({error: 'Request failed', status: xhr.status});
                        btn.prop('disabled', false).text('Send Test Push');
                    });
                });
                
                $('#amm-trigger-cron').on('click', function() {
                    var btn = $(this);
                    btn.prop('disabled', true).text('Running...');
                    
                    $.post(ajaxurl, {
                        action: 'amm_trigger_cron',
                        _wpnonce: '<?php echo wp_create_nonce('amm_debug'); ?>'
                    }, function(response) {
                        showResult(response);
                        btn.prop('disabled', false).text('Trigger Cron Now');
                    }).fail(function(xhr) {
                        showResult({error: 'Request failed', status: xhr.status});
                        btn.prop('disabled', false).text('Trigger Cron Now');
                    });
                });
                
                $('#amm-refresh').on('click', function() {
                    location.reload();
                });
            });
            </script>
        </div>
        <?php
    }
    
    public static function ajax_trigger_cron() {
        check_ajax_referer('amm_debug', '_wpnonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permission denied');
        }
        
        $result = AMM_Cron::check_due_medications();
        wp_send_json($result);
    }
    
    public static function ajax_send_test_push() {
        check_ajax_referer('amm_debug', '_wpnonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permission denied');
        }
        
        $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : get_current_user_id();
        
        $result = AMM_OneSignal::send_test($user_id);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array(
                'message' => $result->get_error_message(),
                'target_user' => $user_id,
                'external_id' => 'amm_user_' . $user_id
            ));
        }
        
        wp_send_json_success(array(
            'message' => 'Push notification sent!',
            'target_user' => $user_id,
            'external_id' => 'amm_user_' . $user_id,
            'onesignal_response' => $result
        ));
    }
}

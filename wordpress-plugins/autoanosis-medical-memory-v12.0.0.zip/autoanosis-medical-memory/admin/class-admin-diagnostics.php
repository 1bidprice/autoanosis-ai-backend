<?php
/**
 * Admin Diagnostics class - v12.0.0 (NEW)
 * Provides health monitoring and debugging tools
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Admin_Diagnostics {
    
    /**
     * Render diagnostics dashboard
     */
    public static function render_dashboard() {
        ?>
        <div class="wrap">
            <h1>Medical Memory - Diagnostics</h1>
            
            <?php self::render_cron_health(); ?>
            <?php self::render_onesignal_status(); ?>
            <?php self::render_dose_stats(); ?>
            <?php self::render_notification_log(); ?>
            <?php self::render_test_tools(); ?>
        </div>
        <?php
    }
    
    /**
     * Render cron health section
     */
    private static function render_cron_health() {
        $cron_status = AMM_Cron::get_status();
        $health_stats = AMM_Cron::get_health_stats();
        
        ?>
        <div class="card" style="margin-top: 20px;">
            <h2>Cron Health (Last 24 Hours)</h2>
            
            <h3>Scheduled Events</h3>
            <table class="widefat">
                <thead>
                    <tr>
                        <th>Job</th>
                        <th>Next Run</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Check Medications</td>
                        <td><?php echo $cron_status['check_medications'] ? date('Y-m-d H:i:s', $cron_status['check_medications']) : 'Not scheduled'; ?></td>
                        <td><?php echo $cron_status['check_medications'] ? '✅ Active' : '❌ Inactive'; ?></td>
                    </tr>
                    <tr>
                        <td>Generate Doses</td>
                        <td><?php echo $cron_status['generate_doses'] ? date('Y-m-d H:i:s', $cron_status['generate_doses']) : 'Not scheduled'; ?></td>
                        <td><?php echo $cron_status['generate_doses'] ? '✅ Active' : '❌ Inactive'; ?></td>
                    </tr>
                    <tr>
                        <td>Cleanup Doses</td>
                        <td><?php echo $cron_status['cleanup_doses'] ? date('Y-m-d H:i:s', $cron_status['cleanup_doses']) : 'Not scheduled'; ?></td>
                        <td><?php echo $cron_status['cleanup_doses'] ? '✅ Active' : '❌ Inactive'; ?></td>
                    </tr>
                </tbody>
            </table>
            
            <h3>Execution Stats</h3>
            <?php if (!empty($health_stats)): ?>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>Job</th>
                            <th>Total Runs</th>
                            <th>Success</th>
                            <th>Failed</th>
                            <th>Last Run</th>
                            <th>Avg Time (ms)</th>
                            <th>Notifications Sent</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($health_stats as $stat): ?>
                            <tr>
                                <td><?php echo esc_html($stat->job_name); ?></td>
                                <td><?php echo intval($stat->total_runs); ?></td>
                                <td style="color: green;"><?php echo intval($stat->successful_runs); ?></td>
                                <td style="color: red;"><?php echo intval($stat->failed_runs); ?></td>
                                <td><?php echo esc_html($stat->last_run_at); ?></td>
                                <td><?php echo round($stat->avg_execution_time_ms); ?></td>
                                <td><?php echo intval($stat->total_notifications_sent); ?> (<?php echo intval($stat->total_notifications_failed); ?> failed)</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No cron runs in the last 24 hours.</p>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render OneSignal status section
     */
    private static function render_onesignal_status() {
        global $wpdb;
        
        $tokens_table = AMM_Database::get_table_name('onesignal_tokens');
        $total_tokens = $wpdb->get_var("SELECT COUNT(*) FROM $tokens_table WHERE is_subscribed = 1");
        
        $app_id = get_option('amm_onesignal_app_id', '');
        $api_key = get_option('amm_onesignal_api_key', '');
        
        ?>
        <div class="card" style="margin-top: 20px;">
            <h2>OneSignal Status</h2>
            
            <table class="widefat">
                <tr>
                    <th>App ID</th>
                    <td><?php echo $app_id ? '✅ Configured: ' . esc_html(substr($app_id, 0, 20)) . '...' : '❌ Not configured'; ?></td>
                </tr>
                <tr>
                    <th>API Key</th>
                    <td><?php echo $api_key ? '✅ Configured' : '❌ Not configured'; ?></td>
                </tr>
                <tr>
                    <th>Subscribed Users</th>
                    <td><?php echo intval($total_tokens); ?></td>
                </tr>
            </table>
            
            <h3>Recent Subscriptions</h3>
            <?php
            $recent_tokens = $wpdb->get_results("
                SELECT t.*, u.user_login
                FROM $tokens_table t
                LEFT JOIN {$wpdb->users} u ON t.user_id = u.ID
                WHERE t.is_subscribed = 1
                ORDER BY t.updated_at DESC
                LIMIT 10
            ");
            
            if (!empty($recent_tokens)): ?>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>External ID</th>
                            <th>Platform</th>
                            <th>Last Updated</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_tokens as $token): ?>
                            <tr>
                                <td><?php echo esc_html($token->user_login); ?> (ID: <?php echo $token->user_id; ?>)</td>
                                <td><?php echo esc_html($token->external_id); ?></td>
                                <td><?php echo esc_html($token->platform); ?></td>
                                <td><?php echo esc_html($token->updated_at); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No subscriptions yet.</p>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render dose statistics section
     */
    private static function render_dose_stats() {
        global $wpdb;
        
        $doses_table = AMM_Database::get_table_name('doses');
        
        $stats = $wpdb->get_row("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'sending' THEN 1 ELSE 0 END) as sending,
                SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent,
                SUM(CASE WHEN status = 'taken' THEN 1 ELSE 0 END) as taken,
                SUM(CASE WHEN status = 'missed' THEN 1 ELSE 0 END) as missed,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
            FROM $doses_table
            WHERE dose_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        ");
        
        ?>
        <div class="card" style="margin-top: 20px;">
            <h2>Dose Statistics (Last 7 Days)</h2>
            
            <table class="widefat">
                <tr>
                    <th>Total Doses</th>
                    <td><?php echo intval($stats->total); ?></td>
                </tr>
                <tr>
                    <th>Pending</th>
                    <td style="color: orange;"><?php echo intval($stats->pending); ?></td>
                </tr>
                <tr>
                    <th>Sending</th>
                    <td style="color: blue;"><?php echo intval($stats->sending); ?></td>
                </tr>
                <tr>
                    <th>Sent</th>
                    <td style="color: green;"><?php echo intval($stats->sent); ?></td>
                </tr>
                <tr>
                    <th>Taken</th>
                    <td style="color: green; font-weight: bold;"><?php echo intval($stats->taken); ?></td>
                </tr>
                <tr>
                    <th>Missed</th>
                    <td style="color: red;"><?php echo intval($stats->missed); ?></td>
                </tr>
                <tr>
                    <th>Failed</th>
                    <td style="color: red; font-weight: bold;"><?php echo intval($stats->failed); ?></td>
                </tr>
            </table>
        </div>
        <?php
    }
    
    /**
     * Render recent notification log
     */
    private static function render_notification_log() {
        global $wpdb;
        
        $log_table = AMM_Database::get_table_name('notification_log');
        
        $recent_logs = $wpdb->get_results("
            SELECT l.*, u.user_login, m.medication_name
            FROM $log_table l
            LEFT JOIN {$wpdb->users} u ON l.user_id = u.ID
            LEFT JOIN {$wpdb->prefix}mm_medications m ON l.medication_id = m.id
            ORDER BY l.created_at DESC
            LIMIT 20
        ");
        
        ?>
        <div class="card" style="margin-top: 20px;">
            <h2>Recent Notifications</h2>
            
            <?php if (!empty($recent_logs)): ?>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>Time</th>
                            <th>User</th>
                            <th>Medication</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Error</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_logs as $log): ?>
                            <tr>
                                <td><?php echo esc_html($log->created_at); ?></td>
                                <td><?php echo esc_html($log->user_login); ?></td>
                                <td><?php echo esc_html($log->medication_name); ?></td>
                                <td><?php echo esc_html($log->notification_type); ?></td>
                                <td style="color: <?php echo $log->status === 'sent' ? 'green' : 'red'; ?>;">
                                    <?php echo esc_html($log->status); ?>
                                </td>
                                <td><?php echo esc_html($log->error_message); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No notifications logged yet.</p>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render test tools section
     */
    private static function render_test_tools() {
        $current_user_id = get_current_user_id();
        
        ?>
        <div class="card" style="margin-top: 20px;">
            <h2>Test Tools</h2>
            
            <p>
                <button type="button" class="button button-primary" id="amm-test-push">
                    Send Test Push to Me
                </button>
                <span id="amm-test-result" style="margin-left: 10px;"></span>
            </p>
            
            <p>
                <button type="button" class="button" id="amm-run-cron">
                    Manually Run Cron Now
                </button>
                <span id="amm-cron-result" style="margin-left: 10px;"></span>
            </p>
            
            <script>
            jQuery(document).ready(function($) {
                $('#amm-test-push').on('click', function() {
                    var $btn = $(this);
                    var $result = $('#amm-test-result');
                    
                    $btn.prop('disabled', true);
                    $result.html('Sending...');
                    
                    $.post(ajaxurl, {
                        action: 'amm_test_push',
                        nonce: '<?php echo wp_create_nonce('amm_test_push'); ?>'
                    }, function(response) {
                        $btn.prop('disabled', false);
                        if (response.success) {
                            $result.html('<span style="color: green;">✅ ' + response.data.message + '</span>');
                        } else {
                            $result.html('<span style="color: red;">❌ ' + response.data.message + '</span>');
                        }
                    });
                });
                
                $('#amm-run-cron').on('click', function() {
                    var $btn = $(this);
                    var $result = $('#amm-cron-result');
                    
                    $btn.prop('disabled', true);
                    $result.html('Running...');
                    
                    $.post(ajaxurl, {
                        action: 'amm_run_cron_manually',
                        nonce: '<?php echo wp_create_nonce('amm_run_cron'); ?>'
                    }, function(response) {
                        $btn.prop('disabled', false);
                        if (response.success) {
                            $result.html('<span style="color: green;">✅ ' + response.data.message + '</span>');
                            setTimeout(function() {
                                location.reload();
                            }, 2000);
                        } else {
                            $result.html('<span style="color: red;">❌ ' + response.data.message + '</span>');
                        }
                    });
                });
            });
            </script>
        </div>
        <?php
    }
    
    /**
     * Handle test push AJAX
     */
    public static function ajax_test_push() {
        check_ajax_referer('amm_test_push', 'nonce');
        
        $user_id = get_current_user_id();
        
        if (!$user_id) {
            wp_send_json_error(array('message' => 'Not logged in'));
        }
        
        $result = AMM_OneSignal::send_test($user_id);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        } else {
            wp_send_json_success(array('message' => 'Test notification sent! Check your device.'));
        }
    }
    
    /**
     * Handle manual cron run AJAX
     */
    public static function ajax_run_cron_manually() {
        check_ajax_referer('amm_run_cron', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied'));
        }
        
        $result = AMM_Cron::check_due_medications();
        
        $message = sprintf(
            'Cron executed: %d doses checked, %d notifications sent',
            $result['doses_checked'],
            $result['notifications_sent']
        );
        
        wp_send_json_success(array('message' => $message));
    }
}

// Register AJAX handlers
add_action('wp_ajax_amm_test_push', array('AMM_Admin_Diagnostics', 'ajax_test_push'));
add_action('wp_ajax_amm_run_cron_manually', array('AMM_Admin_Diagnostics', 'ajax_run_cron_manually'));

<?php
/**
 * Plugin Name: Autoanosis Medical Memory
 * Plugin URI: https://autoanosis.com
 * Description: Production-ready medication tracking with push notifications, dose instances, atomic locking, and professional cron scheduling.
 * Version: 12.0.0
 * Author: Autoanosis Team
 * Author URI: https://autoanosis.com
 * Text Domain: autoanosis-medical-memory
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * 
 * CHANGELOG v12.0.0 (PRODUCTION-READY):
 * - NEW: tkc_mm_doses table with atomic locking
 * - NEW: Dose generation system (pre-generate 30 days)
 * - NEW: Admin diagnostics dashboard
 * - NEW: Notification audit trail
 * - NEW: Cron health monitoring
 * - FIXED: Anti-duplicate with database unique constraint
 * - FIXED: Atomic status updates (no more transients)
 * - IMPROVED: Server cron support (SiteGround)
 * - IMPROVED: Performance indexes
 * - IMPROVED: Error handling and logging
 */

if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('AMM_VERSION', '12.0.0');
define('AMM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AMM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AMM_DB_VERSION', '12.0');

// Include required files
require_once AMM_PLUGIN_DIR . 'includes/class-database.php';
require_once AMM_PLUGIN_DIR . 'includes/class-medications.php';
require_once AMM_PLUGIN_DIR . 'includes/class-adherence.php';
require_once AMM_PLUGIN_DIR . 'includes/class-doses.php'; // NEW
require_once AMM_PLUGIN_DIR . 'includes/class-alerts.php';
require_once AMM_PLUGIN_DIR . 'includes/class-symptoms.php';
require_once AMM_PLUGIN_DIR . 'includes/class-timezone.php';
require_once AMM_PLUGIN_DIR . 'includes/class-onesignal.php';
require_once AMM_PLUGIN_DIR . 'includes/class-cron.php';
require_once AMM_PLUGIN_DIR . 'includes/class-ajax.php';
require_once AMM_PLUGIN_DIR . 'includes/class-shortcodes.php';
require_once AMM_PLUGIN_DIR . 'admin/class-admin.php';
require_once AMM_PLUGIN_DIR . 'admin/class-admin-diagnostics.php';

// Initialize plugin
class Autoanosis_Medical_Memory {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Check for database updates
        add_action('plugins_loaded', array($this, 'check_db_version'));
        
        // Initialize admin EARLY - before admin_menu hook fires
        if (is_admin()) {
            AMM_Admin::init();
        }
        
        // Initialize components
        add_action('init', array($this, 'init'));
        
        // Enqueue scripts
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_head', array($this, 'add_onesignal_script'));
    }
    
    public function activate() {
        // Create/update database tables
        AMM_Database::create_tables();
        
        // Schedule cron events
        AMM_Cron::schedule_events();
        
        // Generate doses for existing medications
        $this->generate_initial_doses();
        
        flush_rewrite_rules();
        
        // Set database version
        update_option('amm_db_version', AMM_DB_VERSION);
    }
    
    public function deactivate() {
        AMM_Cron::deactivate();
    }
    
    public function check_db_version() {
        $current_version = get_option('amm_db_version', '0');
        
        if (version_compare($current_version, AMM_DB_VERSION, '<')) {
            // Database needs update
            AMM_Database::create_tables();
            update_option('amm_db_version', AMM_DB_VERSION);
            
            // Regenerate doses if upgrading from old version
            if (version_compare($current_version, '12.0', '<')) {
                $this->generate_initial_doses();
            }
        }
    }
    
    private function generate_initial_doses() {
        // Generate doses for all active medications
        $medications = AMM_Medications::get_all_active();
        
        foreach ($medications as $med) {
            AMM_Doses::generate_doses_for_medication($med->id, 30);
        }
    }
    
    public function init() {
        AMM_Cron::init();
        AMM_Ajax::init();
        AMM_Shortcodes::init();
    }
    
    public function enqueue_scripts() {
        if (is_page('my-medications') || has_shortcode(get_post()->post_content ?? '', 'amm_my_medications')) {
            wp_enqueue_style(
                'amm-dashboard',
                AMM_PLUGIN_URL . 'public/assets/css/dashboard.css',
                array(),
                AMM_VERSION
            );
            
            wp_enqueue_script(
                'amm-dashboard',
                AMM_PLUGIN_URL . 'public/assets/js/dashboard.js',
                array('jquery'),
                AMM_VERSION,
                true
            );
            
            wp_localize_script('amm-dashboard', 'ammData', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('amm_nonce'),
                'user_id' => get_current_user_id()
            ));
        }
    }
    
    public function add_onesignal_script() {
        if (is_page('my-medications') || has_shortcode(get_post()->post_content ?? '', 'amm_my_medications')) {
            echo AMM_OneSignal::get_init_script();
        }
    }
}

// Initialize plugin
Autoanosis_Medical_Memory::get_instance();

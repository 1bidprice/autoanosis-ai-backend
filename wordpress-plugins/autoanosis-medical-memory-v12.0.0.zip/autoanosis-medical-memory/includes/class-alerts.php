<?php
/**
 * Alerts class - manages user notifications
 * Uses existing tkc_mm_alerts table
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Alerts {
    
    /**
     * Create new alert
     */
    public static function create($patient_id, $type, $message, $severity = 'info') {
        global $wpdb;
        $table = AMM_Database::table('alerts');
        
        // Check for duplicate in last 5 minutes
        $recent = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} 
             WHERE patient_id = %d 
             AND alert_type = %s 
             AND message = %s
             AND created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)",
            $patient_id, $type, $message
        ));
        
        if ($recent) {
            return $recent; // Return existing alert ID
        }
        
        $result = $wpdb->insert($table, array(
            'patient_id' => intval($patient_id),
            'alert_type' => sanitize_text_field($type),
            'message' => sanitize_text_field($message),
            'severity' => sanitize_text_field($severity),
            'is_read' => 0,
            'created_at' => current_time('mysql')
        ), array('%d', '%s', '%s', '%s', '%d', '%s'));
        
        return $result ? $wpdb->insert_id : false;
    }
    
    /**
     * Get alerts for patient
     */
    public static function get_by_patient($patient_id, $unread_only = false, $limit = 20) {
        global $wpdb;
        $table = AMM_Database::table('alerts');
        
        $sql = "SELECT * FROM {$table} WHERE patient_id = %d";
        if ($unread_only) {
            $sql .= " AND is_read = 0";
        }
        $sql .= " ORDER BY created_at DESC LIMIT %d";
        
        return $wpdb->get_results($wpdb->prepare($sql, $patient_id, $limit));
    }
    
    /**
     * Get unread count
     */
    public static function get_unread_count($patient_id) {
        global $wpdb;
        $table = AMM_Database::table('alerts');
        
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE patient_id = %d AND is_read = 0",
            $patient_id
        ));
    }
    
    /**
     * Mark alert as read
     */
    public static function mark_read($alert_id) {
        global $wpdb;
        $table = AMM_Database::table('alerts');
        
        return $wpdb->update(
            $table,
            array('is_read' => 1),
            array('id' => $alert_id),
            array('%d'),
            array('%d')
        );
    }
    
    /**
     * Mark all alerts as read for patient
     */
    public static function mark_all_read($patient_id) {
        global $wpdb;
        $table = AMM_Database::table('alerts');
        
        return $wpdb->update(
            $table,
            array('is_read' => 1),
            array('patient_id' => $patient_id, 'is_read' => 0),
            array('%d'),
            array('%d', '%d')
        );
    }
}

<?php
/**
 * Symptoms class - tracks patient symptoms
 * Uses existing tkc_mm_symptoms table
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Symptoms {
    
    /**
     * Log new symptom
     */
    public static function log($patient_id, $type, $severity, $description = '') {
        global $wpdb;
        $table = AMM_Database::table('symptoms');
        
        $result = $wpdb->insert($table, array(
            'patient_id' => intval($patient_id),
            'symptom_type' => sanitize_text_field($type),
            'severity' => intval($severity),
            'description' => sanitize_textarea_field($description),
            'logged_at' => current_time('mysql')
        ), array('%d', '%s', '%d', '%s', '%s'));
        
        if ($result) {
            $symptom_id = $wpdb->insert_id;
            
            // Create alert for severe symptoms (severity >= 4)
            if ($severity >= 4) {
                $user = get_user_by('id', $patient_id);
                $username = $user ? $user->display_name : 'Patient';
                AMM_Alerts::create(
                    $patient_id,
                    'severe_symptom',
                    sprintf('%s reported severe %s (severity: %d/5)', $username, $type, $severity),
                    'critical'
                );
            }
            
            return $symptom_id;
        }
        
        return false;
    }
    
    /**
     * Get symptoms for patient
     */
    public static function get_by_patient($patient_id, $limit = 20) {
        global $wpdb;
        $table = AMM_Database::table('symptoms');
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} 
             WHERE patient_id = %d 
             ORDER BY logged_at DESC 
             LIMIT %d",
            $patient_id, $limit
        ));
    }
    
    /**
     * Get recent symptoms (last X days)
     */
    public static function get_recent($patient_id, $days = 7) {
        global $wpdb;
        $table = AMM_Database::table('symptoms');
        
        $start_date = date('Y-m-d 00:00:00', strtotime("-{$days} days"));
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} 
             WHERE patient_id = %d 
             AND logged_at >= %s
             ORDER BY logged_at DESC",
            $patient_id, $start_date
        ));
    }
}

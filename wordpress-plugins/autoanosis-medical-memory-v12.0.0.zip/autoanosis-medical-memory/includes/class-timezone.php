<?php
/**
 * Timezone class - handles user timezone detection and conversion
 * Supports travel mode for patients traveling to different countries
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Timezone {
    
    /**
     * User meta keys
     */
    const META_HOME_TIMEZONE = 'amm_home_timezone';
    const META_CURRENT_TIMEZONE = 'amm_current_timezone';
    const META_TRAVEL_MODE = 'amm_travel_mode';
    const META_TIMEZONE_UPDATED = 'amm_timezone_updated';
    
    /**
     * Initialize timezone hooks
     */
    public static function init() {
        add_action('wp_ajax_amm_update_timezone', array(__CLASS__, 'ajax_update_timezone'));
        add_action('wp_ajax_amm_toggle_travel_mode', array(__CLASS__, 'ajax_toggle_travel_mode'));
        add_action('wp_ajax_amm_detect_timezone', array(__CLASS__, 'ajax_detect_timezone'));
    }
    
    /**
     * Get user's home timezone (where they normally live)
     */
    public static function get_home_timezone($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        $timezone = get_user_meta($user_id, self::META_HOME_TIMEZONE, true);
        
        // Default to WordPress timezone if not set
        if (empty($timezone)) {
            $timezone = wp_timezone_string();
        }
        
        return $timezone;
    }
    
    /**
     * Get user's current timezone (may differ if traveling)
     */
    public static function get_current_timezone($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        $travel_mode = self::is_travel_mode($user_id);
        
        if ($travel_mode) {
            $current = get_user_meta($user_id, self::META_CURRENT_TIMEZONE, true);
            if (!empty($current)) {
                return $current;
            }
        }
        
        return self::get_home_timezone($user_id);
    }
    
    /**
     * Check if travel mode is enabled
     */
    public static function is_travel_mode($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        return get_user_meta($user_id, self::META_TRAVEL_MODE, true) === '1';
    }
    
    /**
     * Set user's home timezone
     */
    public static function set_home_timezone($user_id, $timezone) {
        if (!self::is_valid_timezone($timezone)) {
            return false;
        }
        
        update_user_meta($user_id, self::META_HOME_TIMEZONE, $timezone);
        update_user_meta($user_id, self::META_TIMEZONE_UPDATED, current_time('mysql'));
        
        // If not in travel mode, also update current timezone
        if (!self::is_travel_mode($user_id)) {
            update_user_meta($user_id, self::META_CURRENT_TIMEZONE, $timezone);
        }
        
        return true;
    }
    
    /**
     * Set user's current timezone (for travel mode)
     */
    public static function set_current_timezone($user_id, $timezone) {
        if (!self::is_valid_timezone($timezone)) {
            return false;
        }
        
        update_user_meta($user_id, self::META_CURRENT_TIMEZONE, $timezone);
        update_user_meta($user_id, self::META_TIMEZONE_UPDATED, current_time('mysql'));
        
        return true;
    }
    
    /**
     * Enable/disable travel mode
     */
    public static function set_travel_mode($user_id, $enabled, $travel_timezone = null) {
        update_user_meta($user_id, self::META_TRAVEL_MODE, $enabled ? '1' : '0');
        
        if ($enabled && $travel_timezone) {
            self::set_current_timezone($user_id, $travel_timezone);
        } else if (!$enabled) {
            // Reset current timezone to home timezone
            $home = self::get_home_timezone($user_id);
            update_user_meta($user_id, self::META_CURRENT_TIMEZONE, $home);
        }
        
        return true;
    }
    
    /**
     * Validate timezone string
     */
    public static function is_valid_timezone($timezone) {
        try {
            new DateTimeZone($timezone);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Convert time from user's home timezone to UTC
     * Used when storing medication times
     */
    public static function home_to_utc($time_string, $user_id = null) {
        $home_tz = self::get_home_timezone($user_id);
        
        try {
            $dt = new DateTime($time_string, new DateTimeZone($home_tz));
            $dt->setTimezone(new DateTimeZone('UTC'));
            return $dt->format('Y-m-d H:i:s');
        } catch (Exception $e) {
            return $time_string;
        }
    }
    
    /**
     * Convert time from UTC to user's current timezone
     * Used when displaying medication times
     */
    public static function utc_to_current($time_string, $user_id = null) {
        $current_tz = self::get_current_timezone($user_id);
        
        try {
            $dt = new DateTime($time_string, new DateTimeZone('UTC'));
            $dt->setTimezone(new DateTimeZone($current_tz));
            return $dt->format('Y-m-d H:i:s');
        } catch (Exception $e) {
            return $time_string;
        }
    }
    
    /**
     * Get the time difference between home and current timezone
     * Returns offset in hours (positive = ahead, negative = behind)
     */
    public static function get_timezone_offset($user_id = null) {
        $home_tz = self::get_home_timezone($user_id);
        $current_tz = self::get_current_timezone($user_id);
        
        try {
            $home = new DateTimeZone($home_tz);
            $current = new DateTimeZone($current_tz);
            $now = new DateTime('now', new DateTimeZone('UTC'));
            
            $home_offset = $home->getOffset($now);
            $current_offset = $current->getOffset($now);
            
            return ($current_offset - $home_offset) / 3600; // Convert seconds to hours
        } catch (Exception $e) {
            return 0;
        }
    }
    
    /**
     * Get user's timezone info for display
     */
    public static function get_timezone_info($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        $home_tz = self::get_home_timezone($user_id);
        $current_tz = self::get_current_timezone($user_id);
        $travel_mode = self::is_travel_mode($user_id);
        $offset = self::get_timezone_offset($user_id);
        
        return array(
            'home_timezone' => $home_tz,
            'current_timezone' => $current_tz,
            'travel_mode' => $travel_mode,
            'offset_hours' => $offset,
            'home_time' => self::get_time_in_timezone($home_tz),
            'current_time' => self::get_time_in_timezone($current_tz),
            'home_label' => self::get_timezone_label($home_tz),
            'current_label' => self::get_timezone_label($current_tz)
        );
    }
    
    /**
     * Get current time in a specific timezone
     */
    public static function get_time_in_timezone($timezone) {
        try {
            $dt = new DateTime('now', new DateTimeZone($timezone));
            return $dt->format('H:i');
        } catch (Exception $e) {
            return '--:--';
        }
    }
    
    /**
     * Get human-readable timezone label
     */
    public static function get_timezone_label($timezone) {
        try {
            $tz = new DateTimeZone($timezone);
            $dt = new DateTime('now', $tz);
            $offset = $tz->getOffset($dt);
            $hours = floor(abs($offset) / 3600);
            $minutes = floor((abs($offset) % 3600) / 60);
            $sign = $offset >= 0 ? '+' : '-';
            
            // Get city name from timezone
            $parts = explode('/', $timezone);
            $city = end($parts);
            $city = str_replace('_', ' ', $city);
            
            return sprintf('%s (UTC%s%02d:%02d)', $city, $sign, $hours, $minutes);
        } catch (Exception $e) {
            return $timezone;
        }
    }
    
    /**
     * Get list of common timezones for dropdown
     */
    public static function get_timezone_list() {
        $timezones = array();
        $regions = array(
            'Europe' => DateTimeZone::EUROPE,
            'America' => DateTimeZone::AMERICA,
            'Asia' => DateTimeZone::ASIA,
            'Africa' => DateTimeZone::AFRICA,
            'Pacific' => DateTimeZone::PACIFIC,
            'Australia' => DateTimeZone::AUSTRALIA
        );
        
        foreach ($regions as $region => $mask) {
            $zones = DateTimeZone::listIdentifiers($mask);
            foreach ($zones as $zone) {
                $timezones[$zone] = self::get_timezone_label($zone);
            }
        }
        
        return $timezones;
    }
    
    /**
     * AJAX: Update user timezone
     */
    public static function ajax_update_timezone() {
        check_ajax_referer('amm_nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error('Not logged in');
        }
        
        $user_id = get_current_user_id();
        $timezone = sanitize_text_field($_POST['timezone']);
        $type = sanitize_text_field($_POST['type']); // 'home' or 'current'
        
        if (!self::is_valid_timezone($timezone)) {
            wp_send_json_error('Invalid timezone');
        }
        
        if ($type === 'home') {
            self::set_home_timezone($user_id, $timezone);
        } else {
            self::set_current_timezone($user_id, $timezone);
        }
        
        wp_send_json_success(self::get_timezone_info($user_id));
    }
    
    /**
     * AJAX: Toggle travel mode
     */
    public static function ajax_toggle_travel_mode() {
        check_ajax_referer('amm_nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error('Not logged in');
        }
        
        $user_id = get_current_user_id();
        $enabled = isset($_POST['enabled']) && $_POST['enabled'] === 'true';
        $travel_timezone = isset($_POST['timezone']) ? sanitize_text_field($_POST['timezone']) : null;
        
        self::set_travel_mode($user_id, $enabled, $travel_timezone);
        
        wp_send_json_success(self::get_timezone_info($user_id));
    }
    
    /**
     * AJAX: Detect timezone from browser
     */
    public static function ajax_detect_timezone() {
        check_ajax_referer('amm_nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error('Not logged in');
        }
        
        $user_id = get_current_user_id();
        $detected_timezone = sanitize_text_field($_POST['timezone']);
        
        if (!self::is_valid_timezone($detected_timezone)) {
            wp_send_json_error('Invalid timezone');
        }
        
        // Check if this is different from home timezone
        $home_tz = self::get_home_timezone($user_id);
        $is_different = ($detected_timezone !== $home_tz);
        
        // If first time, set as home timezone
        $has_home = get_user_meta($user_id, self::META_HOME_TIMEZONE, true);
        if (empty($has_home)) {
            self::set_home_timezone($user_id, $detected_timezone);
            $is_different = false;
        }
        
        // Always update current timezone
        self::set_current_timezone($user_id, $detected_timezone);
        
        wp_send_json_success(array(
            'detected' => $detected_timezone,
            'is_different' => $is_different,
            'suggest_travel_mode' => $is_different,
            'info' => self::get_timezone_info($user_id)
        ));
    }
}

<?php
/**
 * Adherence class - tracks medication doses
 * Uses existing tkc_mm_adherence table
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Adherence {
    
    /**
     * Mark dose as taken
     */
    public static function mark_taken($dose_id, $notes = '') {
        global $wpdb;
        $table = AMM_Database::table('adherence');
        
        return $wpdb->update(
            $table,
            array(
                'status' => 'taken',
                'taken_time' => current_time('mysql'),
                'notes' => sanitize_textarea_field($notes)
            ),
            array('id' => $dose_id),
            array('%s', '%s', '%s'),
            array('%d')
        );
    }
    
    /**
     * Mark dose as skipped
     */
    public static function mark_skipped($dose_id, $notes = '') {
        global $wpdb;
        $table = AMM_Database::table('adherence');
        
        return $wpdb->update(
            $table,
            array(
                'status' => 'skipped',
                'notes' => sanitize_textarea_field($notes)
            ),
            array('id' => $dose_id),
            array('%s', '%s'),
            array('%d')
        );
    }
    
    /**
     * Mark dose as missed (called by cron)
     */
    public static function mark_missed($dose_id) {
        global $wpdb;
        $table = AMM_Database::table('adherence');
        
        return $wpdb->update(
            $table,
            array('status' => 'missed'),
            array('id' => $dose_id),
            array('%s'),
            array('%d')
        );
    }
    
    /**
     * Get dose by ID
     */
    public static function get($dose_id) {
        global $wpdb;
        $table = AMM_Database::table('adherence');
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            $dose_id
        ));
    }
    
    /**
     * Get pending doses that are overdue (for cron)
     */
    public static function get_overdue_doses($minutes = 60) {
        global $wpdb;
        $table = AMM_Database::table('adherence');
        $medications_table = AMM_Database::table('medications');
        
        $cutoff = date('Y-m-d H:i:s', strtotime("-{$minutes} minutes", current_time('timestamp')));
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, m.medication_name, m.patient_id
             FROM {$table} a
             JOIN {$medications_table} m ON a.medication_id = m.id
             WHERE a.status = 'pending'
             AND a.scheduled_time < %s
             AND m.active = 1",
            $cutoff
        ));
    }
    
    /**
     * Get due doses (within next X minutes)
     */
    public static function get_due_doses($minutes = 5) {
        global $wpdb;
        $table = AMM_Database::table('adherence');
        $medications_table = AMM_Database::table('medications');
        
        $now = current_time('mysql');
        $future = date('Y-m-d H:i:s', strtotime("+{$minutes} minutes", current_time('timestamp')));
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, m.medication_name, m.dosage, m.instructions, m.patient_id
             FROM {$table} a
             JOIN {$medications_table} m ON a.medication_id = m.id
             WHERE a.status = 'pending'
             AND a.scheduled_time BETWEEN %s AND %s
             AND m.active = 1",
            $now, $future
        ));
    }
    
    /**
     * Get adherence statistics for patient
     */
    public static function get_stats($patient_id, $days = 7) {
        global $wpdb;
        $table = AMM_Database::table('adherence');
        
        $start_date = date('Y-m-d 00:00:00', strtotime("-{$days} days"));
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'taken' THEN 1 ELSE 0 END) as taken,
                SUM(CASE WHEN status = 'missed' THEN 1 ELSE 0 END) as missed,
                SUM(CASE WHEN status = 'skipped' THEN 1 ELSE 0 END) as skipped,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
             FROM {$table}
             WHERE patient_id = %d
             AND scheduled_time >= %s",
            $patient_id, $start_date
        ));
        
        // Calculate adherence rate
        $completed = $stats->taken + $stats->missed + $stats->skipped;
        $stats->adherence_rate = $completed > 0 ? round(($stats->taken / $completed) * 100) : 0;
        
        return $stats;
    }
}

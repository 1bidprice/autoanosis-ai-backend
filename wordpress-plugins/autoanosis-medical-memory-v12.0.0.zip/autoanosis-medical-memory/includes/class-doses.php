<?php
/**
 * Doses class - v12.0.0 (NEW)
 * Manages individual dose instances with generation and atomic locking
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Doses {
    
    /**
     * Generate doses for a medication
     * 
     * @param int $medication_id Medication ID
     * @param int $days_ahead Number of days to generate (default 30)
     * @return int Number of doses generated
     */
    public static function generate_doses_for_medication($medication_id, $days_ahead = 30) {
        global $wpdb;
        
        $medication = AMM_Medications::get($medication_id);
        
        if (!$medication || !$medication->active) {
            return 0;
        }
        
        // Parse time slots
        $time_slots = json_decode($medication->time_slots, true);
        if (empty($time_slots) || !is_array($time_slots)) {
            return 0;
        }
        
        // Get Athens timezone
        $athens_tz = new DateTimeZone('Europe/Athens');
        $start_date = new DateTime($medication->start_date, $athens_tz);
        $today = new DateTime('today', $athens_tz);
        
        // Start from today or medication start date, whichever is later
        if ($start_date > $today) {
            $current_date = clone $start_date;
        } else {
            $current_date = clone $today;
        }
        
        // End date
        $end_date = clone $current_date;
        $end_date->modify("+{$days_ahead} days");
        
        // If medication has end_date, don't generate beyond it
        if ($medication->end_date) {
            $med_end_date = new DateTime($medication->end_date, $athens_tz);
            if ($med_end_date < $end_date) {
                $end_date = $med_end_date;
            }
        }
        
        $doses_generated = 0;
        $doses_table = AMM_Database::get_table_name('doses');
        
        // Generate doses for each day
        while ($current_date <= $end_date) {
            $dose_date = $current_date->format('Y-m-d');
            
            // Generate dose for each time slot
            foreach ($time_slots as $time_slot) {
                // Parse time (format: "HH:MM" or "HH:MM:SS")
                $time_parts = explode(':', $time_slot);
                $hour = intval($time_parts[0]);
                $minute = intval($time_parts[1]);
                
                // Create due_at datetime
                $due_at = clone $current_date;
                $due_at->setTime($hour, $minute, 0);
                
                // Skip if in the past
                $now = new DateTime('now', $athens_tz);
                if ($due_at < $now) {
                    continue;
                }
                
                // Generate unique key
                $unique_key = self::generate_unique_key(
                    $medication->patient_id,
                    $medication_id,
                    $due_at
                );
                
                // Insert dose (ignore if duplicate)
                $result = $wpdb->query($wpdb->prepare(
                    "INSERT IGNORE INTO $doses_table 
                    (medication_id, user_id, dose_date, dose_time, due_at, status, unique_key, created_at)
                    VALUES (%d, %d, %s, %s, %s, 'pending', %s, NOW())",
                    $medication_id,
                    $medication->patient_id,
                    $dose_date,
                    $time_slot,
                    $due_at->format('Y-m-d H:i:s'),
                    $unique_key
                ));
                
                if ($result) {
                    $doses_generated++;
                }
            }
            
            // Move to next day
            $current_date->modify('+1 day');
        }
        
        return $doses_generated;
    }
    
    /**
     * Generate unique key for dose
     * Format: userId-medId-YYYYMMDD-HHMM
     */
    public static function generate_unique_key($user_id, $medication_id, $due_at) {
        if ($due_at instanceof DateTime) {
            $due_at_str = $due_at->format('Ymd-Hi');
        } else {
            $due_at_str = date('Ymd-Hi', strtotime($due_at));
        }
        
        return sprintf('%d-%d-%s', $user_id, $medication_id, $due_at_str);
    }
    
    /**
     * Get pending doses within time window
     * 
     * @param DateTime $window_start Start of time window
     * @param DateTime $window_end End of time window
     * @return array Array of dose objects
     */
    public static function get_pending_doses_in_window($window_start, $window_end) {
        global $wpdb;
        
        $doses_table = AMM_Database::get_table_name('doses');
        $medications_table = AMM_Database::get_table_name('medications');
        
        $sql = $wpdb->prepare(
            "SELECT d.*, m.medication_name, m.dosage, m.instructions
             FROM $doses_table d
             JOIN $medications_table m ON d.medication_id = m.id
             WHERE d.status = 'pending'
             AND m.active = 1
             AND d.due_at BETWEEN %s AND %s
             ORDER BY d.due_at ASC",
            $window_start->format('Y-m-d H:i:s'),
            $window_end->format('Y-m-d H:i:s')
        );
        
        return $wpdb->get_results($sql);
    }
    
    /**
     * Atomically claim a dose for sending
     * Returns true if successfully claimed, false if already claimed by another worker
     * 
     * @param int $dose_id Dose ID
     * @return bool True if claimed, false otherwise
     */
    public static function claim_dose_for_sending($dose_id) {
        global $wpdb;
        
        $doses_table = AMM_Database::get_table_name('doses');
        
        // Atomic update: only succeeds if status is 'pending'
        $rows_affected = $wpdb->query($wpdb->prepare(
            "UPDATE $doses_table
             SET status = 'sending',
                 attempts = attempts + 1,
                 updated_at = NOW()
             WHERE id = %d
             AND status = 'pending'",
            $dose_id
        ));
        
        return ($rows_affected > 0);
    }
    
    /**
     * Mark dose as sent
     */
    public static function mark_as_sent($dose_id, $onesignal_notification_id = null, $onesignal_response = null) {
        global $wpdb;
        
        $doses_table = AMM_Database::get_table_name('doses');
        
        $wpdb->update(
            $doses_table,
            array(
                'status' => 'sent',
                'sent_at' => current_time('mysql'),
                'onesignal_notification_id' => $onesignal_notification_id,
                'onesignal_response' => is_array($onesignal_response) ? wp_json_encode($onesignal_response) : $onesignal_response,
                'updated_at' => current_time('mysql')
            ),
            array('id' => $dose_id),
            array('%s', '%s', '%s', '%s', '%s'),
            array('%d')
        );
    }
    
    /**
     * Mark dose as failed
     */
    public static function mark_as_failed($dose_id, $error_message = null) {
        global $wpdb;
        
        $doses_table = AMM_Database::get_table_name('doses');
        
        // Get current attempts
        $dose = $wpdb->get_row($wpdb->prepare(
            "SELECT attempts FROM $doses_table WHERE id = %d",
            $dose_id
        ));
        
        // If attempts >= 3, mark as failed permanently, otherwise back to pending for retry
        $new_status = ($dose && $dose->attempts >= 3) ? 'failed' : 'pending';
        
        $wpdb->update(
            $doses_table,
            array(
                'status' => $new_status,
                'last_error' => $error_message,
                'updated_at' => current_time('mysql')
            ),
            array('id' => $dose_id),
            array('%s', '%s', '%s'),
            array('%d')
        );
    }
    
    /**
     * Mark dose as taken (user confirmed)
     */
    public static function mark_as_taken($dose_id) {
        global $wpdb;
        
        $doses_table = AMM_Database::get_table_name('doses');
        
        $wpdb->update(
            $doses_table,
            array(
                'status' => 'taken',
                'taken_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ),
            array('id' => $dose_id),
            array('%s', '%s', '%s'),
            array('%d')
        );
    }
    
    /**
     * Get dose statistics for user
     */
    public static function get_user_stats($user_id, $days = 7) {
        global $wpdb;
        
        $doses_table = AMM_Database::get_table_name('doses');
        
        $since_date = date('Y-m-d', strtotime("-{$days} days"));
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_doses,
                SUM(CASE WHEN status = 'taken' THEN 1 ELSE 0 END) as taken,
                SUM(CASE WHEN status = 'missed' THEN 1 ELSE 0 END) as missed,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent
             FROM $doses_table
             WHERE user_id = %d
             AND dose_date >= %s",
            $user_id,
            $since_date
        ));
        
        return $stats;
    }
    
    /**
     * Clean up old doses (older than 90 days)
     */
    public static function cleanup_old_doses() {
        global $wpdb;
        
        $doses_table = AMM_Database::get_table_name('doses');
        
        $cutoff_date = date('Y-m-d', strtotime('-90 days'));
        
        $deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM $doses_table WHERE dose_date < %s",
            $cutoff_date
        ));
        
        return $deleted;
    }
    
    /**
     * Regenerate doses for all active medications
     * Used for daily top-up
     */
    public static function regenerate_all_doses($days_ahead = 30) {
        $medications = AMM_Medications::get_all_active();
        
        $total_generated = 0;
        foreach ($medications as $med) {
            $generated = self::generate_doses_for_medication($med->id, $days_ahead);
            $total_generated += $generated;
        }
        
        return $total_generated;
    }
}

<?php
/**
 * Medications class - CRUD operations for medications
 * Version 10.0.0 - Push-Only Professional Edition
 * Uses existing tkc_mm_medications table
 * NOTE: Includes proper date format conversion (d/m/Y → Y-m-d)
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Medications {
    
    /**
     * Get all active medications (all users)
     */
    public static function get_all_active() {
        global $wpdb;
        $table = AMM_Database::table('medications');
        
        return $wpdb->get_results(
            "SELECT * FROM {$table} WHERE active = 1 ORDER BY medication_name ASC"
        );
    }
    
    /**
     * Get all medications for a patient
     */
    public static function get_by_patient($patient_id, $active_only = true) {
        global $wpdb;
        $table = AMM_Database::table('medications');
        
        $sql = "SELECT * FROM {$table} WHERE patient_id = %d";
        if ($active_only) {
            $sql .= " AND active = 1";
        }
        $sql .= " ORDER BY medication_name ASC";
        
        return $wpdb->get_results($wpdb->prepare($sql, $patient_id));
    }
    
    /**
     * Get single medication
     */
    public static function get($id) {
        global $wpdb;
        $table = AMM_Database::table('medications');
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            $id
        ));
    }
    
    /**
     * Parse date from various formats to Y-m-d
     * Supports: d/m/Y, d-m-Y, Y-m-d
     * Returns false on parse failure
     */
    private static function parse_date($date_string) {
        if (empty($date_string)) {
            return null;
        }
        
        $date_string = trim($date_string);
        
        // Already in correct format
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_string)) {
            return $date_string;
        }
        
        // Try d/m/Y format (European)
        $date = DateTime::createFromFormat('d/m/Y', $date_string);
        if ($date !== false) {
            return $date->format('Y-m-d');
        }
        
        // Try d-m-Y format
        $date = DateTime::createFromFormat('d-m-Y', $date_string);
        if ($date !== false) {
            return $date->format('Y-m-d');
        }
        
        // Try m/d/Y format (US)
        $date = DateTime::createFromFormat('m/d/Y', $date_string);
        if ($date !== false) {
            return $date->format('Y-m-d');
        }
        
        return false;
    }
    
    /**
     * Validate time format (HH:MM)
     */
    private static function validate_time($time_string) {
        return preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/', trim($time_string));
    }
    
    /**
     * Add new medication
     * Time slots are stored in user's HOME timezone
     * CRITICAL: Dates are converted from d/m/Y to Y-m-d
     */
    public static function add($data) {
        global $wpdb;
        $table = AMM_Database::table('medications');
        
        // Parse and validate start_date (REQUIRED)
        $start_date = self::parse_date($data['start_date']);
        if ($start_date === false) {
            return new WP_Error('invalid_date', 'Λάθος μορφή ημερομηνίας έναρξης. Χρησιμοποιήστε dd/mm/yyyy.');
        }
        if (empty($start_date)) {
            return new WP_Error('missing_date', 'Η ημερομηνία έναρξης είναι υποχρεωτική.');
        }
        
        // Parse end_date (OPTIONAL)
        $end_date = null;
        if (!empty($data['end_date'])) {
            $end_date = self::parse_date($data['end_date']);
            if ($end_date === false) {
                return new WP_Error('invalid_date', 'Λάθος μορφή ημερομηνίας λήξης. Χρησιμοποιήστε dd/mm/yyyy.');
            }
        }
        
        // Validate time slots
        $time_slots = isset($data['time_slots']) ? $data['time_slots'] : array();
        if (is_string($time_slots)) {
            $time_slots = json_decode($time_slots, true);
        }
        if (!is_array($time_slots)) {
            $time_slots = array();
        }
        
        // Validate each time slot
        foreach ($time_slots as $time) {
            if (!self::validate_time($time)) {
                return new WP_Error('invalid_time', 'Λάθος μορφή ώρας. Χρησιμοποιήστε HH:MM (π.χ. 09:00).');
            }
        }
        
        $time_slots_json = wp_json_encode($time_slots);
        
        $result = $wpdb->insert($table, array(
            'patient_id' => intval($data['patient_id']),
            'medication_name' => sanitize_text_field($data['medication_name']),
            'dosage' => sanitize_text_field($data['dosage']),
            'frequency' => sanitize_text_field($data['frequency']),
            'time_slots' => $time_slots_json,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'instructions' => sanitize_textarea_field($data['instructions']),
            'active' => 1,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ), array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s'));
        
        if ($result) {
            $medication_id = $wpdb->insert_id;
            // Generate adherence records for the next 7 days
            self::generate_adherence_records($medication_id);
            
            // v12: Generate dose instances for next 30 days
            if (class_exists('AMM_Doses')) {
                AMM_Doses::generate_doses_for_medication($medication_id, 30);
            }
            
            return $medication_id;
        }
        
        return false;
    }
    
    /**
     * Update medication
     * CRITICAL: Dates are converted from d/m/Y to Y-m-d
     */
    public static function update($id, $data) {
        global $wpdb;
        $table = AMM_Database::table('medications');
        
        $update_data = array(
            'updated_at' => current_time('mysql')
        );
        $format = array('%s');
        
        if (isset($data['medication_name'])) {
            $update_data['medication_name'] = sanitize_text_field($data['medication_name']);
            $format[] = '%s';
        }
        if (isset($data['dosage'])) {
            $update_data['dosage'] = sanitize_text_field($data['dosage']);
            $format[] = '%s';
        }
        if (isset($data['frequency'])) {
            $update_data['frequency'] = sanitize_text_field($data['frequency']);
            $format[] = '%s';
        }
        if (isset($data['time_slots'])) {
            $time_slots = is_array($data['time_slots']) ? wp_json_encode($data['time_slots']) : $data['time_slots'];
            $update_data['time_slots'] = $time_slots;
            $format[] = '%s';
        }
        if (isset($data['start_date'])) {
            $parsed_date = self::parse_date($data['start_date']);
            if ($parsed_date === false) {
                return new WP_Error('invalid_date', 'Λάθος μορφή ημερομηνίας έναρξης.');
            }
            $update_data['start_date'] = $parsed_date;
            $format[] = '%s';
        }
        if (isset($data['end_date'])) {
            if (!empty($data['end_date'])) {
                $parsed_date = self::parse_date($data['end_date']);
                if ($parsed_date === false) {
                    return new WP_Error('invalid_date', 'Λάθος μορφή ημερομηνίας λήξης.');
                }
                $update_data['end_date'] = $parsed_date;
            } else {
                $update_data['end_date'] = null;
            }
            $format[] = '%s';
        }
        if (isset($data['instructions'])) {
            $update_data['instructions'] = sanitize_textarea_field($data['instructions']);
            $format[] = '%s';
        }
        if (isset($data['active'])) {
            $update_data['active'] = intval($data['active']);
            $format[] = '%d';
        }
        
        $result = $wpdb->update($table, $update_data, array('id' => $id), $format, array('%d'));
        
        if ($result !== false) {
            // v12: Regenerate dose instances
            if (class_exists('AMM_Doses')) {
                // Delete future pending doses for this medication
                $doses_table = AMM_Database::get_table_name('doses');
                $wpdb->query($wpdb->prepare(
                    "DELETE FROM $doses_table WHERE medication_id = %d AND status = 'pending' AND due_at > NOW()",
                    $id
                ));
                
                // Generate new doses
                AMM_Doses::generate_doses_for_medication($id, 30);
            }
        }
        
        return $result;
    }
    
    /**
     * Delete medication (soft delete - set active = 0)
     */
    public static function delete($id) {
        return self::update($id, array('active' => 0));
    }
    
    /**
     * Generate adherence records for medication
     * Times are stored in user's HOME timezone
     */
    public static function generate_adherence_records($medication_id, $days = 7) {
        global $wpdb;
        
        $medication = self::get($medication_id);
        if (!$medication || !$medication->active) {
            return false;
        }
        
        $time_slots = json_decode($medication->time_slots, true);
        if (empty($time_slots) || !is_array($time_slots)) {
            return false;
        }
        
        $adherence_table = AMM_Database::table('adherence');
        $today = current_time('Y-m-d');
        $end_date = $medication->end_date ? $medication->end_date : date('Y-m-d', strtotime("+{$days} days"));
        
        // Don't generate past end_date
        if ($end_date < $today) {
            return false;
        }
        
        $current_date = $today;
        $records_created = 0;
        
        for ($i = 0; $i < $days; $i++) {
            $date = date('Y-m-d', strtotime("+{$i} days", strtotime($today)));
            
            // Skip if past end_date
            if ($medication->end_date && $date > $medication->end_date) {
                break;
            }
            
            // Skip if before start_date
            if ($date < $medication->start_date) {
                continue;
            }
            
            foreach ($time_slots as $time) {
                // Store scheduled_time in HOME timezone
                $scheduled_time = $date . ' ' . $time . ':00';
                
                // Check if record already exists
                $exists = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$adherence_table} 
                     WHERE medication_id = %d AND scheduled_time = %s",
                    $medication_id, $scheduled_time
                ));
                
                if (!$exists) {
                    $wpdb->insert($adherence_table, array(
                        'medication_id' => $medication_id,
                        'patient_id' => $medication->patient_id,
                        'scheduled_time' => $scheduled_time,
                        'status' => 'pending',
                        'created_at' => current_time('mysql')
                    ), array('%d', '%d', '%s', '%s', '%s'));
                    $records_created++;
                }
            }
        }
        
        return $records_created;
    }
    
    /**
     * Get today's schedule for patient
     * Returns doses with times in user's HOME timezone (stored format)
     * Frontend will convert to current timezone for display
     */
    public static function get_todays_schedule($patient_id) {
        global $wpdb;
        
        $adherence_table = AMM_Database::table('adherence');
        $medications_table = AMM_Database::table('medications');
        
        $today_start = current_time('Y-m-d') . ' 00:00:00';
        $today_end = current_time('Y-m-d') . ' 23:59:59';
        
        // First, ensure today's records exist
        $medications = self::get_by_patient($patient_id, true);
        foreach ($medications as $med) {
            self::generate_adherence_records($med->id, 1);
        }
        
        // Get today's doses
        return $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, m.medication_name, m.dosage, m.instructions
             FROM {$adherence_table} a
             JOIN {$medications_table} m ON a.medication_id = m.id
             WHERE a.patient_id = %d 
             AND a.scheduled_time BETWEEN %s AND %s
             AND m.active = 1
             ORDER BY a.scheduled_time ASC",
            $patient_id, $today_start, $today_end
        ));
    }
    
    /**
     * Get schedule for a specific date range
     */
    public static function get_schedule_range($patient_id, $start_date, $end_date) {
        global $wpdb;
        
        $adherence_table = AMM_Database::table('adherence');
        $medications_table = AMM_Database::table('medications');
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, m.medication_name, m.dosage, m.instructions
             FROM {$adherence_table} a
             JOIN {$medications_table} m ON a.medication_id = m.id
             WHERE a.patient_id = %d 
             AND a.scheduled_time BETWEEN %s AND %s
             AND m.active = 1
             ORDER BY a.scheduled_time ASC",
            $patient_id, $start_date . ' 00:00:00', $end_date . ' 23:59:59'
        ));
    }
}

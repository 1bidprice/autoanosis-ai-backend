<?php
/**
 * AJAX handler class
 * Version 10.0.0 - Push-Only Professional Edition
 * NOTE: Handles WP_Error from date validation
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Ajax {
    
    public static function init() {
        // Medication actions
        add_action('wp_ajax_amm_save_medication', array(__CLASS__, 'save_medication'));
        add_action('wp_ajax_amm_add_medication', array(__CLASS__, 'add_medication'));
        add_action('wp_ajax_amm_update_medication', array(__CLASS__, 'update_medication'));
        add_action('wp_ajax_amm_delete_medication', array(__CLASS__, 'delete_medication'));
        add_action('wp_ajax_amm_get_medication', array(__CLASS__, 'get_medication'));
        
        // Dose actions
        add_action('wp_ajax_amm_mark_dose', array(__CLASS__, 'mark_dose'));
        add_action('wp_ajax_amm_mark_taken', array(__CLASS__, 'mark_taken'));
        add_action('wp_ajax_amm_mark_skipped', array(__CLASS__, 'mark_skipped'));
        
        // Symptom actions
        add_action('wp_ajax_amm_log_symptom', array(__CLASS__, 'log_symptom'));
        
        // Alert actions
        add_action('wp_ajax_amm_mark_alert_read', array(__CLASS__, 'mark_alert_read'));
        add_action('wp_ajax_amm_mark_alerts_read', array(__CLASS__, 'mark_all_alerts_read'));
        add_action('wp_ajax_amm_mark_all_alerts_read', array(__CLASS__, 'mark_all_alerts_read'));
        
        // Test actions
        add_action('wp_ajax_amm_test_push', array(__CLASS__, 'test_push'));
        
        // Timezone actions
        add_action('wp_ajax_amm_get_timezone_preview', array(__CLASS__, 'get_timezone_preview'));
    }
    
    /**
     * Verify nonce and user
     */
    private static function verify_request() {
        if (!check_ajax_referer('amm_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => 'Invalid security token'));
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in'));
        }
        
        return get_current_user_id();
    }
    
    /**
     * Save medication (add or update)
     */
    public static function save_medication() {
        $user_id = self::verify_request();
        
        $medication_id = isset($_POST['medication_id']) && !empty($_POST['medication_id']) ? intval($_POST['medication_id']) : 0;
        
        $time_slots = isset($_POST['time_slots']) ? $_POST['time_slots'] : array();
        if (is_string($time_slots)) {
            $time_slots = json_decode(stripslashes($time_slots), true);
        }
        
        $data = array(
            'patient_id' => $user_id,
            'medication_name' => sanitize_text_field($_POST['medication_name']),
            'dosage' => sanitize_text_field($_POST['dosage']),
            'frequency' => sanitize_text_field($_POST['frequency']),
            'time_slots' => $time_slots,
            'start_date' => sanitize_text_field($_POST['start_date']),
            'end_date' => isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '',
            'instructions' => isset($_POST['instructions']) ? sanitize_textarea_field($_POST['instructions']) : ''
        );
        
        if ($medication_id > 0) {
            // Update existing
            $medication = AMM_Medications::get($medication_id);
            if (!$medication || $medication->patient_id != $user_id) {
                wp_send_json_error(array('message' => 'Το φάρμακο δεν βρέθηκε'));
            }
            $result = AMM_Medications::update($medication_id, $data);
            
            // Check for WP_Error (date validation failure)
            if (is_wp_error($result)) {
                wp_send_json_error(array('message' => $result->get_error_message()));
            }
            
            AMM_Medications::generate_adherence_records($medication_id);
        } else {
            // Add new
            $result = AMM_Medications::add($data);
            
            // Check for WP_Error (date validation failure)
            if (is_wp_error($result)) {
                wp_send_json_error(array('message' => $result->get_error_message()));
            }
            
            $medication_id = $result;
        }
        
        if ($result && !is_wp_error($result)) {
            wp_send_json_success(array('medication_id' => $medication_id));
        } else {
            wp_send_json_error(array('message' => 'Αποτυχία αποθήκευσης φαρμάκου'));
        }
    }
    
    /**
     * Mark dose (taken or skipped)
     */
    public static function mark_dose() {
        $user_id = self::verify_request();
        
        $dose_id = intval($_POST['dose_id']);
        $status = sanitize_text_field($_POST['status']);
        
        $dose = AMM_Adherence::get($dose_id);
        if (!$dose || $dose->patient_id != $user_id) {
            wp_send_json_error('Dose not found');
        }
        
        if ($status === 'taken') {
            $result = AMM_Adherence::mark_taken($dose_id);
        } else {
            $result = AMM_Adherence::mark_skipped($dose_id);
        }
        
        if ($result !== false) {
            wp_send_json_success(array('message' => 'Dose updated'));
        } else {
            wp_send_json_error('Failed to update dose');
        }
    }
    
    /**
     * Add medication
     */
    public static function add_medication() {
        $user_id = self::verify_request();
        
        $time_slots = isset($_POST['time_slots']) ? $_POST['time_slots'] : array();
        if (is_string($time_slots)) {
            $time_slots = json_decode(stripslashes($time_slots), true);
        }
        
        $data = array(
            'patient_id' => $user_id,
            'medication_name' => sanitize_text_field($_POST['medication_name']),
            'dosage' => sanitize_text_field($_POST['dosage']),
            'frequency' => sanitize_text_field($_POST['frequency']),
            'time_slots' => $time_slots,
            'start_date' => sanitize_text_field($_POST['start_date']),
            'end_date' => isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '',
            'instructions' => isset($_POST['instructions']) ? sanitize_textarea_field($_POST['instructions']) : ''
        );
        
        $medication_id = AMM_Medications::add($data);
        
        if ($medication_id) {
            wp_send_json_success(array(
                'message' => 'Medication added successfully',
                'medication_id' => $medication_id
            ));
        } else {
            wp_send_json_error(array('message' => 'Failed to add medication'));
        }
    }
    
    /**
     * Update medication
     */
    public static function update_medication() {
        $user_id = self::verify_request();
        
        $medication_id = intval($_POST['medication_id']);
        $medication = AMM_Medications::get($medication_id);
        
        if (!$medication || $medication->patient_id != $user_id) {
            wp_send_json_error(array('message' => 'Medication not found'));
        }
        
        $time_slots = isset($_POST['time_slots']) ? $_POST['time_slots'] : array();
        if (is_string($time_slots)) {
            $time_slots = json_decode(stripslashes($time_slots), true);
        }
        
        $data = array(
            'medication_name' => sanitize_text_field($_POST['medication_name']),
            'dosage' => sanitize_text_field($_POST['dosage']),
            'frequency' => sanitize_text_field($_POST['frequency']),
            'time_slots' => $time_slots,
            'start_date' => sanitize_text_field($_POST['start_date']),
            'end_date' => isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '',
            'instructions' => isset($_POST['instructions']) ? sanitize_textarea_field($_POST['instructions']) : ''
        );
        
        $result = AMM_Medications::update($medication_id, $data);
        
        if ($result !== false) {
            // Regenerate adherence records
            AMM_Medications::generate_adherence_records($medication_id);
            wp_send_json_success(array('message' => 'Medication updated successfully'));
        } else {
            wp_send_json_error(array('message' => 'Failed to update medication'));
        }
    }
    
    /**
     * Delete medication
     */
    public static function delete_medication() {
        $user_id = self::verify_request();
        
        $medication_id = intval($_POST['medication_id']);
        $medication = AMM_Medications::get($medication_id);
        
        if (!$medication || $medication->patient_id != $user_id) {
            wp_send_json_error(array('message' => 'Medication not found'));
        }
        
        $result = AMM_Medications::delete($medication_id);
        
        if ($result) {
            wp_send_json_success(array('message' => 'Medication deleted successfully'));
        } else {
            wp_send_json_error(array('message' => 'Failed to delete medication'));
        }
    }
    
    /**
     * Get medication details
     */
    public static function get_medication() {
        $user_id = self::verify_request();
        
        $medication_id = intval($_POST['medication_id']);
        $medication = AMM_Medications::get($medication_id);
        
        if (!$medication || $medication->patient_id != $user_id) {
            wp_send_json_error(array('message' => 'Medication not found'));
        }
        
        // Decode time_slots
        $medication->time_slots = json_decode($medication->time_slots, true);
        
        wp_send_json_success($medication);
    }
    
    /**
     * Mark dose as taken
     */
    public static function mark_taken() {
        $user_id = self::verify_request();
        
        $dose_id = intval($_POST['dose_id']);
        $dose = AMM_Adherence::get($dose_id);
        
        if (!$dose || $dose->patient_id != $user_id) {
            wp_send_json_error(array('message' => 'Dose not found'));
        }
        
        $notes = isset($_POST['notes']) ? sanitize_textarea_field($_POST['notes']) : '';
        $result = AMM_Adherence::mark_taken($dose_id, $notes);
        
        if ($result) {
            wp_send_json_success(array('message' => 'Marked as taken'));
        } else {
            wp_send_json_error(array('message' => 'Failed to update'));
        }
    }
    
    /**
     * Mark dose as skipped
     */
    public static function mark_skipped() {
        $user_id = self::verify_request();
        
        $dose_id = intval($_POST['dose_id']);
        $dose = AMM_Adherence::get($dose_id);
        
        if (!$dose || $dose->patient_id != $user_id) {
            wp_send_json_error(array('message' => 'Dose not found'));
        }
        
        $notes = isset($_POST['notes']) ? sanitize_textarea_field($_POST['notes']) : '';
        $result = AMM_Adherence::mark_skipped($dose_id, $notes);
        
        if ($result) {
            wp_send_json_success(array('message' => 'Marked as skipped'));
        } else {
            wp_send_json_error(array('message' => 'Failed to update'));
        }
    }
    
    /**
     * Log symptom
     */
    public static function log_symptom() {
        $user_id = self::verify_request();
        
        $type = sanitize_text_field($_POST['symptom_type']);
        $severity = intval($_POST['severity']);
        $description = isset($_POST['description']) ? sanitize_textarea_field($_POST['description']) : '';
        
        $symptom_id = AMM_Symptoms::log($user_id, $type, $severity, $description);
        
        if ($symptom_id) {
            wp_send_json_success(array('message' => 'Symptom logged successfully'));
        } else {
            wp_send_json_error(array('message' => 'Failed to log symptom'));
        }
    }
    
    /**
     * Mark alert as read
     */
    public static function mark_alert_read() {
        $user_id = self::verify_request();
        
        $alert_id = intval($_POST['alert_id']);
        $result = AMM_Alerts::mark_read($alert_id);
        
        wp_send_json_success(array('message' => 'Alert marked as read'));
    }
    
    /**
     * Mark all alerts as read
     */
    public static function mark_all_alerts_read() {
        $user_id = self::verify_request();
        
        AMM_Alerts::mark_all_read($user_id);
        
        wp_send_json_success(array('message' => 'All alerts marked as read'));
    }
    
    /**
     * Test push notification
     */
    public static function test_push() {
        $user_id = self::verify_request();
        
        $result = AMM_OneSignal::send_test($user_id);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        } else {
            wp_send_json_success(array(
                'message' => 'Test notification sent',
                'recipients' => $result['recipients']
            ));
        }
    }
    
    /**
     * Get timezone preview for settings modal
     */
    public static function get_timezone_preview() {
        $user_id = self::verify_request();
        
        $home_tz = sanitize_text_field($_POST['home_timezone']);
        $current_tz = sanitize_text_field($_POST['current_timezone']);
        
        if (!AMM_Timezone::is_valid_timezone($home_tz)) {
            $home_tz = wp_timezone_string();
        }
        
        if (!AMM_Timezone::is_valid_timezone($current_tz)) {
            $current_tz = $home_tz;
        }
        
        try {
            $home = new DateTimeZone($home_tz);
            $current = new DateTimeZone($current_tz);
            $now = new DateTime('now', new DateTimeZone('UTC'));
            
            $home_time = new DateTime('now', $home);
            $current_time = new DateTime('now', $current);
            
            $home_offset = $home->getOffset($now);
            $current_offset = $current->getOffset($now);
            $offset_hours = ($current_offset - $home_offset) / 3600;
            
            wp_send_json_success(array(
                'home_time' => $home_time->format('H:i'),
                'current_time' => $current_time->format('H:i'),
                'offset_hours' => $offset_hours
            ));
        } catch (Exception $e) {
            wp_send_json_error(array('message' => 'Invalid timezone'));
        }
    }
}

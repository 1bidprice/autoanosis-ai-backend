<?php
/**
 * Database class - v12.0.0
 * Creates and manages database tables with dose instances and atomic locking
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Database {
    
    /**
     * Create/update all database tables
     */
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Table 1: Doses (NEW in v12)
        $sql_doses = "CREATE TABLE {$wpdb->prefix}mm_doses (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            medication_id bigint(20) NOT NULL,
            user_id bigint(20) NOT NULL,
            dose_date date NOT NULL COMMENT 'Date of the dose',
            dose_time time NOT NULL COMMENT 'Time of the dose',
            due_at datetime NOT NULL COMMENT 'Full datetime in Europe/Athens',
            status enum('pending','sending','sent','taken','missed','failed') NOT NULL DEFAULT 'pending',
            sent_at datetime DEFAULT NULL,
            taken_at datetime DEFAULT NULL,
            onesignal_notification_id varchar(255) DEFAULT NULL,
            onesignal_response longtext DEFAULT NULL,
            attempts int(11) NOT NULL DEFAULT 0,
            last_error text DEFAULT NULL,
            unique_key varchar(100) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_dose (unique_key),
            KEY idx_user_status (user_id, status),
            KEY idx_due_at (due_at),
            KEY idx_medication (medication_id),
            KEY idx_status_due (status, due_at)
        ) $charset_collate COMMENT='Individual dose instances with atomic locking';";
        
        dbDelta($sql_doses);
        
        // Table 2: OneSignal Tokens (NEW in v12)
        $sql_tokens = "CREATE TABLE {$wpdb->prefix}mm_onesignal_tokens (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            onesignal_subscription_id varchar(255) DEFAULT NULL,
            onesignal_player_id varchar(255) DEFAULT NULL,
            external_id varchar(100) NOT NULL,
            platform enum('web','android','ios') NOT NULL DEFAULT 'web',
            is_subscribed tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_user_platform (user_id, platform),
            KEY idx_external_id (external_id),
            KEY idx_subscribed (is_subscribed)
        ) $charset_collate COMMENT='OneSignal tokens per user';";
        
        dbDelta($sql_tokens);
        
        // Table 3: Notification Log (NEW in v12)
        $sql_log = "CREATE TABLE {$wpdb->prefix}mm_notification_log (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            dose_id bigint(20) UNSIGNED DEFAULT NULL,
            user_id bigint(20) NOT NULL,
            medication_id bigint(20) DEFAULT NULL,
            notification_type varchar(50) NOT NULL,
            channel enum('push','email','sms') NOT NULL DEFAULT 'push',
            status enum('pending','sent','failed','cancelled') NOT NULL,
            title varchar(255) DEFAULT NULL,
            message text DEFAULT NULL,
            onesignal_notification_id varchar(255) DEFAULT NULL,
            recipients int(11) DEFAULT 0,
            error_message text DEFAULT NULL,
            sent_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_dose (dose_id),
            KEY idx_user (user_id),
            KEY idx_status (status),
            KEY idx_created (created_at)
        ) $charset_collate COMMENT='Notification audit trail';";
        
        dbDelta($sql_log);
        
        // Table 4: Cron Log (NEW in v12)
        $sql_cron = "CREATE TABLE {$wpdb->prefix}mm_cron_log (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            job_name varchar(100) NOT NULL,
            status enum('started','completed','failed') NOT NULL,
            doses_checked int(11) DEFAULT 0,
            notifications_sent int(11) DEFAULT 0,
            notifications_failed int(11) DEFAULT 0,
            execution_time_ms int(11) DEFAULT NULL,
            error_message text DEFAULT NULL,
            debug_data longtext DEFAULT NULL,
            started_at datetime NOT NULL,
            completed_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY idx_job_status (job_name, status),
            KEY idx_started (started_at)
        ) $charset_collate COMMENT='Cron job execution tracking';";
        
        dbDelta($sql_cron);
        
        // Add indexes to existing tables
        self::add_indexes_to_existing_tables();
        
        // Migrate data from old device_subscriptions table if exists
        self::migrate_device_subscriptions();
    }
    
    /**
     * Add performance indexes to existing tables
     */
    private static function add_indexes_to_existing_tables() {
        global $wpdb;
        
        // Check if medications table exists
        $medications_table = $wpdb->prefix . 'mm_medications';
        if ($wpdb->get_var("SHOW TABLES LIKE '$medications_table'") === $medications_table) {
            // Add indexes if they don't exist
            $wpdb->query("ALTER TABLE $medications_table 
                ADD INDEX IF NOT EXISTS idx_active (active),
                ADD INDEX IF NOT EXISTS idx_patient_active (patient_id, active)");
        }
        
        // Check if adherence table exists
        $adherence_table = $wpdb->prefix . 'mm_adherence';
        if ($wpdb->get_var("SHOW TABLES LIKE '$adherence_table'") === $adherence_table) {
            $wpdb->query("ALTER TABLE $adherence_table
                ADD INDEX IF NOT EXISTS idx_scheduled_status (scheduled_time, status),
                ADD INDEX IF NOT EXISTS idx_medication (medication_id)");
        }
    }
    
    /**
     * Migrate data from old device_subscriptions table
     */
    private static function migrate_device_subscriptions() {
        global $wpdb;
        
        $old_table = $wpdb->prefix . 'mm_device_subscriptions';
        $new_table = $wpdb->prefix . 'mm_onesignal_tokens';
        
        // Check if old table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$old_table'") !== $old_table) {
            return;
        }
        
        // Migrate data
        $wpdb->query("
            INSERT IGNORE INTO $new_table 
                (user_id, external_id, onesignal_subscription_id, onesignal_player_id, platform, created_at)
            SELECT 
                user_id,
                CONCAT('amm_user_', user_id) as external_id,
                external_id as onesignal_subscription_id,
                player_id as onesignal_player_id,
                'web' as platform,
                created_at
            FROM $old_table
        ");
    }
    
    /**
     * Get table name with prefix
     */
    public static function get_table_name($table) {
        global $wpdb;
        return $wpdb->prefix . 'mm_' . $table;
    }
}

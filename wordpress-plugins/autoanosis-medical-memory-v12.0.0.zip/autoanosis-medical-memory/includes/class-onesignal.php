<?php
/**
 * OneSignal class - v11.0.0
 * Uses include_aliases with external_id for targeting
 * Includes JS SDK for user binding
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_OneSignal {
    
    const API_URL = 'https://api.onesignal.com/notifications';
    
    /**
     * Send push notification to user
     * Uses include_aliases with external_id (OneSignal v11+ API)
     */
    public static function send($user_id, $title, $message, $data = array()) {
        $app_id = get_option('amm_onesignal_app_id', '');
        $api_key = get_option('amm_onesignal_api_key', '');
        
        if (empty($app_id) || empty($api_key)) {
            error_log('[AMM OneSignal] Missing credentials - App ID or API Key not set');
            return new WP_Error('config_missing', 'OneSignal credentials not configured');
        }
        
        // External ID format: amm_user_{user_id}
        $external_id = 'amm_user_' . intval($user_id);
        
        $payload = array(
            'app_id' => $app_id,
            'include_aliases' => array(
                'external_id' => array($external_id)
            ),
            'target_channel' => 'push',
            'headings' => array('en' => $title, 'el' => $title),
            'contents' => array('en' => $message, 'el' => $message),
            'data' => $data,
            'ttl' => 86400,
            'priority' => 10
        );
        
        // Add URL if provided
        if (!empty($data['url'])) {
            $payload['url'] = $data['url'];
        }
        
        error_log('[AMM OneSignal] Sending to ' . $external_id . ': ' . $title);
        error_log('[AMM OneSignal] Payload: ' . wp_json_encode($payload));
        
        $response = wp_remote_post(self::API_URL, array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Key ' . $api_key,
                'Content-Type' => 'application/json; charset=utf-8'
            ),
            'body' => wp_json_encode($payload)
        ));
        
        if (is_wp_error($response)) {
            error_log('[AMM OneSignal] WP Error: ' . $response->get_error_message());
            return $response;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('[AMM OneSignal] Response code: ' . $code);
        error_log('[AMM OneSignal] Response body: ' . wp_json_encode($body));
        
        if ($code !== 200 && $code !== 201) {
            $error_msg = isset($body['errors']) ? implode(', ', $body['errors']) : 'Unknown error (HTTP ' . $code . ')';
            error_log('[AMM OneSignal] API Error: ' . $error_msg);
            return new WP_Error('api_error', $error_msg);
        }
        
        return array(
            'success' => true,
            'id' => isset($body['id']) ? $body['id'] : null,
            'recipients' => isset($body['recipients']) ? $body['recipients'] : 0
        );
    }
    
    /**
     * Send medication reminder
     */
    public static function send_medication_reminder($user_id, $medication_name, $dose_time, $dose_id = null) {
        $title = 'Ωρα για φαρμακο';
        $message = sprintf('Παρτε το %s (%s)', $medication_name, $dose_time);
        
        $data = array(
            'type' => 'medication_reminder',
            'dose_id' => $dose_id,
            'url' => home_url('/my-medications/')
        );
        
        return self::send($user_id, $title, $message, $data);
    }
    
    /**
     * Send test notification
     */
    public static function send_test($user_id) {
        return self::send(
            $user_id,
            'Δοκιμαστικη Ειδοποιηση',
            'Οι ειδοποιησεις λειτουργουν σωστα!',
            array(
                'type' => 'test',
                'url' => home_url('/my-medications/')
            )
        );
    }
    
    /**
     * Get OneSignal JS init code for frontend
     * This binds the WordPress user to OneSignal external_id
     */
    public static function get_init_script() {
        static $printed = false;
        if ($printed) { return ''; }
        $printed = true;

        $app_id = get_option('amm_onesignal_app_id', '');
        
        if (empty($app_id)) {
            return '';
        }
        
        $user_id = get_current_user_id();
        $external_id = $user_id ? 'amm_user_' . $user_id : '';
        
        ob_start();
        ?>
        <script src="https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js" defer></script>
        <script>
        window.OneSignalDeferred = window.OneSignalDeferred || [];
        OneSignalDeferred.push(async function(OneSignal) {
            await OneSignal.init({
                appId: "<?php echo esc_js($app_id); ?>",
                allowLocalhostAsSecureOrigin: true
            });
            
            <?php if ($external_id): ?>
            // Login user with external_id for targeting
            try {
                await OneSignal.login("<?php echo esc_js($external_id); ?>");
                console.log('[AMM] OneSignal logged in as: <?php echo esc_js($external_id); ?>');
                
                // Get subscription info for debugging
                const subscription = OneSignal.User.PushSubscription;
                console.log('[AMM] Push subscription ID:', subscription.id);
                console.log('[AMM] Push subscription token:', subscription.token);
                console.log('[AMM] Push optedIn:', subscription.optedIn);
            } catch (e) {
                console.error('[AMM] OneSignal login error:', e);
            }
            <?php endif; ?>
        });
        </script>
        <?php
        return ob_get_clean();
    }
}

<?php
/**
 * Shortcodes class - UI only, no business logic
 * Now includes timezone/travel mode support
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Shortcodes {
    
    public static function init() {
        add_shortcode('amm_my_medications', array(__CLASS__, 'render_dashboard'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
    }
    
    public static function enqueue_assets() {
        if (!is_singular()) return;
        
        global $post;
        if (!has_shortcode($post->post_content, 'amm_my_medications')) return;
        
        wp_enqueue_style('amm-dashboard', AMM_PLUGIN_URL . 'public/assets/css/dashboard.css', array(), AMM_VERSION);
        wp_enqueue_script('amm-dashboard', AMM_PLUGIN_URL . 'public/assets/js/dashboard.js', array('jquery'), AMM_VERSION, true);
        
        // Get timezone info for current user
        $timezone_info = is_user_logged_in() ? AMM_Timezone::get_timezone_info() : array();
        
        wp_localize_script('amm-dashboard', 'amm_ajax', array(
            'url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('amm_nonce'),
            'user_id' => get_current_user_id(),
            'timezone' => $timezone_info
        ));
    }
    
    public static function render_dashboard() {
        if (!is_user_logged_in()) {
            return '<div class="amm-login-required"><p>Παρακαλώ <a href="' . wp_login_url(get_permalink()) . '">συνδεθείτε</a> για να δείτε τα φάρμακά σας.</p></div>';
        }
        
        $user_id = get_current_user_id();
        $medications = AMM_Medications::get_by_patient($user_id);
        $todays_schedule = AMM_Medications::get_todays_schedule($user_id);
        $stats = AMM_Adherence::get_stats($user_id);
        $alerts = AMM_Alerts::get_by_patient($user_id, false, 10);
        $unread_count = AMM_Alerts::get_unread_count($user_id);
        
        // Get timezone info
        $tz_info = AMM_Timezone::get_timezone_info($user_id);
        
        ob_start();
        echo AMM_OneSignal::get_init_script();
        ?>
        
        <div class="amm-dashboard">
            
            <!-- Timezone/Travel Mode Section -->
            <div class="amm-timezone-bar" id="amm-timezone-bar">
                <div class="amm-timezone-info">
                    <span class="amm-timezone-icon">🌍</span>
                    <span class="amm-timezone-label">
                        <?php if ($tz_info['travel_mode']): ?>
                            <strong>Λειτουργία Ταξιδιού:</strong> 
                            <?php echo esc_html($tz_info['current_label']); ?>
                            <span class="amm-timezone-diff">
                                (<?php echo $tz_info['offset_hours'] >= 0 ? '+' : ''; ?><?php echo intval($tz_info['offset_hours']); ?>ω από σπίτι)
                            </span>
                        <?php else: ?>
                            <strong>Ζώνη Ώρας:</strong> <?php echo esc_html($tz_info['home_label']); ?>
                        <?php endif; ?>
                    </span>
                    <span class="amm-current-time" id="amm-current-time"><?php echo esc_html($tz_info['current_time']); ?></span>
                </div>
                <div class="amm-timezone-actions">
                    <button class="amm-btn amm-btn-small amm-btn-travel <?php echo esc_attr($tz_info['travel_mode'] ? 'active' : ''); ?>" id="amm-toggle-travel">
                        ✈️ <?php echo esc_html($tz_info['travel_mode'] ? 'Απενεργοποίηση Ταξιδιού' : 'Λειτουργία Ταξιδιού'); ?>
                    </button>
                    <button class="amm-btn amm-btn-small amm-btn-settings" id="amm-timezone-settings">⚙️</button>
                </div>
            </div>
            
            <!-- Travel Mode Alert (shown when timezone differs) -->
            <?php if ($tz_info['travel_mode'] && $tz_info['offset_hours'] != 0): ?>
            <div class="amm-travel-alert">
                <div class="amm-travel-alert-icon">✈️</div>
                <div class="amm-travel-alert-content">
                    <strong>Ταξιδεύετε!</strong>
                    <p>Οι υπενθυμίσεις φαρμάκων προσαρμόζονται στην τοπική ώρα σας. 
                    Η δόση που ήταν στις <strong><?php echo esc_html($tz_info['home_time']); ?></strong> (ώρα σπιτιού) 
                    θα εμφανιστεί στις <strong><?php echo esc_html($tz_info['current_time']); ?></strong> (τοπική ώρα).</p>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="amm-stats-grid">
                <div class="amm-stat-card amm-stat-taken">
                    <div class="amm-stat-number"><?php echo intval($stats->taken); ?></div>
                    <div class="amm-stat-label">Ελήφθησαν</div>
                </div>
                <div class="amm-stat-card amm-stat-missed">
                    <div class="amm-stat-number"><?php echo intval($stats->missed); ?></div>
                    <div class="amm-stat-label">Χάθηκαν</div>
                </div>
                <div class="amm-stat-card amm-stat-rate">
                    <div class="amm-stat-number"><?php echo intval($stats->adherence_rate); ?>%</div>
                    <div class="amm-stat-label">Συμμόρφωση</div>
                </div>
                <div class="amm-stat-card amm-stat-alerts">
                    <div class="amm-stat-number"><?php echo intval($unread_count); ?></div>
                    <div class="amm-stat-label">Ειδοποιήσεις</div>
                </div>
            </div>
            
            <div class="amm-section">
                <div class="amm-section-header">
                    <h3>📅 Σημερινό Πρόγραμμα</h3>
                    <span class="amm-date"><?php echo date_i18n('l, j F Y'); ?></span>
                </div>
                <div class="amm-schedule-list">
                    <?php if (empty($todays_schedule)): ?>
                        <p class="amm-empty">Δεν υπάρχουν φάρμακα για σήμερα</p>
                    <?php else: ?>
                        <?php foreach ($todays_schedule as $dose): ?>
                            <?php 
                            // Display time as stored (in user's home timezone)
                            // No conversion needed - times are stored in home timezone
                            $display_time_formatted = date('H:i', strtotime($dose->scheduled_time));
                            ?>
                            <div class="amm-dose-item amm-dose-<?php echo esc_attr($dose->status); ?>" data-dose-id="<?php echo intval($dose->id); ?>">
                                <div class="amm-dose-time"><?php echo esc_html($display_time_formatted); ?></div>
                                <div class="amm-dose-info">
                                    <div class="amm-dose-name"><?php echo esc_html($dose->medication_name); ?></div>
                                    <div class="amm-dose-dosage"><?php echo esc_html($dose->dosage); ?></div>
                                </div>
                                <div class="amm-dose-actions">
                                    <?php if ($dose->status === 'pending'): ?>
                                        <button class="amm-btn amm-btn-taken" data-action="taken">✓ Το πήρα</button>
                                        <button class="amm-btn amm-btn-skipped" data-action="skipped">✗ Παράλειψη</button>
                                    <?php elseif ($dose->status === 'taken'): ?>
                                        <span class="amm-status-badge amm-status-taken">✓ Ελήφθη</span>
                                    <?php elseif ($dose->status === 'missed'): ?>
                                        <span class="amm-status-badge amm-status-missed">✗ Χάθηκε</span>
                                    <?php else: ?>
                                        <span class="amm-status-badge amm-status-skipped">⊘ Παραλείφθηκε</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="amm-section">
                <div class="amm-section-header">
                    <h3>💊 Τα Φάρμακά μου</h3>
                    <button class="amm-btn amm-btn-primary" id="amm-add-medication">+ Προσθήκη Φαρμάκου</button>
                </div>
                <div class="amm-medications-list">
                    <?php if (empty($medications)): ?>
                        <p class="amm-empty">Δεν έχετε καταχωρημένα φάρμακα</p>
                    <?php else: ?>
                        <?php foreach ($medications as $med): ?>
                            <?php $time_slots = json_decode($med->time_slots, true); ?>
                            <div class="amm-medication-card" data-medication-id="<?php echo intval($med->id); ?>">
                                <div class="amm-medication-header">
                                    <h4><?php echo esc_html($med->medication_name); ?></h4>
                                    <span class="amm-dosage-badge"><?php echo esc_html($med->dosage); ?></span>
                                </div>
                                <div class="amm-medication-details">
                                    <div><strong>Συχνότητα:</strong> <?php echo esc_html($med->frequency); ?></div>
                                    <div><strong>Ώρες:</strong> <?php echo is_array($time_slots) ? esc_html(implode(', ', $time_slots)) : '-'; ?></div>
                                </div>
                                <div class="amm-medication-actions">
                                    <button class="amm-btn amm-btn-edit" data-action="edit">Επεξεργασία</button>
                                    <button class="amm-btn amm-btn-delete" data-action="delete">Διαγραφή</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="amm-section">
                <div class="amm-section-header">
                    <h3>🔔 Ειδοποιήσεις</h3>
                    <?php if ($unread_count > 0): ?>
                        <button class="amm-btn amm-btn-small" id="amm-mark-all-read">Σήμανση όλων</button>
                    <?php endif; ?>
                </div>
                <div class="amm-alerts-list">
                    <?php if (empty($alerts)): ?>
                        <p class="amm-empty">Δεν υπάρχουν ειδοποιήσεις</p>
                    <?php else: ?>
                        <?php foreach ($alerts as $alert): ?>
                            <div class="amm-alert-item amm-alert-<?php echo esc_attr($alert->severity); ?>" data-alert-id="<?php echo intval($alert->id); ?>">
                                <div class="amm-alert-message"><?php echo esc_html($alert->message); ?></div>
                                <div class="amm-alert-time"><?php echo human_time_diff(strtotime($alert->created_at), current_time('timestamp')); ?> πριν</div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="amm-section">
                <div class="amm-section-header"><h3>📝 Καταγραφή Συμπτώματος</h3></div>
                <form id="amm-symptom-form" class="amm-form">
                    <div class="amm-form-row">
                        <div class="amm-form-group">
                            <label>Σύμπτωμα *</label>
                            <input type="text" name="symptom_type" required placeholder="π.χ. Πονοκέφαλος">
                        </div>
                        <div class="amm-form-group">
                            <label>Σοβαρότητα *</label>
                            <select name="severity" required>
                                <option value="1">1 - Ήπιο</option>
                                <option value="2">2 - Ελαφρύ</option>
                                <option value="3">3 - Μέτριο</option>
                                <option value="4">4 - Σοβαρό</option>
                                <option value="5">5 - Πολύ Σοβαρό</option>
                            </select>
                        </div>
                    </div>
                    <div class="amm-form-group">
                        <label>Σημειώσεις</label>
                        <textarea name="description" rows="2"></textarea>
                    </div>
                    <button type="submit" class="amm-btn amm-btn-primary">Καταγραφή</button>
                </form>
            </div>
            
            <div class="amm-section amm-push-section">
                <div class="amm-section-header"><h3>🔔 Push Notifications</h3></div>
                <div class="amm-push-controls">
                    <p>Ενεργοποιήστε τις ειδοποιήσεις για υπενθυμίσεις φαρμάκων.</p>
                    <button class="amm-btn amm-btn-primary" id="amm-enable-push">Ενεργοποίηση</button>
                    <button class="amm-btn amm-btn-secondary" id="amm-test-push">Δοκιμή</button>
                </div>
            </div>
        </div>
        
        <!-- Medication Modal -->
        <div id="amm-medication-modal" class="amm-modal">
            <div class="amm-modal-content">
                <div class="amm-modal-header">
                    <h3 id="amm-modal-title">Προσθήκη Φαρμάκου</h3>
                    <button class="amm-modal-close">&times;</button>
                </div>
                <form id="amm-medication-form" class="amm-form">
                    <input type="hidden" name="medication_id" value="">
                    <div class="amm-form-group">
                        <label>Όνομα Φαρμάκου *</label>
                        <input type="text" name="medication_name" required>
                    </div>
                    <div class="amm-form-row">
                        <div class="amm-form-group">
                            <label>Δοσολογία *</label>
                            <input type="text" name="dosage" required placeholder="π.χ. 500mg">
                        </div>
                        <div class="amm-form-group">
                            <label>Συχνότητα *</label>
                            <select name="frequency" required>
                                <option value="Once daily">Μία φορά την ημέρα</option>
                                <option value="Twice daily">Δύο φορές την ημέρα</option>
                                <option value="Three times daily">Τρεις φορές την ημέρα</option>
                                <option value="Four times daily">Τέσσερις φορές την ημέρα</option>
                                <option value="As needed">Όταν χρειάζεται</option>
                            </select>
                        </div>
                    </div>
                    <div class="amm-form-group">
                        <label>Ώρες Λήψης * <small>(ώρα σπιτιού σας)</small></label>
                        <div id="amm-time-slots">
                            <div class="amm-time-slot">
                                <input type="time" name="time_slot[]" required>
                                <button type="button" class="amm-btn-remove-time">&times;</button>
                            </div>
                        </div>
                        <button type="button" class="amm-btn amm-btn-small" id="amm-add-time-slot">+ Ώρα</button>
                    </div>
                    <div class="amm-form-row">
                        <div class="amm-form-group">
                            <label>Ημ/νία Έναρξης *</label>
                            <input type="date" name="start_date" required>
                        </div>
                        <div class="amm-form-group">
                            <label>Ημ/νία Λήξης</label>
                            <input type="date" name="end_date">
                        </div>
                    </div>
                    <div class="amm-form-group">
                        <label>Οδηγίες</label>
                        <textarea name="instructions" rows="2"></textarea>
                    </div>
                    <div class="amm-form-actions">
                        <button type="button" class="amm-btn amm-btn-secondary amm-modal-cancel">Ακύρωση</button>
                        <button type="submit" class="amm-btn amm-btn-primary">Αποθήκευση</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Timezone Settings Modal -->
        <div id="amm-timezone-modal" class="amm-modal">
            <div class="amm-modal-content">
                <div class="amm-modal-header">
                    <h3>🌍 Ρυθμίσεις Ζώνης Ώρας</h3>
                    <button class="amm-modal-close">&times;</button>
                </div>
                <div class="amm-timezone-settings-content">
                    <div class="amm-form-group">
                        <label><strong>🏠 Ζώνη Ώρας Σπιτιού</strong></label>
                        <p class="amm-help-text">Η ζώνη ώρας όπου ζείτε κανονικά. Οι ώρες φαρμάκων βασίζονται σε αυτή.</p>
                        <select id="amm-home-timezone" class="amm-select-timezone">
                            <?php echo self::render_timezone_options($tz_info['home_timezone']); ?>
                        </select>
                    </div>
                    
                    <div class="amm-travel-mode-section">
                        <label class="amm-toggle-label">
                            <input type="checkbox" id="amm-travel-mode-checkbox" <?php echo $tz_info['travel_mode'] ? 'checked' : ''; ?>>
                            <span class="amm-toggle-slider"></span>
                            <strong>✈️ Λειτουργία Ταξιδιού</strong>
                        </label>
                        <p class="amm-help-text">Ενεργοποιήστε όταν ταξιδεύετε σε άλλη χώρα. Οι υπενθυμίσεις θα προσαρμοστούν στην τοπική ώρα.</p>
                    </div>
                    
                    <div class="amm-form-group amm-travel-timezone-group" style="<?php echo $tz_info['travel_mode'] ? '' : 'display:none;'; ?>">
                        <label><strong>📍 Τρέχουσα Τοποθεσία</strong></label>
                        <p class="amm-help-text">Η ζώνη ώρας όπου βρίσκεστε τώρα.</p>
                        <select id="amm-current-timezone" class="amm-select-timezone">
                            <?php echo self::render_timezone_options($tz_info['current_timezone']); ?>
                        </select>
                        <button class="amm-btn amm-btn-small" id="amm-detect-timezone">🔍 Αυτόματη Ανίχνευση</button>
                    </div>
                    
                    <div class="amm-timezone-preview" id="amm-timezone-preview">
                        <h4>Προεπισκόπηση:</h4>
                        <div class="amm-preview-times">
                            <div class="amm-preview-time">
                                <span class="amm-preview-label">🏠 Ώρα Σπιτιού:</span>
                                <span class="amm-preview-value" id="amm-preview-home-time"><?php echo esc_html($tz_info['home_time']); ?></span>
                            </div>
                            <div class="amm-preview-time">
                                <span class="amm-preview-label">📍 Τοπική Ώρα:</span>
                                <span class="amm-preview-value" id="amm-preview-current-time"><?php echo esc_html($tz_info['current_time']); ?></span>
                            </div>
                            <div class="amm-preview-time amm-preview-diff">
                                <span class="amm-preview-label">Διαφορά:</span>
                                <span class="amm-preview-value" id="amm-preview-diff">
                                    <?php echo $tz_info['offset_hours'] >= 0 ? '+' : ''; ?><?php echo intval($tz_info['offset_hours']); ?> ώρες
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="amm-form-actions">
                        <button type="button" class="amm-btn amm-btn-secondary amm-modal-cancel">Κλείσιμο</button>
                        <button type="button" class="amm-btn amm-btn-primary" id="amm-save-timezone">Αποθήκευση</button>
                    </div>
                </div>
            </div>
        </div>
        
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render timezone dropdown options
     */
    private static function render_timezone_options($selected = '') {
        $timezones = AMM_Timezone::get_timezone_list();
        $output = '';
        
        // Group by region
        $grouped = array();
        foreach ($timezones as $tz => $label) {
            $parts = explode('/', $tz);
            $region = $parts[0];
            if (!isset($grouped[$region])) {
                $grouped[$region] = array();
            }
            $grouped[$region][$tz] = $label;
        }
        
        foreach ($grouped as $region => $zones) {
            $output .= '<optgroup label="' . esc_attr($region) . '">';
            foreach ($zones as $tz => $label) {
                $is_selected = ($tz === $selected) ? 'selected' : '';
                $output .= '<option value="' . esc_attr($tz) . '" ' . $is_selected . '>' . esc_html($label) . '</option>';
            }
            $output .= '</optgroup>';
        }
        
        return $output;
    }
}

<?php
/**
 * Cron class - v12.0.0 PRODUCTION-READY
 * 
 * KEY FEATURES:
 * - Uses tkc_mm_doses table with atomic locking
 * - No transients (database-level duplicate prevention)
 * - Proper error handling and retry logic
 * - Comprehensive logging to tkc_mm_cron_log
 * - Daily dose generation top-up
 * - Cleanup old doses
 */

if (!defined('ABSPATH')) {
    exit;
}

class AMM_Cron {
    
    const HOOK_CHECK_MEDICATIONS = 'amm_check_medications';
    const HOOK_GENERATE_DOSES = 'amm_generate_doses';
    const HOOK_CLEANUP_DOSES = 'amm_cleanup_doses';
    
    /**
     * Initialize cron hooks
     */
    public static function init() {
        add_action(self::HOOK_CHECK_MEDICATIONS, array(__CLASS__, 'check_due_medications'));
        add_action(self::HOOK_GENERATE_DOSES, array(__CLASS__, 'generate_daily_doses'));
        add_action(self::HOOK_CLEANUP_DOSES, array(__CLASS__, 'cleanup_old_doses'));
    }
    
    /**
     * Schedule cron events
     */
    public static function schedule_events() {
        // Check medications every minute
        if (!wp_next_scheduled(self::HOOK_CHECK_MEDICATIONS)) {
            wp_schedule_event(time(), 'every_minute', self::HOOK_CHECK_MEDICATIONS);
        }
        
        // Generate doses daily at 2 AM
        if (!wp_next_scheduled(self::HOOK_GENERATE_DOSES)) {
            $tomorrow_2am = strtotime('tomorrow 2:00 AM');
            wp_schedule_event($tomorrow_2am, 'daily', self::HOOK_GENERATE_DOSES);
        }
        
        // Cleanup old doses weekly
        if (!wp_next_scheduled(self::HOOK_CLEANUP_DOSES)) {
            $next_sunday_3am = strtotime('next Sunday 3:00 AM');
            wp_schedule_event($next_sunday_3am, 'weekly', self::HOOK_CLEANUP_DOSES);
        }
    }
    
    /**
     * Add custom cron intervals
     */
    public static function add_cron_intervals($schedules) {
        $schedules['every_minute'] = array(
            'interval' => 60,
            'display' => 'Every Minute'
        );
        return $schedules;
    }
    
    /**
     * Deactivation - clear scheduled events
     */
    public static function deactivate() {
        wp_clear_scheduled_hook(self::HOOK_CHECK_MEDICATIONS);
        wp_clear_scheduled_hook(self::HOOK_GENERATE_DOSES);
        wp_clear_scheduled_hook(self::HOOK_CLEANUP_DOSES);
    }
    
    /**
     * Check for due medications and send push notifications
     * Uses tkc_mm_doses table with atomic locking
     * 
     * @return array Debug info
     */
    public static function check_due_medications() {
        global $wpdb;
        
        $start_time = microtime(true);
        $cron_log_table = AMM_Database::get_table_name('cron_log');
        
        // Log cron start
        $log_id = $wpdb->insert($cron_log_table, array(
            'job_name' => 'check_medications',
            'status' => 'started',
            'started_at' => current_time('mysql')
        ), array('%s', '%s', '%s'));
        
        $log_id = $wpdb->insert_id;
        
        $debug = array(
            'success' => true,
            'timestamp' => current_time('mysql'),
            'doses_checked' => 0,
            'notifications_sent' => 0,
            'notifications_failed' => 0,
            'details' => array()
        );
        
        try {
            // Check if push is enabled
            if (get_option('amm_enable_push', '1') !== '1') {
                $debug['details'][] = 'Push notifications disabled';
                self::complete_cron_log($log_id, 'completed', $debug, $start_time);
                return $debug;
            }
            
            // Get Athens timezone
            $athens_tz = new DateTimeZone('Europe/Athens');
            $now_athens = new DateTime('now', $athens_tz);
            
            $debug['athens_time'] = $now_athens->format('Y-m-d H:i:s');
            
            // Calculate time window: current time +/- 2 minutes
            $window_start = (clone $now_athens)->modify('-2 minutes');
            $window_end = (clone $now_athens)->modify('+2 minutes');
            
            $debug['window_start'] = $window_start->format('Y-m-d H:i:s');
            $debug['window_end'] = $window_end->format('Y-m-d H:i:s');
            
            // Get pending doses in window
            $due_doses = AMM_Doses::get_pending_doses_in_window($window_start, $window_end);
            
            $debug['doses_found'] = count($due_doses);
            
            if (empty($due_doses)) {
                $debug['details'][] = 'No pending doses in current window';
                self::complete_cron_log($log_id, 'completed', $debug, $start_time);
                return $debug;
            }
            
            foreach ($due_doses as $dose) {
                $debug['doses_checked']++;
                
                $dose_detail = array(
                    'dose_id' => $dose->id,
                    'medication_name' => $dose->medication_name,
                    'scheduled_time' => $dose->due_at,
                    'user_id' => $dose->user_id
                );
                
                // ATOMIC LOCK: Try to claim this dose
                $claimed = AMM_Doses::claim_dose_for_sending($dose->id);
                
                if (!$claimed) {
                    // Another worker already claimed it
                    $dose_detail['status'] = 'already_claimed';
                    $debug['details'][] = $dose_detail;
                    continue;
                }
                
                // Format time for display
                $dose_time = date('H:i', strtotime($dose->due_at));
                
                // Send push notification
                $result = AMM_OneSignal::send_medication_reminder(
                    $dose->user_id,
                    $dose->medication_name,
                    $dose_time,
                    $dose->id
                );
                
                if (is_wp_error($result)) {
                    // Failed - mark as failed and log
                    $error_msg = $result->get_error_message();
                    AMM_Doses::mark_as_failed($dose->id, $error_msg);
                    
                    $dose_detail['status'] = 'failed';
                    $dose_detail['error'] = $error_msg;
                    $debug['notifications_failed']++;
                    
                    // Log to notification_log
                    self::log_notification($dose->id, $dose->user_id, $dose->medication_id, 'failed', null, $error_msg);
                    
                } else {
                    // Success - mark as sent
                    $notification_id = isset($result['id']) ? $result['id'] : null;
                    AMM_Doses::mark_as_sent($dose->id, $notification_id, $result);
                    
                    $dose_detail['status'] = 'sent';
                    $dose_detail['onesignal_id'] = $notification_id;
                    $dose_detail['recipients'] = isset($result['recipients']) ? $result['recipients'] : 0;
                    $debug['notifications_sent']++;
                    
                    // Log to notification_log
                    self::log_notification($dose->id, $dose->user_id, $dose->medication_id, 'sent', $notification_id);
                }
                
                $debug['details'][] = $dose_detail;
            }
            
            // Complete cron log
            self::complete_cron_log($log_id, 'completed', $debug, $start_time);
            
        } catch (Exception $e) {
            $debug['success'] = false;
            $debug['error'] = $e->getMessage();
            self::complete_cron_log($log_id, 'failed', $debug, $start_time);
        }
        
        // Log to error_log for debugging
        error_log('[AMM Cron v12] ' . wp_json_encode($debug));
        
        return $debug;
    }
    
    /**
     * Generate doses for all active medications (daily top-up)
     */
    public static function generate_daily_doses() {
        global $wpdb;
        
        $start_time = microtime(true);
        $cron_log_table = AMM_Database::get_table_name('cron_log');
        
        // Log cron start
        $log_id = $wpdb->insert($cron_log_table, array(
            'job_name' => 'generate_doses',
            'status' => 'started',
            'started_at' => current_time('mysql')
        ), array('%s', '%s', '%s'));
        
        $log_id = $wpdb->insert_id;
        
        try {
            // Generate doses for next 30 days
            $total_generated = AMM_Doses::regenerate_all_doses(30);
            
            $debug = array(
                'success' => true,
                'doses_generated' => $total_generated
            );
            
            self::complete_cron_log($log_id, 'completed', $debug, $start_time);
            
            error_log('[AMM Cron v12] Daily dose generation: ' . $total_generated . ' doses');
            
        } catch (Exception $e) {
            $debug = array(
                'success' => false,
                'error' => $e->getMessage()
            );
            self::complete_cron_log($log_id, 'failed', $debug, $start_time);
        }
    }
    
    /**
     * Cleanup old doses (older than 90 days)
     */
    public static function cleanup_old_doses() {
        global $wpdb;
        
        $start_time = microtime(true);
        $cron_log_table = AMM_Database::get_table_name('cron_log');
        
        // Log cron start
        $log_id = $wpdb->insert($cron_log_table, array(
            'job_name' => 'cleanup_doses',
            'status' => 'started',
            'started_at' => current_time('mysql')
        ), array('%s', '%s', '%s'));
        
        $log_id = $wpdb->insert_id;
        
        try {
            $deleted = AMM_Doses::cleanup_old_doses();
            
            $debug = array(
                'success' => true,
                'doses_deleted' => $deleted
            );
            
            self::complete_cron_log($log_id, 'completed', $debug, $start_time);
            
            error_log('[AMM Cron v12] Cleanup: ' . $deleted . ' old doses deleted');
            
        } catch (Exception $e) {
            $debug = array(
                'success' => false,
                'error' => $e->getMessage()
            );
            self::complete_cron_log($log_id, 'failed', $debug, $start_time);
        }
    }
    
    /**
     * Complete cron log entry
     */
    private static function complete_cron_log($log_id, $status, $debug, $start_time) {
        global $wpdb;
        
        $cron_log_table = AMM_Database::get_table_name('cron_log');
        $execution_time_ms = round((microtime(true) - $start_time) * 1000);
        
        $wpdb->update(
            $cron_log_table,
            array(
                'status' => $status,
                'doses_checked' => isset($debug['doses_checked']) ? $debug['doses_checked'] : 0,
                'notifications_sent' => isset($debug['notifications_sent']) ? $debug['notifications_sent'] : 0,
                'notifications_failed' => isset($debug['notifications_failed']) ? $debug['notifications_failed'] : 0,
                'execution_time_ms' => $execution_time_ms,
                'error_message' => isset($debug['error']) ? $debug['error'] : null,
                'debug_data' => wp_json_encode($debug),
                'completed_at' => current_time('mysql')
            ),
            array('id' => $log_id),
            array('%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s'),
            array('%d')
        );
    }
    
    /**
     * Log notification attempt
     */
    private static function log_notification($dose_id, $user_id, $medication_id, $status, $onesignal_id = null, $error_message = null) {
        global $wpdb;
        
        $notification_log_table = AMM_Database::get_table_name('notification_log');
        
        $wpdb->insert($notification_log_table, array(
            'dose_id' => $dose_id,
            'user_id' => $user_id,
            'medication_id' => $medication_id,
            'notification_type' => 'medication_reminder',
            'channel' => 'push',
            'status' => $status,
            'onesignal_notification_id' => $onesignal_id,
            'error_message' => $error_message,
            'sent_at' => ($status === 'sent') ? current_time('mysql') : null,
            'created_at' => current_time('mysql')
        ), array('%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s'));
    }
    
    /**
     * Get cron status for admin
     */
    public static function get_status() {
        return array(
            'check_medications' => wp_next_scheduled(self::HOOK_CHECK_MEDICATIONS),
            'generate_doses' => wp_next_scheduled(self::HOOK_GENERATE_DOSES),
            'cleanup_doses' => wp_next_scheduled(self::HOOK_CLEANUP_DOSES)
        );
    }
    
    /**
     * Get cron health stats (last 24 hours)
     */
    public static function get_health_stats() {
        global $wpdb;
        
        $cron_log_table = AMM_Database::get_table_name('cron_log');
        
        $stats = $wpdb->get_results("
            SELECT 
                job_name,
                COUNT(*) as total_runs,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as successful_runs,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_runs,
                MAX(started_at) as last_run_at,
                AVG(execution_time_ms) as avg_execution_time_ms,
                SUM(notifications_sent) as total_notifications_sent,
                SUM(notifications_failed) as total_notifications_failed
            FROM $cron_log_table
            WHERE started_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            GROUP BY job_name
        ");
        
        return $stats;
    }
}

// Register custom intervals early
add_filter('cron_schedules', array('AMM_Cron', 'add_cron_intervals'));

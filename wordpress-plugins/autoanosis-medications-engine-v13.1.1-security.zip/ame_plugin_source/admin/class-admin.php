<?php
/**
 * AME_Admin — v13.0.0
 * Admin settings page for Medications Engine.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_Admin {

    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
    }

    public static function add_menu() {
        add_options_page(
            'Medications Engine',
            'Medications Engine',
            'manage_options',
            'ame-settings',
            array( __CLASS__, 'render_settings_page' )
        );
    }

    public static function register_settings() {
        register_setting( 'ame_settings', 'ame_onesignal_app_id' );
        register_setting( 'ame_settings', 'ame_onesignal_api_key' );
        register_setting( 'ame_settings', 'ame_backend_key' );
    }

    public static function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $quarantined_at = get_option( 'ame_adherence_quarantined_at', '' );
        ?>
        <div class="wrap">
            <h1>Autoanosis Medications Engine v<?php echo AME_VERSION; ?></h1>

            <div class="notice notice-info">
                <p><strong>Architecture v13.0.0:</strong> Single truth = <code>mm_doses</code>. Legacy <code>mm_adherence</code> is quarantined (read-only). FastAPI meds backend is deprecated.</p>
                <?php if ( $quarantined_at ) : ?>
                    <p>✅ <code>mm_adherence</code> quarantined at: <?php echo esc_html( $quarantined_at ); ?></p>
                <?php endif; ?>
            </div>

            <form method="post" action="options.php">
                <?php settings_fields( 'ame_settings' ); ?>
                <table class="form-table">
                    <tr>
                        <th>OneSignal App ID</th>
                        <td><input type="text" name="ame_onesignal_app_id" value="<?php echo esc_attr( get_option( 'ame_onesignal_app_id' ) ); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>OneSignal REST API Key</th>
                        <td><input type="password" name="ame_onesignal_api_key" value="<?php echo esc_attr( get_option( 'ame_onesignal_api_key' ) ); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Backend API Key (X-AME-Backend-Key)</th>
                        <td>
                            <input type="text" name="ame_backend_key" value="<?php echo esc_attr( get_option( 'ame_backend_key' ) ); ?>" class="regular-text">
                            <p class="description">Used by the AI backend for server-to-server calls to /ai-context.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>

            <h2>Diagnostics</h2>
            <?php AME_Admin_Diagnostics::render(); ?>
        </div>
        <?php
    }
}

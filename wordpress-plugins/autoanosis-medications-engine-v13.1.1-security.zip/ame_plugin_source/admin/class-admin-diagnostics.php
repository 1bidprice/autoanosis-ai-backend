<?php
/**
 * AME_Admin_Diagnostics — v13.0.0
 * Admin diagnostics panel: table health, cron status, recent logs.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_Admin_Diagnostics {

    public static function render() {
        global $wpdb;

        $tables = array(
            'mm_medications'     => 'Master medications',
            'mm_doses'           => 'Dose instances (ONE TRUTH)',
            'mm_onesignal_tokens' => 'Push tokens',
            'mm_notification_log' => 'Notification audit',
            'mm_cron_log'        => 'Cron audit',
            'mm_adherence'       => 'DEPRECATED (quarantined)',
        );

        echo '<table class="widefat striped"><thead><tr><th>Table</th><th>Status</th><th>Rows</th><th>Note</th></tr></thead><tbody>';

        foreach ( $tables as $table_suffix => $label ) {
            $full = $wpdb->prefix . $table_suffix;
            $exists = $wpdb->get_var( "SHOW TABLES LIKE '{$full}'" ) === $full;
            $count  = $exists ? intval( $wpdb->get_var( "SELECT COUNT(*) FROM {$full}" ) ) : 'N/A';
            $status = $exists ? '✅ Exists' : '❌ Missing';
            $note   = $table_suffix === 'mm_adherence' ? '⚠️ Quarantined — no new writes' : '';
            echo "<tr><td><code>{$full}</code></td><td>{$status}</td><td>{$count}</td><td>{$label} {$note}</td></tr>";
        }

        echo '</tbody></table>';

        // Cron status
        echo '<h3>Cron Jobs</h3><table class="widefat striped"><thead><tr><th>Hook</th><th>Next Run</th></tr></thead><tbody>';
        $hooks = array(
            AME_Cron::HOOK_SEND_REMINDERS,
            AME_Cron::HOOK_MARK_MISSED,
            AME_Cron::HOOK_TOPUP_DOSES,
            AME_Cron::HOOK_CLEANUP,
        );
        foreach ( $hooks as $hook ) {
            $next = wp_next_scheduled( $hook );
            $next_str = $next ? date( 'Y-m-d H:i:s', $next ) . ' UTC' : '❌ Not scheduled';
            echo "<tr><td><code>{$hook}</code></td><td>{$next_str}</td></tr>";
        }
        echo '</tbody></table>';

        // Recent cron log
        $cron_log_table = AME_Database::table( 'cron_log' );
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$cron_log_table}'" ) === $cron_log_table ) {
            $logs = $wpdb->get_results( "SELECT * FROM {$cron_log_table} ORDER BY started_at DESC LIMIT 10" );
            if ( $logs ) {
                echo '<h3>Recent Cron Log (last 10)</h3>';
                echo '<table class="widefat striped"><thead><tr><th>Job</th><th>Status</th><th>Checked</th><th>Sent</th><th>Failed</th><th>ms</th><th>Started</th></tr></thead><tbody>';
                foreach ( $logs as $log ) {
                    echo "<tr><td>{$log->job_name}</td><td>{$log->status}</td><td>{$log->doses_checked}</td><td>{$log->notifications_sent}</td><td>{$log->notifications_failed}</td><td>{$log->execution_time_ms}</td><td>{$log->started_at}</td></tr>";
                }
                echo '</tbody></table>';
            }
        }
    }
}

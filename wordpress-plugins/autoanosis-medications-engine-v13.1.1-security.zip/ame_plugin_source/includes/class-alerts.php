<?php
/**
 * AME_Alerts — v13.0.0
 * Medication-related alerts (missed doses, adherence warnings, etc.)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_Alerts {

    public static function get_by_patient( $patient_id, $unread_only = false, $limit = 20 ) {
        global $wpdb;
        $t   = $wpdb->prefix . 'mm_alerts';

        // If table doesn't exist yet, return empty
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$t}'" ) !== $t ) {
            return array();
        }

        $sql = "SELECT * FROM {$t} WHERE patient_id = %d";
        if ( $unread_only ) {
            $sql .= " AND is_read = 0";
        }
        $sql .= " ORDER BY created_at DESC LIMIT %d";

        return $wpdb->get_results( $wpdb->prepare( $sql, $patient_id, $limit ) );
    }

    public static function get_unread_count( $patient_id ) {
        global $wpdb;
        $t = $wpdb->prefix . 'mm_alerts';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$t}'" ) !== $t ) {
            return 0;
        }
        return intval( $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$t} WHERE patient_id = %d AND is_read = 0",
            $patient_id
        ) ) );
    }

    public static function mark_read( $alert_id, $patient_id ) {
        global $wpdb;
        $t = $wpdb->prefix . 'mm_alerts';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$t}'" ) !== $t ) {
            return false;
        }
        return $wpdb->update(
            $t,
            array( 'is_read' => 1 ),
            array( 'id' => $alert_id, 'patient_id' => $patient_id ),
            array( '%d' ),
            array( '%d', '%d' )
        );
    }

    public static function mark_all_read( $patient_id ) {
        global $wpdb;
        $t = $wpdb->prefix . 'mm_alerts';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$t}'" ) !== $t ) {
            return false;
        }
        return $wpdb->update(
            $t,
            array( 'is_read' => 1 ),
            array( 'patient_id' => $patient_id ),
            array( '%d' ),
            array( '%d' )
        );
    }
}

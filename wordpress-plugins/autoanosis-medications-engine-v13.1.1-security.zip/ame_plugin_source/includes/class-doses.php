<?php
/**
 * AME_Doses — v13.0.0
 *
 * Read, mark, and aggregate dose data from mm_doses (ONE TRUTH).
 * No legacy mm_adherence references anywhere in this class.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_Doses {

    // ─── MARK INTAKE ─────────────────────────────────────────────────────────

    /**
     * Mark a dose as taken.
     * Idempotent: if already taken, returns true without re-writing.
     *
     * @param int    $dose_id
     * @param int    $user_id   For ownership check
     * @param string $note      Optional note
     * @return true|WP_Error
     */
    public static function mark_taken( $dose_id, $user_id, $note = '' ) {
        global $wpdb;
        $t    = AME_Database::table( 'doses' );
        $dose = self::get( $dose_id );

        if ( ! $dose ) {
            return new WP_Error( 'not_found', 'Dose not found.' );
        }
        if ( intval( $dose->user_id ) !== intval( $user_id ) ) {
            return new WP_Error( 'forbidden', 'Access denied.' );
        }
        // Idempotency: already taken
        if ( $dose->status === 'taken' ) {
            return true;
        }

        $home_tz  = new DateTimeZone( AME_Timezone::get_home_timezone( $user_id ) );
        $now_local = ( new DateTime( 'now', $home_tz ) )->format( 'Y-m-d H:i:s' );

        $result = $wpdb->update(
            $t,
            array(
                'status'              => 'taken',
                'taken_at'            => $now_local,
                'confirmation_source' => 'user_ui',
                'note'                => sanitize_textarea_field( $note ),
                'reminder_state'      => 'suppressed', // prevent future reminders for this dose
                'updated_at'          => current_time( 'mysql' ),
            ),
            array( 'id' => $dose_id ),
            array( '%s', '%s', '%s', '%s', '%s', '%s' ),
            array( '%d' )
        );

        return ( $result !== false ) ? true : new WP_Error( 'db_error', 'Failed to update dose.' );
    }

    /**
     * Mark a dose as skipped.
     * Idempotent.
     */
    public static function mark_skipped( $dose_id, $user_id, $note = '' ) {
        global $wpdb;
        $t    = AME_Database::table( 'doses' );
        $dose = self::get( $dose_id );

        if ( ! $dose ) {
            return new WP_Error( 'not_found', 'Dose not found.' );
        }
        if ( intval( $dose->user_id ) !== intval( $user_id ) ) {
            return new WP_Error( 'forbidden', 'Access denied.' );
        }
        if ( in_array( $dose->status, array( 'taken', 'skipped' ), true ) ) {
            return true; // idempotent
        }

        $home_tz   = new DateTimeZone( AME_Timezone::get_home_timezone( $user_id ) );
        $now_local = ( new DateTime( 'now', $home_tz ) )->format( 'Y-m-d H:i:s' );

        $result = $wpdb->update(
            $t,
            array(
                'status'              => 'skipped',
                'skipped_at'          => $now_local,
                'confirmation_source' => 'user_ui',
                'note'                => sanitize_textarea_field( $note ),
                'reminder_state'      => 'suppressed',
                'updated_at'          => current_time( 'mysql' ),
            ),
            array( 'id' => $dose_id ),
            array( '%s', '%s', '%s', '%s', '%s', '%s' ),
            array( '%d' )
        );

        return ( $result !== false ) ? true : new WP_Error( 'db_error', 'Failed to update dose.' );
    }

    /**
     * Mark overdue pending doses as missed (called by cron).
     * A dose is missed if: status=pending AND due_at_utc + grace_window_minutes < NOW()
     *
     * @return int Number of doses marked missed
     */
    public static function mark_overdue_as_missed() {
        global $wpdb;
        $t = AME_Database::table( 'doses' );

        $rows = $wpdb->query(
            "UPDATE {$t}
             SET status = 'missed',
                 missed_at = NOW(),
                 reminder_state = 'suppressed',
                 updated_at = NOW()
             WHERE status = 'pending'
               AND DATE_ADD(due_at_utc, INTERVAL grace_window_minutes MINUTE) < UTC_TIMESTAMP()"
        );

        return intval( $rows );
    }

    // ─── CRON HELPERS ────────────────────────────────────────────────────────

    /**
     * Get pending doses within a UTC time window (for cron notification dispatch).
     *
     * @param DateTime $window_start UTC
     * @param DateTime $window_end   UTC
     * @return array
     */
    public static function get_pending_in_window( $window_start, $window_end ) {
        global $wpdb;
        $doses_table = AME_Database::table( 'doses' );
        $meds_table  = AME_Database::table( 'medications' );

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT d.*, m.medication_name, m.dosage, m.instructions, m.status AS med_status
             FROM {$doses_table} d
             JOIN {$meds_table} m ON d.medication_id = m.id
             WHERE d.status = 'pending'
               AND d.reminder_state NOT IN ('suppressed','sent','delivered','acknowledged')
               AND m.active = 1
               AND m.status = 'active'
               AND d.due_at_utc BETWEEN %s AND %s
             ORDER BY d.due_at_utc ASC",
            $window_start->format( 'Y-m-d H:i:s' ),
            $window_end->format( 'Y-m-d H:i:s' )
        ) );
    }

    /**
     * Atomically claim a dose for sending (prevents duplicate sends).
     * Returns true if claimed, false if already claimed.
     */
    public static function claim_for_sending( $dose_id ) {
        global $wpdb;
        $t = AME_Database::table( 'doses' );

        $rows = $wpdb->query( $wpdb->prepare(
            "UPDATE {$t}
             SET reminder_state = 'queued',
                 send_attempts  = send_attempts + 1,
                 updated_at     = NOW()
             WHERE id = %d
               AND reminder_state NOT IN ('queued','sent','delivered','acknowledged','suppressed')",
            $dose_id
        ) );

        return $rows > 0;
    }

    /**
     * Mark dose reminder as sent.
     */
    public static function mark_reminder_sent( $dose_id, $onesignal_id = null, $response = null ) {
        global $wpdb;
        $t = AME_Database::table( 'doses' );
        $wpdb->update(
            $t,
            array(
                'reminder_state'           => 'sent',
                'onesignal_notification_id' => $onesignal_id,
                'onesignal_response'        => is_array( $response ) ? wp_json_encode( $response ) : $response,
                'updated_at'               => current_time( 'mysql' ),
            ),
            array( 'id' => $dose_id ),
            array( '%s', '%s', '%s', '%s' ),
            array( '%d' )
        );
    }

    /**
     * Mark dose reminder as failed (with retry logic).
     */
    public static function mark_reminder_failed( $dose_id, $error = null ) {
        global $wpdb;
        $t    = AME_Database::table( 'doses' );
        $dose = self::get( $dose_id );

        // After 3 attempts, mark as permanently failed; otherwise back to not_sent for retry
        $new_state = ( $dose && intval( $dose->send_attempts ) >= 3 ) ? 'failed' : 'not_sent';

        $wpdb->update(
            $t,
            array(
                'reminder_state' => $new_state,
                'last_error'     => $error,
                'updated_at'     => current_time( 'mysql' ),
            ),
            array( 'id' => $dose_id ),
            array( '%s', '%s', '%s' ),
            array( '%d' )
        );
    }

    // ─── READ ────────────────────────────────────────────────────────────────

    public static function get( $dose_id ) {
        global $wpdb;
        $t = AME_Database::table( 'doses' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $dose_id ) );
    }

    /**
     * Get adherence statistics for a user from mm_doses.
     * Returns: taken, missed, skipped, pending, total_past, adherence_rate.
     *
     * Policy:
     *   adherence_rate = taken / (taken + missed + skipped) * 100
     *   skipped counts as non-adherent (conservative clinical standard)
     *
     * @param int $user_id
     * @param int $days    Lookback window in days (default 7)
     * @return object
     */
    public static function get_stats( $user_id, $days = 7 ) {
        global $wpdb;
        $t = AME_Database::table( 'doses' );

        $since = ( new DateTime( "-{$days} days", new DateTimeZone( 'UTC' ) ) )->format( 'Y-m-d H:i:s' );

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT
                SUM(CASE WHEN status = 'taken'   THEN 1 ELSE 0 END) AS taken,
                SUM(CASE WHEN status = 'missed'  THEN 1 ELSE 0 END) AS missed,
                SUM(CASE WHEN status = 'skipped' THEN 1 ELSE 0 END) AS skipped,
                SUM(CASE WHEN status = 'pending' AND due_at_utc <= UTC_TIMESTAMP() THEN 1 ELSE 0 END) AS overdue,
                COUNT(*) AS total
             FROM {$t}
             WHERE user_id = %d
               AND due_at_utc >= %s
               AND status != 'cancelled'",
            $user_id,
            $since
        ) );

        if ( ! $row ) {
            return (object) array(
                'taken'          => 0,
                'missed'         => 0,
                'skipped'        => 0,
                'overdue'        => 0,
                'total'          => 0,
                'adherence_rate' => 0,
            );
        }

        $taken   = intval( $row->taken );
        $missed  = intval( $row->missed );
        $skipped = intval( $row->skipped );
        $denom   = $taken + $missed + $skipped;

        $row->adherence_rate = ( $denom > 0 ) ? round( ( $taken / $denom ) * 100 ) : 0;

        return $row;
    }

    /**
     * Get the next upcoming pending dose for a user.
     *
     * @param int $user_id
     * @return object|null
     */
    public static function get_next_dose( $user_id ) {
        global $wpdb;
        $doses_table = AME_Database::table( 'doses' );
        $meds_table  = AME_Database::table( 'medications' );

        return $wpdb->get_row( $wpdb->prepare(
            "SELECT d.*, m.medication_name, m.dosage
             FROM {$doses_table} d
             JOIN {$meds_table} m ON d.medication_id = m.id
             WHERE d.user_id = %d
               AND d.status = 'pending'
               AND d.due_at_utc > UTC_TIMESTAMP()
             ORDER BY d.due_at_utc ASC
             LIMIT 1",
            $user_id
        ) );
    }

    /**
     * Clean up old dose records (older than 90 days).
     * Preserves taken/missed/skipped for analytics; removes cancelled/failed.
     */
    public static function cleanup_old( $days = 90 ) {
        global $wpdb;
        $t      = AME_Database::table( 'doses' );
        $cutoff = ( new DateTime( "-{$days} days", new DateTimeZone( 'UTC' ) ) )->format( 'Y-m-d' );

        return $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$t}
             WHERE scheduled_local_date < %s
               AND status IN ('cancelled','failed','pending')",
            $cutoff
        ) );
    }
}

<?php
/**
 * AME_OneSignal — v13.0.0
 *
 * OneSignal push notification integration.
 * Channel-agnostic design: notification dispatch is isolated here.
 * Future channels (email, SMS) can be added without touching cron logic.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_OneSignal {

    private static function get_app_id() {
        return get_option( 'ame_onesignal_app_id', get_option( 'amm_onesignal_app_id', '' ) );
    }

    private static function get_api_key() {
        return get_option( 'ame_onesignal_api_key', get_option( 'amm_onesignal_api_key', '' ) );
    }

    /**
     * Send a dose reminder push notification.
     *
     * @param object $dose  Dose row (with medication_name, dosage, user_id)
     * @return array|false  OneSignal API response or false on failure
     */
    public static function send_dose_reminder( $dose ) {
        $app_id  = self::get_app_id();
        $api_key = self::get_api_key();

        if ( ! $app_id || ! $api_key ) {
            return false;
        }

        $external_id = 'ame_user_' . intval( $dose->user_id );
        $time_str    = substr( $dose->scheduled_local_time, 0, 5 );
        $med_name    = $dose->medication_name;
        $dosage      = $dose->dosage ? ' — ' . $dose->dosage : '';

        $payload = array(
            'app_id'             => $app_id,
            'include_aliases'    => array( 'external_id' => array( $external_id ) ),
            'target_channel'     => 'push',
            'headings'           => array( 'el' => '💊 Υπενθύμιση Φαρμάκου', 'en' => '💊 Medication Reminder' ),
            'contents'           => array(
                'el' => $med_name . $dosage . ' — ' . $time_str,
                'en' => $med_name . $dosage . ' — ' . $time_str,
            ),
            'data'               => array(
                'dose_id'       => intval( $dose->id ),
                'medication_id' => intval( $dose->medication_id ),
                'action'        => 'dose_reminder',
            ),
            'url'                => home_url( '/my-medications/' ),
            'web_buttons'        => array(
                array( 'id' => 'taken',   'text' => '✓ Το πήρα',    'url' => '' ),
                array( 'id' => 'snooze',  'text' => '⏰ Αργότερα',   'url' => '' ),
            ),
            'ttl'                => 3600, // Expire after 1 hour
        );

        return self::api_call( $payload );
    }

    /**
     * Send a test notification to a user.
     */
    public static function send_test( $user_id ) {
        $app_id  = self::get_app_id();
        $api_key = self::get_api_key();

        if ( ! $app_id || ! $api_key ) {
            return false;
        }

        $external_id = 'ame_user_' . intval( $user_id );

        $payload = array(
            'app_id'          => $app_id,
            'include_aliases' => array( 'external_id' => array( $external_id ) ),
            'target_channel'  => 'push',
            'headings'        => array( 'el' => '✅ Δοκιμή Ειδοποίησης', 'en' => '✅ Test Notification' ),
            'contents'        => array(
                'el' => 'Οι υπενθυμίσεις φαρμάκων λειτουργούν σωστά!',
                'en' => 'Medication reminders are working correctly!',
            ),
        );

        $result = self::api_call( $payload );
        return $result && isset( $result['id'] );
    }

    /**
     * Register a OneSignal token for a user.
     */
    public static function register_token( $user_id, $subscription_id, $player_id = null, $platform = 'web' ) {
        global $wpdb;
        $t           = AME_Database::table( 'onesignal_tokens' );
        $external_id = 'ame_user_' . intval( $user_id );

        $wpdb->replace( $t, array(
            'user_id'                   => $user_id,
            'onesignal_subscription_id' => $subscription_id,
            'onesignal_player_id'       => $player_id,
            'external_id'               => $external_id,
            'platform'                  => $platform,
            'is_subscribed'             => 1,
            'updated_at'                => current_time( 'mysql' ),
        ), array( '%d', '%s', '%s', '%s', '%s', '%d', '%s' ) );

        // Set external_id in OneSignal via API
        if ( $subscription_id ) {
            self::set_external_id( $subscription_id, $external_id );
        }
    }

    /**
     * Set external_id on a OneSignal subscription.
     */
    private static function set_external_id( $subscription_id, $external_id ) {
        $app_id  = self::get_app_id();
        $api_key = self::get_api_key();

        if ( ! $app_id || ! $api_key || ! $subscription_id ) {
            return false;
        }

        $url = 'https://onesignal.com/api/v1/players/' . $subscription_id;

        wp_remote_post( $url, array(
            'method'  => 'PUT',
            'headers' => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Basic ' . $api_key,
            ),
            'body'    => wp_json_encode( array(
                'app_id'      => $app_id,
                'external_user_id' => $external_id,
            ) ),
            'timeout' => 10,
        ) );
    }

    /**
     * Make a OneSignal API call.
     *
     * @param array $payload
     * @return array|false
     */
    private static function api_call( $payload ) {
        $api_key = self::get_api_key();

        $response = wp_remote_post( 'https://onesignal.com/api/v1/notifications', array(
            'method'  => 'POST',
            'headers' => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Basic ' . $api_key,
            ),
            'body'    => wp_json_encode( $payload ),
            'timeout' => 15,
        ) );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        return $body ?: false;
    }

    /**
     * Print the OneSignal init script in wp_footer.
     * Called via add_action('wp_footer', ...) — runs AFTER ame_ajax is localized.
     */
    public static function print_init_script() {
        $app_id = self::get_app_id();
        if ( ! $app_id ) {
            return;
        }
        $user_id    = intval( get_current_user_id() );
        $ajax_url   = esc_js( admin_url( 'admin-ajax.php' ) );
        $nonce      = esc_js( wp_create_nonce( 'ame_nonce' ) );
        $app_id_esc = esc_js( $app_id );
        ?>
        <script>
        /* AME OneSignal Init — runs after DOM and ame_ajax are ready */
        (function() {
            'use strict';

            var ajaxUrl = '<?php echo $ajax_url; ?>';
            var nonce   = '<?php echo $nonce; ?>';
            var userId  = <?php echo $user_id; ?>;

            function initOneSignal() {
                // Use OneSignalDeferred queue — SDK populates it when ready.
                // Do NOT check window.OneSignal here: SDK v16 sets it async.
                window.OneSignalDeferred = window.OneSignalDeferred || [];
                window.OneSignalDeferred.push(async function(OneSignal) {
                    try {
                        await OneSignal.init({
                            appId: '<?php echo $app_id_esc; ?>',
                            serviceWorkerPath: '/OneSignalSDKWorker.js',
                            notifyButton: { enable: false },
                            allowLocalhostAsSecureOrigin: false,
                        });
                    } catch(e) {
                        var el = document.getElementById('ame-push-status');
                        if (el) el.textContent = '⚠️ Σφάλμα αρχικοποίησης push.';
                        return;
                    }

                    // Login with external_id to link this device to the WP user
                    if (userId > 0) {
                        var externalId = 'ame_user_' + userId;
                        try {
                            await OneSignal.login(externalId);
                        } catch(e) { /* already logged in or not supported */ }

                        // Register subscription token with WordPress
                        try {
                            var subscriptionId = OneSignal.User.PushSubscription.id;
                            if (subscriptionId) {
                                jQuery.post(ajaxUrl, {
                                    action: 'ame_register_token',
                                    nonce: nonce,
                                    subscription_id: subscriptionId,
                                    platform: 'web'
                                });
                            }
                        } catch(e) {}
                    }

                    // Update UI based on subscription status
                    var isSubscribed = false;
                    try {
                        isSubscribed = OneSignal.User.PushSubscription.optedIn;
                    } catch(e) {}

                    var pushStatus = document.getElementById('ame-push-status');
                    var enableBtn  = document.getElementById('ame-enable-push');
                    var testBtn    = document.getElementById('ame-test-push');

                    if (pushStatus) {
                        if (isSubscribed) {
                            pushStatus.innerHTML = '<span style="color:#27ae60;">&#10003; Οι υπενθυμίσεις push είναι ενεργές.</span>';
                            if (testBtn) testBtn.style.display = 'inline-block';
                        } else {
                            pushStatus.innerHTML = '<span style="color:#e67e22;">&#9888; Οι υπενθυμίσεις push δεν είναι ενεργές.</span>';
                            if (enableBtn) enableBtn.style.display = 'inline-block';
                        }
                    }

                    if (enableBtn) {
                        enableBtn.addEventListener('click', async function() {
                            try {
                                await OneSignal.User.PushSubscription.optIn();
                                location.reload();
                            } catch(e) {
                                alert('Σφάλμα ενεργοποίησης. Βεβαιωθείτε ότι επιτρέπετε τις ειδοποιήσεις στον browser σας.');
                            }
                        });
                    }

                    if (testBtn) {
                        testBtn.addEventListener('click', function() {
                            jQuery.post(ajaxUrl, {
                                action: 'ame_test_push',
                                nonce: nonce
                            }, function(r) {
                                alert(r && r.success ? '&#10003; Δοκιμαστική ειδοποίηση εστάλη!' : '&#10007; Αποτυχία αποστολής.');
                            });
                        });
                    }
                });
            }

            // Run after DOM is fully loaded
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initOneSignal);
            } else {
                initOneSignal();
            }
        })();
        </script>
        <?php
    }

    /**
     * @deprecated Use print_init_script() via wp_footer action instead.
     * Kept for backwards compatibility only.
     */
    public static function get_init_script() {
        return '';
    }
}

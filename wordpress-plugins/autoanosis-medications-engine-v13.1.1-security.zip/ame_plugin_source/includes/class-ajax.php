<?php
/**
 * AME_Ajax — v13.0.0
 *
 * All AJAX handlers for the My Medications UI.
 *
 * WRITE CONTRACT:
 *   - Medication CRUD → mm_medications + triggers AME_DoseGenerator → mm_doses
 *   - Dose intake ("Το πήρα" / "Παράλειψη") → mm_doses ONLY
 *   - mm_adherence is NEVER written
 *
 * NONCE: ame_nonce (replaces legacy amm_nonce — backwards compat handled)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_Ajax {

    public static function init() {
        // Medication CRUD
        add_action( 'wp_ajax_ame_save_medication',   array( __CLASS__, 'save_medication' ) );
        add_action( 'wp_ajax_ame_delete_medication',  array( __CLASS__, 'delete_medication' ) );
        add_action( 'wp_ajax_ame_get_medication',     array( __CLASS__, 'get_medication' ) );
        add_action( 'wp_ajax_ame_pause_medication',   array( __CLASS__, 'pause_medication' ) );
        add_action( 'wp_ajax_ame_resume_medication',  array( __CLASS__, 'resume_medication' ) );

        // Backwards compat aliases (old JS may still post amm_*)
        add_action( 'wp_ajax_amm_save_medication',   array( __CLASS__, 'save_medication' ) );
        add_action( 'wp_ajax_amm_add_medication',    array( __CLASS__, 'save_medication' ) );
        add_action( 'wp_ajax_amm_update_medication', array( __CLASS__, 'save_medication' ) );
        add_action( 'wp_ajax_amm_delete_medication', array( __CLASS__, 'delete_medication' ) );
        add_action( 'wp_ajax_amm_get_medication',    array( __CLASS__, 'get_medication' ) );

        // Dose intake — writes to mm_doses ONLY
        add_action( 'wp_ajax_ame_mark_dose',    array( __CLASS__, 'mark_dose' ) );
        add_action( 'wp_ajax_ame_log_prn',      array( __CLASS__, 'log_prn' ) );

        // Backwards compat — old JS posts amm_mark_dose / amm_mark_taken / amm_mark_skipped
        add_action( 'wp_ajax_amm_mark_dose',    array( __CLASS__, 'mark_dose' ) );
        add_action( 'wp_ajax_amm_mark_taken',   array( __CLASS__, 'mark_dose_taken_compat' ) );
        add_action( 'wp_ajax_amm_mark_skipped', array( __CLASS__, 'mark_dose_skipped_compat' ) );

        // Symptom & alert actions (unchanged)
        add_action( 'wp_ajax_ame_log_symptom',       array( __CLASS__, 'log_symptom' ) );
        add_action( 'wp_ajax_ame_mark_alert_read',   array( __CLASS__, 'mark_alert_read' ) );
        add_action( 'wp_ajax_ame_mark_alerts_read',  array( __CLASS__, 'mark_all_alerts_read' ) );
        add_action( 'wp_ajax_amm_log_symptom',       array( __CLASS__, 'log_symptom' ) );
        add_action( 'wp_ajax_amm_mark_alert_read',   array( __CLASS__, 'mark_alert_read' ) );
        add_action( 'wp_ajax_amm_mark_alerts_read',  array( __CLASS__, 'mark_all_alerts_read' ) );
        add_action( 'wp_ajax_amm_mark_all_alerts_read', array( __CLASS__, 'mark_all_alerts_read' ) );

        // Push & timezone
        add_action( 'wp_ajax_ame_test_push',            array( __CLASS__, 'test_push' ) );
        add_action( 'wp_ajax_ame_register_token',       array( __CLASS__, 'register_token' ) );
        add_action( 'wp_ajax_ame_detect_timezone',      array( __CLASS__, 'detect_timezone' ) );
        add_action( 'wp_ajax_ame_toggle_travel_mode',   array( __CLASS__, 'toggle_travel_mode' ) );
        add_action( 'wp_ajax_ame_update_timezone',      array( __CLASS__, 'update_timezone' ) );
        add_action( 'wp_ajax_amm_test_push',            array( __CLASS__, 'test_push' ) );
        add_action( 'wp_ajax_amm_detect_timezone',      array( __CLASS__, 'detect_timezone' ) );
        add_action( 'wp_ajax_amm_toggle_travel_mode',   array( __CLASS__, 'toggle_travel_mode' ) );
        add_action( 'wp_ajax_amm_update_timezone',      array( __CLASS__, 'update_timezone' ) );
        add_action( 'wp_ajax_amm_get_timezone_preview', array( __CLASS__, 'get_timezone_preview' ) );
    }

    // ─── AUTH ────────────────────────────────────────────────────────────────

    private static function verify_request() {
        // Accept both ame_nonce and legacy amm_nonce
        $nonce_ok = check_ajax_referer( 'ame_nonce', 'nonce', false )
                 || check_ajax_referer( 'amm_nonce', 'nonce', false );

        if ( ! $nonce_ok ) {
            wp_send_json_error( array( 'message' => 'Invalid security token.' ), 403 );
        }
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'Please log in.' ), 401 );
        }
        return get_current_user_id();
    }

    // ─── MEDICATION CRUD ─────────────────────────────────────────────────────

    public static function save_medication() {
        $user_id = self::verify_request();

        $medication_id = isset( $_POST['medication_id'] ) ? intval( $_POST['medication_id'] ) : 0;

        $time_slots = isset( $_POST['time_slots'] ) ? $_POST['time_slots'] : array();
        if ( is_string( $time_slots ) ) {
            $time_slots = json_decode( stripslashes( $time_slots ), true );
        }

        $data = array(
            'patient_id'      => $user_id,
            'medication_name' => sanitize_text_field( $_POST['medication_name'] ?? '' ),
            'dosage'          => sanitize_text_field( $_POST['dosage'] ?? '' ),
            'unit'            => sanitize_text_field( $_POST['unit'] ?? '' ),
            'frequency'       => sanitize_text_field( $_POST['frequency'] ?? '' ),
            'frequency_type'  => sanitize_text_field( $_POST['frequency_type'] ?? 'fixed_daily' ),
            'time_slots'      => $time_slots,
            'interval_hours'  => isset( $_POST['interval_hours'] ) ? intval( $_POST['interval_hours'] ) : null,
            'weekdays'        => isset( $_POST['weekdays'] ) ? $_POST['weekdays'] : null,
            'start_date'      => sanitize_text_field( $_POST['start_date'] ?? '' ),
            'end_date'        => sanitize_text_field( $_POST['end_date'] ?? '' ),
            'instructions'    => sanitize_textarea_field( $_POST['instructions'] ?? '' ),
            'is_prn'          => isset( $_POST['is_prn'] ) ? intval( $_POST['is_prn'] ) : 0,
            'prescribed_by'   => sanitize_text_field( $_POST['prescribed_by'] ?? '' ),
            'indication'      => sanitize_textarea_field( $_POST['indication'] ?? '' ),
        );

        if ( $medication_id > 0 ) {
            // Ownership check
            $existing = AME_Medications::get( $medication_id );
            if ( ! $existing || intval( $existing->patient_id ) !== $user_id ) {
                wp_send_json_error( array( 'message' => 'Φάρμακο δεν βρέθηκε.' ), 404 );
            }
            $result = AME_Medications::update( $medication_id, $data );
        } else {
            $result = AME_Medications::add( $data );
            if ( ! is_wp_error( $result ) ) {
                $medication_id = $result;
            }
        }

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array( 'medication_id' => $medication_id ) );
    }

    public static function delete_medication() {
        $user_id = self::verify_request();

        $medication_id = intval( $_POST['medication_id'] ?? 0 );
        $med           = AME_Medications::get( $medication_id );

        if ( ! $med || intval( $med->patient_id ) !== $user_id ) {
            wp_send_json_error( array( 'message' => 'Φάρμακο δεν βρέθηκε.' ), 404 );
        }

        AME_Medications::delete( $medication_id );
        wp_send_json_success( array( 'message' => 'Φάρμακο διαγράφηκε.' ) );
    }

    public static function get_medication() {
        $user_id = self::verify_request();

        $medication_id = intval( $_POST['medication_id'] ?? 0 );
        $med           = AME_Medications::get( $medication_id );

        if ( ! $med || intval( $med->patient_id ) !== $user_id ) {
            wp_send_json_error( array( 'message' => 'Φάρμακο δεν βρέθηκε.' ), 404 );
        }

        $med->time_slots = json_decode( $med->time_slots, true ) ?: array();
        $med->weekdays   = json_decode( $med->weekdays, true ) ?: array();

        wp_send_json_success( $med );
    }

    public static function pause_medication() {
        $user_id = self::verify_request();

        $medication_id = intval( $_POST['medication_id'] ?? 0 );
        $med           = AME_Medications::get( $medication_id );

        if ( ! $med || intval( $med->patient_id ) !== $user_id ) {
            wp_send_json_error( array( 'message' => 'Φάρμακο δεν βρέθηκε.' ), 404 );
        }

        AME_Medications::pause( $medication_id );
        wp_send_json_success( array( 'message' => 'Φάρμακο σε παύση.' ) );
    }

    public static function resume_medication() {
        $user_id = self::verify_request();

        $medication_id = intval( $_POST['medication_id'] ?? 0 );
        $med           = AME_Medications::get( $medication_id );

        if ( ! $med || intval( $med->patient_id ) !== $user_id ) {
            wp_send_json_error( array( 'message' => 'Φάρμακο δεν βρέθηκε.' ), 404 );
        }

        AME_Medications::resume( $medication_id );
        wp_send_json_success( array( 'message' => 'Φάρμακο επαναλαμβάνεται.' ) );
    }

    // ─── DOSE INTAKE ─────────────────────────────────────────────────────────

    /**
     * Primary dose action handler.
     * Writes to mm_doses ONLY. Never touches mm_adherence.
     */
    public static function mark_dose() {
        $user_id = self::verify_request();

        $dose_id = intval( $_POST['dose_id'] ?? 0 );
        $status  = sanitize_text_field( $_POST['status'] ?? '' );
        $note    = sanitize_textarea_field( $_POST['note'] ?? '' );

        if ( ! in_array( $status, array( 'taken', 'skipped' ), true ) ) {
            wp_send_json_error( array( 'message' => 'Μη έγκυρη κατάσταση.' ) );
        }

        if ( $status === 'taken' ) {
            $result = AME_Doses::mark_taken( $dose_id, $user_id, $note );
        } else {
            $result = AME_Doses::mark_skipped( $dose_id, $user_id, $note );
        }

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array( 'message' => 'Dose updated.', 'status' => $status ) );
    }

    /**
     * Backwards compat: old JS posts amm_mark_taken with dose_id from mm_adherence.
     * We resolve the dose_id via mm_doses unique_key lookup if possible,
     * otherwise we accept the dose_id directly (it may already be a mm_doses id).
     */
    public static function mark_dose_taken_compat() {
        $_POST['status'] = 'taken';
        self::mark_dose();
    }

    public static function mark_dose_skipped_compat() {
        $_POST['status'] = 'skipped';
        self::mark_dose();
    }

    /**
     * Log a PRN (as-needed) intake.
     */
    public static function log_prn() {
        $user_id = self::verify_request();

        $medication_id = intval( $_POST['medication_id'] ?? 0 );
        $note          = sanitize_textarea_field( $_POST['note'] ?? '' );

        $dose_id = AME_DoseGenerator::log_prn_intake( $medication_id, $user_id, $note );

        if ( ! $dose_id ) {
            wp_send_json_error( array( 'message' => 'Αποτυχία καταγραφής PRN.' ) );
        }

        wp_send_json_success( array( 'dose_id' => $dose_id ) );
    }

    // ─── SYMPTOMS ────────────────────────────────────────────────────────────

    public static function log_symptom() {
        $user_id = self::verify_request();

        $symptom     = sanitize_text_field( $_POST['symptom'] ?? '' );
        $severity    = intval( $_POST['severity'] ?? 0 );
        $description = sanitize_textarea_field( $_POST['description'] ?? '' );

        if ( empty( $symptom ) ) {
            wp_send_json_error( array( 'message' => 'Το σύμπτωμα είναι υποχρεωτικό.' ) );
        }

        $result = AME_Symptoms::log( $user_id, $symptom, $severity, $description );

        if ( $result ) {
            wp_send_json_success( array( 'message' => 'Σύμπτωμα καταγράφηκε.' ) );
        } else {
            wp_send_json_error( array( 'message' => 'Αποτυχία καταγραφής συμπτώματος.' ) );
        }
    }

    // ─── ALERTS ──────────────────────────────────────────────────────────────

    public static function mark_alert_read() {
        $user_id  = self::verify_request();
        $alert_id = intval( $_POST['alert_id'] ?? 0 );
        AME_Alerts::mark_read( $alert_id, $user_id );
        wp_send_json_success();
    }

    public static function mark_all_alerts_read() {
        $user_id = self::verify_request();
        AME_Alerts::mark_all_read( $user_id );
        wp_send_json_success();
    }

    // ─── PUSH ────────────────────────────────────────────────────────────────

    public static function test_push() {
        $user_id = self::verify_request();
        $result  = AME_OneSignal::send_test( $user_id );
        if ( $result ) {
            wp_send_json_success( array( 'message' => 'Test notification sent.' ) );
        } else {
            wp_send_json_error( array( 'message' => 'Failed to send test notification.' ) );
        }
    }

    public static function register_token() {
        $user_id      = self::verify_request();
        $subscription = sanitize_text_field( $_POST['subscription_id'] ?? '' );
        $player_id    = sanitize_text_field( $_POST['player_id'] ?? '' );
        $platform     = sanitize_text_field( $_POST['platform'] ?? 'web' );

        AME_OneSignal::register_token( $user_id, $subscription, $player_id, $platform );
        wp_send_json_success();
    }

    // ─── TIMEZONE ────────────────────────────────────────────────────────────

    public static function detect_timezone() {
        $user_id  = self::verify_request();
        $timezone = sanitize_text_field( $_POST['timezone'] ?? '' );
        AME_Timezone::set_current_timezone( $user_id, $timezone );
        wp_send_json_success( AME_Timezone::get_timezone_info( $user_id ) );
    }

    public static function toggle_travel_mode() {
        $user_id = self::verify_request();
        $result  = AME_Timezone::toggle_travel_mode( $user_id );
        wp_send_json_success( $result );
    }

    public static function update_timezone() {
        $user_id  = self::verify_request();
        $home_tz  = sanitize_text_field( $_POST['home_timezone'] ?? '' );
        $curr_tz  = sanitize_text_field( $_POST['current_timezone'] ?? '' );

        if ( $home_tz ) {
            AME_Timezone::set_home_timezone( $user_id, $home_tz );
        }
        if ( $curr_tz ) {
            AME_Timezone::set_current_timezone( $user_id, $curr_tz );
        }

        wp_send_json_success( AME_Timezone::get_timezone_info( $user_id ) );
    }

    public static function get_timezone_preview() {
        $user_id = self::verify_request();
        wp_send_json_success( AME_Timezone::get_timezone_info( $user_id ) );
    }
}

<?php
/**
 * AME_Database — v13.0.0
 *
 * Schema owner for all Medications Engine tables.
 * Manages creation, migration, and legacy quarantine.
 *
 * TABLES OWNED:
 *   mm_medications       — master medication metadata
 *   mm_doses             — ONE TRUTH for all dose instances and intake state
 *   mm_notification_log  — push/email/sms audit trail
 *   mm_cron_log          — cron execution audit
 *   mm_onesignal_tokens  — push subscription tokens
 *
 * DEPRECATED (quarantine only, no writes):
 *   mm_adherence         — legacy adherence records (read-only until drop)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_Database {

    /**
     * Create or upgrade all tables.
     * Safe to call on every activation / db version bump.
     */
    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // ─── TABLE 1: mm_medications ─────────────────────────────────────────
        $sql_medications = "CREATE TABLE {$wpdb->prefix}mm_medications (
            id                  bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            patient_id          bigint(20) NOT NULL COMMENT 'WordPress user_id',
            medication_name     varchar(255) NOT NULL,
            active_ingredient   varchar(255) DEFAULT NULL,
            dosage              varchar(100) DEFAULT NULL COMMENT 'e.g. 100mg, 1 tablet',
            unit                varchar(50)  DEFAULT NULL COMMENT 'mg, ml, tablet, drop',
            instructions        text         DEFAULT NULL,
            frequency           varchar(100) DEFAULT NULL COMMENT 'e.g. daily, twice_daily, every_8h, prn, weekdays',
            frequency_type      enum('fixed_daily','interval_hours','weekdays','prn','short_course','chronic') NOT NULL DEFAULT 'fixed_daily',
            time_slots          text         DEFAULT NULL COMMENT 'JSON array of HH:MM strings for fixed_daily/weekdays',
            interval_hours      tinyint(3)   DEFAULT NULL COMMENT 'For frequency_type=interval_hours',
            weekdays            varchar(20)  DEFAULT NULL COMMENT 'JSON array: [1,3,5] = Mon,Wed,Fri',
            start_date          date         NOT NULL,
            end_date            date         DEFAULT NULL,
            status              enum('active','paused','stopped','completed') NOT NULL DEFAULT 'active',
            is_prn              tinyint(1)   NOT NULL DEFAULT 0,
            prescribed_by       varchar(255) DEFAULT NULL,
            indication          text         DEFAULT NULL COMMENT 'Condition / reason for medication',
            timezone_mode       enum('home','travel') NOT NULL DEFAULT 'home',
            version             int(11)      NOT NULL DEFAULT 1 COMMENT 'Increments on schedule change for history',
            active              tinyint(1)   NOT NULL DEFAULT 1 COMMENT 'Soft delete flag',
            created_at          datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at          datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_patient_active (patient_id, active),
            KEY idx_status (status),
            KEY idx_start_end (start_date, end_date)
        ) $charset_collate COMMENT='Master medication metadata — no adherence data here';";

        dbDelta( $sql_medications );

        // ─── TABLE 2: mm_doses ───────────────────────────────────────────────
        // ONE TRUTH: every scheduled dose instance lives here.
        // UI, cron, REST API all read/write ONLY this table for intake state.
        $sql_doses = "CREATE TABLE {$wpdb->prefix}mm_doses (
            id                      bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            medication_id           bigint(20) NOT NULL,
            user_id                 bigint(20) NOT NULL,
            medication_version      int(11)    NOT NULL DEFAULT 1 COMMENT 'Snapshot of medication.version at generation time',
            scheduled_local_date    date       NOT NULL COMMENT 'Date in user home timezone',
            scheduled_local_time    time       NOT NULL COMMENT 'Time in user home timezone',
            scheduled_timezone      varchar(50) NOT NULL DEFAULT 'Europe/Athens',
            due_at_utc              datetime   NOT NULL COMMENT 'Canonical UTC datetime for cron/sorting',
            status                  enum('pending','taken','skipped','missed','cancelled','sent','sending','failed') NOT NULL DEFAULT 'pending',
            taken_at                datetime   DEFAULT NULL,
            skipped_at              datetime   DEFAULT NULL,
            missed_at               datetime   DEFAULT NULL,
            confirmation_source     enum('user_ui','doctor','caregiver','migration','system','cron') DEFAULT NULL,
            note                    text       DEFAULT NULL,
            reminder_state          enum('not_sent','queued','sent','delivered','acknowledged','suppressed','failed') NOT NULL DEFAULT 'not_sent',
            reminder_count          tinyint(3) NOT NULL DEFAULT 0,
            grace_window_minutes    smallint(5) NOT NULL DEFAULT 60 COMMENT 'Minutes after due_at_utc before marking missed',
            onesignal_notification_id varchar(255) DEFAULT NULL,
            onesignal_response      longtext   DEFAULT NULL,
            send_attempts           tinyint(3) NOT NULL DEFAULT 0,
            last_error              text       DEFAULT NULL,
            unique_key              varchar(120) NOT NULL COMMENT 'user_id-med_id-YYYYMMDD-HHMM',
            created_at              datetime   NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at              datetime   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_dose (unique_key),
            KEY idx_user_status_due (user_id, status, due_at_utc),
            KEY idx_med_due (medication_id, due_at_utc),
            KEY idx_status_due (status, due_at_utc),
            KEY idx_user_date (user_id, scheduled_local_date),
            KEY idx_reminder (reminder_state, due_at_utc)
        ) $charset_collate COMMENT='ONE TRUTH — all dose instances and intake state';";

        dbDelta( $sql_doses );

        // ─── TABLE 3: mm_onesignal_tokens ────────────────────────────────────
        $sql_tokens = "CREATE TABLE {$wpdb->prefix}mm_onesignal_tokens (
            id                          bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id                     bigint(20) NOT NULL,
            onesignal_subscription_id   varchar(255) DEFAULT NULL,
            onesignal_player_id         varchar(255) DEFAULT NULL,
            external_id                 varchar(100) NOT NULL,
            platform                    enum('web','android','ios') NOT NULL DEFAULT 'web',
            is_subscribed               tinyint(1)   NOT NULL DEFAULT 1,
            created_at                  datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at                  datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_user_platform (user_id, platform),
            KEY idx_external_id (external_id),
            KEY idx_subscribed (is_subscribed)
        ) $charset_collate COMMENT='OneSignal push tokens per user';";

        dbDelta( $sql_tokens );

        // ─── TABLE 4: mm_notification_log ────────────────────────────────────
        $sql_notif = "CREATE TABLE {$wpdb->prefix}mm_notification_log (
            id                          bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            dose_id                     bigint(20) UNSIGNED DEFAULT NULL,
            user_id                     bigint(20) NOT NULL,
            medication_id               bigint(20) DEFAULT NULL,
            notification_type           varchar(50) NOT NULL,
            channel                     enum('push','email','sms') NOT NULL DEFAULT 'push',
            status                      enum('pending','sent','failed','cancelled') NOT NULL,
            title                       varchar(255) DEFAULT NULL,
            message                     text DEFAULT NULL,
            onesignal_notification_id   varchar(255) DEFAULT NULL,
            recipients                  int(11) DEFAULT 0,
            error_message               text DEFAULT NULL,
            sent_at                     datetime DEFAULT NULL,
            created_at                  datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_dose (dose_id),
            KEY idx_user (user_id),
            KEY idx_status (status),
            KEY idx_created (created_at)
        ) $charset_collate COMMENT='Notification audit trail';";

        dbDelta( $sql_notif );

        // ─── TABLE 5: mm_cron_log ────────────────────────────────────────────
        $sql_cron = "CREATE TABLE {$wpdb->prefix}mm_cron_log (
            id                      bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            job_name                varchar(100) NOT NULL,
            status                  enum('started','completed','failed') NOT NULL,
            doses_checked           int(11) DEFAULT 0,
            notifications_sent      int(11) DEFAULT 0,
            notifications_failed    int(11) DEFAULT 0,
            execution_time_ms       int(11) DEFAULT NULL,
            error_message           text DEFAULT NULL,
            debug_data              longtext DEFAULT NULL,
            started_at              datetime NOT NULL,
            completed_at            datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY idx_job_status (job_name, status),
            KEY idx_started (started_at)
        ) $charset_collate COMMENT='Cron job execution audit';";

        dbDelta( $sql_cron );

        // Run any post-schema tasks
        self::migrate_legacy_tokens();
    }

    /**
     * Quarantine mm_adherence: remove all write triggers, mark deprecated.
     * Does NOT drop the table — that happens after cutover verification.
     * Safe to call multiple times (idempotent).
     */
    public static function quarantine_legacy_adherence() {
        global $wpdb;
        $table = $wpdb->prefix . 'mm_adherence';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table ) {
            // Record quarantine timestamp in options for audit
            if ( ! get_option( 'ame_adherence_quarantined_at' ) ) {
                update_option( 'ame_adherence_quarantined_at', current_time( 'mysql' ) );
                // Log to cron_log for visibility
                $wpdb->insert(
                    $wpdb->prefix . 'mm_cron_log',
                    array(
                        'job_name'    => 'legacy_quarantine',
                        'status'      => 'completed',
                        'debug_data'  => 'mm_adherence quarantined — no new writes from AME v13+',
                        'started_at'  => current_time( 'mysql' ),
                        'completed_at' => current_time( 'mysql' ),
                    ),
                    array( '%s', '%s', '%s', '%s', '%s' )
                );
            }
        }
    }

    /**
     * Migrate tokens from old mm_device_subscriptions if it exists.
     */
    private static function migrate_legacy_tokens() {
        global $wpdb;
        $old_table = $wpdb->prefix . 'mm_device_subscriptions';
        $new_table = $wpdb->prefix . 'mm_onesignal_tokens';

        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$old_table}'" ) !== $old_table ) {
            return;
        }

        $wpdb->query( "
            INSERT IGNORE INTO {$new_table}
                (user_id, external_id, onesignal_subscription_id, onesignal_player_id, platform, created_at)
            SELECT
                user_id,
                CONCAT('ame_user_', user_id),
                external_id,
                player_id,
                'web',
                created_at
            FROM {$old_table}
        " );
    }

    /**
     * Get prefixed table name.
     * Usage: AME_Database::table('doses') → tkc_mm_doses
     */
    public static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'mm_' . $name;
    }
}

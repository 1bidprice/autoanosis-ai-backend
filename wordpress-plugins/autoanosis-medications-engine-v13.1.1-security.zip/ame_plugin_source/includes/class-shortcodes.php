<?php
/**
 * AME_Shortcodes — v13.0.0
 *
 * Renders the My Medications dashboard.
 *
 * READ CONTRACT:
 *   - Today's schedule → mm_doses (via AME_Medications::get_todays_schedule)
 *   - Counters (taken/missed/rate) → mm_doses (via AME_Doses::get_stats)
 *   - Medication list → mm_medications
 *   - mm_adherence is NEVER read
 *
 * Supports both shortcodes:
 *   [ame_my_medications]  — new name
 *   [amm_my_medications]  — backwards compat
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_Shortcodes {

    public static function init() {
        add_shortcode( 'ame_my_medications', array( __CLASS__, 'render_dashboard' ) );
        add_shortcode( 'amm_my_medications', array( __CLASS__, 'render_dashboard' ) ); // backwards compat
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
    }

    public static function enqueue_assets() {
        if ( ! is_singular() ) {
            return;
        }
        global $post;
        if ( ! $post ) {
            return;
        }
        if ( ! has_shortcode( $post->post_content, 'ame_my_medications' )
            && ! has_shortcode( $post->post_content, 'amm_my_medications' ) ) {
            return;
        }

        wp_enqueue_style( 'ame-dashboard', AME_PLUGIN_URL . 'public/assets/css/dashboard.css', array(), AME_VERSION );
        wp_enqueue_script( 'ame-dashboard', AME_PLUGIN_URL . 'public/assets/js/dashboard.js', array( 'jquery' ), AME_VERSION, true );

        // OneSignal SDK — must be loaded before our init script
        $onesignal_app_id = get_option( 'ame_onesignal_app_id', '' );
        if ( $onesignal_app_id ) {
            wp_enqueue_script(
                'onesignal-sdk',
                'https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js',
                array(),
                null,
                false  // load in <head> as OneSignal requires
            );
        }

        $tz_info = is_user_logged_in() ? AME_Timezone::get_timezone_info( get_current_user_id() ) : array();

        wp_localize_script( 'ame-dashboard', 'ame_ajax', array(
            'url'      => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'ame_nonce' ),
            'user_id'  => get_current_user_id(),
            'timezone' => $tz_info,
        ) );

        // Inject OneSignal init script in wp_footer (after ame_ajax is defined)
        if ( $onesignal_app_id && is_user_logged_in() ) {
            add_action( 'wp_footer', array( 'AME_OneSignal', 'print_init_script' ), 99 );
        }
    }

    public static function render_dashboard() {
        if ( ! is_user_logged_in() ) {
            return '<div class="ame-login-required"><p>Παρακαλώ <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">συνδεθείτε</a> για να δείτε τα φάρμακά σας.</p></div>';
        }

        $user_id = get_current_user_id();

        // ── DATA LAYER (all from mm_doses / mm_medications) ──────────────────
        $medications     = AME_Medications::get_by_patient( $user_id );
        $todays_schedule = AME_Medications::get_todays_schedule( $user_id );
        $stats           = AME_Doses::get_stats( $user_id, 7 );   // reads mm_doses ONLY
        $alerts          = AME_Alerts::get_by_patient( $user_id, false, 10 );
        $unread_count    = AME_Alerts::get_unread_count( $user_id );
        $tz_info         = AME_Timezone::get_timezone_info( $user_id );
        $next_dose       = AME_Doses::get_next_dose( $user_id );

        ob_start();
        ?>

        <div class="ame-dashboard">

            <!-- Timezone / Travel Mode Bar -->
            <div class="ame-timezone-bar" id="ame-timezone-bar">
                <div class="ame-timezone-info">
                    <span class="ame-timezone-icon">🌍</span>
                    <span class="ame-timezone-label">
                        <?php if ( $tz_info['travel_mode'] ) : ?>
                            <strong>Λειτουργία Ταξιδιού:</strong>
                            <?php echo esc_html( $tz_info['current_label'] ); ?>
                            <span class="ame-timezone-diff">
                                (<?php echo $tz_info['offset_hours'] >= 0 ? '+' : ''; ?><?php echo intval( $tz_info['offset_hours'] ); ?>ω από σπίτι)
                            </span>
                        <?php else : ?>
                            <strong>Ζώνη Ώρας:</strong> <?php echo esc_html( $tz_info['home_label'] ); ?>
                        <?php endif; ?>
                    </span>
                    <span class="ame-current-time" id="ame-current-time"><?php echo esc_html( $tz_info['current_time'] ); ?></span>
                </div>
                <div class="ame-timezone-actions">
                    <button class="ame-btn ame-btn-small ame-btn-travel <?php echo esc_attr( $tz_info['travel_mode'] ? 'active' : '' ); ?>" id="ame-toggle-travel">
                        ✈️ <?php echo esc_html( $tz_info['travel_mode'] ? 'Απενεργοποίηση Ταξιδιού' : 'Λειτουργία Ταξιδιού' ); ?>
                    </button>
                    <button class="ame-btn ame-btn-small ame-btn-settings" id="ame-timezone-settings">⚙️</button>
                </div>
            </div>

            <?php if ( $tz_info['travel_mode'] && $tz_info['offset_hours'] != 0 ) : ?>
            <div class="ame-travel-alert">
                <strong>✈️ Ταξιδεύετε!</strong>
                <p>Οι υπενθυμίσεις φαρμάκων προσαρμόζονται στην τοπική ώρα σας.</p>
            </div>
            <?php endif; ?>

            <!-- Stats — reads from mm_doses via AME_Doses::get_stats() -->
            <div class="ame-stats-grid">
                <div class="ame-stat-card ame-stat-taken">
                    <div class="ame-stat-number"><?php echo intval( $stats->taken ); ?></div>
                    <div class="ame-stat-label">Ελήφθησαν</div>
                </div>
                <div class="ame-stat-card ame-stat-missed">
                    <div class="ame-stat-number"><?php echo intval( $stats->missed ); ?></div>
                    <div class="ame-stat-label">Χάθηκαν</div>
                </div>
                <div class="ame-stat-card ame-stat-rate">
                    <div class="ame-stat-number"><?php echo intval( $stats->adherence_rate ); ?>%</div>
                    <div class="ame-stat-label">Συμμόρφωση</div>
                </div>
                <div class="ame-stat-card ame-stat-alerts">
                    <div class="ame-stat-number"><?php echo intval( $unread_count ); ?></div>
                    <div class="ame-stat-label">Ειδοποιήσεις</div>
                </div>
            </div>

            <!-- Today's Schedule — reads from mm_doses -->
            <div class="ame-section">
                <div class="ame-section-header">
                    <h3>📅 Σημερινό Πρόγραμμα</h3>
                    <span class="ame-date"><?php echo date_i18n( 'l, j F Y' ); ?></span>
                </div>

                <?php if ( empty( $todays_schedule ) ) : ?>
                    <div class="ame-empty-state">
                        <p>Δεν υπάρχουν προγραμματισμένες δόσεις για σήμερα.</p>
                    </div>
                <?php else : ?>
                    <div class="ame-schedule-list">
                        <?php foreach ( $todays_schedule as $dose ) : ?>
                            <?php
                            $status_class = 'ame-dose-' . esc_attr( $dose->status );
                            $time_display = esc_html( substr( $dose->scheduled_local_time, 0, 5 ) );
                            ?>
                            <div class="ame-dose-item <?php echo $status_class; ?>" data-dose-id="<?php echo intval( $dose->id ); ?>">
                                <div class="ame-dose-time"><?php echo $time_display; ?></div>
                                <div class="ame-dose-info">
                                    <strong><?php echo esc_html( $dose->medication_name ); ?></strong>
                                    <?php if ( $dose->dosage ) : ?>
                                        <span class="ame-dose-dosage"><?php echo esc_html( $dose->dosage ); ?></span>
                                    <?php endif; ?>
                                    <?php if ( $dose->instructions ) : ?>
                                        <span class="ame-dose-instructions"><?php echo esc_html( $dose->instructions ); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="ame-dose-actions">
                                    <?php if ( $dose->status === 'pending' ) : ?>
                                        <button class="ame-btn ame-btn-taken" data-dose-id="<?php echo intval( $dose->id ); ?>" data-action="taken">
                                            ✓ Το πήρα
                                        </button>
                                        <button class="ame-btn ame-btn-skipped" data-dose-id="<?php echo intval( $dose->id ); ?>" data-action="skipped">
                                            ✕ Παράλειψη
                                        </button>
                                    <?php elseif ( $dose->status === 'taken' ) : ?>
                                        <span class="ame-status-badge ame-status-taken">✓ Ελήφθη</span>
                                        <?php if ( $dose->taken_at ) : ?>
                                            <span class="ame-taken-time"><?php echo esc_html( substr( $dose->taken_at, 11, 5 ) ); ?></span>
                                        <?php endif; ?>
                                    <?php elseif ( $dose->status === 'skipped' ) : ?>
                                        <span class="ame-status-badge ame-status-skipped">Παραλείφθηκε</span>
                                    <?php elseif ( $dose->status === 'missed' ) : ?>
                                        <span class="ame-status-badge ame-status-missed">Χάθηκε</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ( $next_dose && $next_dose->scheduled_local_date > date( 'Y-m-d' ) ) : ?>
                    <div class="ame-next-dose">
                        <strong>Επόμενη δόση:</strong>
                        <?php echo esc_html( $next_dose->medication_name ); ?> —
                        <?php echo esc_html( date_i18n( 'j/n', strtotime( $next_dose->scheduled_local_date ) ) ); ?>
                        στις <?php echo esc_html( substr( $next_dose->scheduled_local_time, 0, 5 ) ); ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Medication Cards -->
            <div class="ame-section">
                <div class="ame-section-header">
                    <h3>💊 Τα Φάρμακά μου</h3>
                    <button class="ame-btn ame-btn-primary" id="ame-add-medication">+ Προσθήκη Φαρμάκου</button>
                </div>

                <?php if ( empty( $medications ) ) : ?>
                    <div class="ame-empty-state">
                        <p>Δεν έχετε καταχωρήσει φάρμακα ακόμα.</p>
                    </div>
                <?php else : ?>
                    <div class="ame-medications-grid">
                        <?php foreach ( $medications as $med ) : ?>
                            <?php
                            $time_slots = json_decode( $med->time_slots, true ) ?: array();
                            $status_badge = '';
                            if ( $med->status === 'paused' ) {
                                $status_badge = '<span class="ame-med-badge ame-badge-paused">Σε Παύση</span>';
                            } elseif ( $med->is_prn ) {
                                $status_badge = '<span class="ame-med-badge ame-badge-prn">PRN</span>';
                            }
                            ?>
                            <div class="ame-medication-card" data-med-id="<?php echo intval( $med->id ); ?>">
                                <div class="ame-med-header">
                                    <h4><?php echo esc_html( $med->medication_name ); ?> <?php echo $status_badge; ?></h4>
                                    <div class="ame-med-actions">
                                        <button class="ame-btn-icon ame-edit-med" data-med-id="<?php echo intval( $med->id ); ?>" title="Επεξεργασία">✏️</button>
                                        <?php if ( $med->status === 'paused' ) : ?>
                                            <button class="ame-btn-icon ame-resume-med" data-med-id="<?php echo intval( $med->id ); ?>" title="Επανέναρξη">▶️</button>
                                        <?php else : ?>
                                            <button class="ame-btn-icon ame-pause-med" data-med-id="<?php echo intval( $med->id ); ?>" title="Παύση">⏸️</button>
                                        <?php endif; ?>
                                        <button class="ame-btn-icon ame-delete-med" data-med-id="<?php echo intval( $med->id ); ?>" title="Διαγραφή">🗑️</button>
                                    </div>
                                </div>
                                <div class="ame-med-details">
                                    <?php if ( $med->dosage ) : ?>
                                        <span class="ame-med-dosage">💊 <?php echo esc_html( $med->dosage ); ?></span>
                                    <?php endif; ?>
                                    <?php if ( ! empty( $time_slots ) && ! $med->is_prn ) : ?>
                                        <span class="ame-med-times">🕐 <?php echo esc_html( implode( ', ', $time_slots ) ); ?></span>
                                    <?php elseif ( $med->is_prn ) : ?>
                                        <span class="ame-med-times">Κατ' ανάγκη (PRN)</span>
                                    <?php endif; ?>
                                    <?php if ( $med->start_date ) : ?>
                                        <span class="ame-med-dates">📆 Από <?php echo esc_html( date_i18n( 'd/m/Y', strtotime( $med->start_date ) ) ); ?>
                                        <?php if ( $med->end_date ) : ?>
                                            έως <?php echo esc_html( date_i18n( 'd/m/Y', strtotime( $med->end_date ) ) ); ?>
                                        <?php endif; ?></span>
                                    <?php endif; ?>
                                    <?php if ( $med->instructions ) : ?>
                                        <span class="ame-med-instructions">ℹ️ <?php echo esc_html( $med->instructions ); ?></span>
                                    <?php endif; ?>
                                    <?php if ( $med->is_prn ) : ?>
                                        <button class="ame-btn ame-btn-prn" data-med-id="<?php echo intval( $med->id ); ?>">
                                            + Καταγραφή Λήψης
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Alerts Section -->
            <?php if ( ! empty( $alerts ) ) : ?>
            <div class="ame-section">
                <div class="ame-section-header">
                    <h3>🔔 Ειδοποιήσεις <?php if ( $unread_count > 0 ) : ?><span class="ame-badge"><?php echo intval( $unread_count ); ?></span><?php endif; ?></h3>
                    <?php if ( $unread_count > 0 ) : ?>
                        <button class="ame-btn ame-btn-small" id="ame-mark-all-read">Σήμανση όλων ως αναγνωσμένων</button>
                    <?php endif; ?>
                </div>
                <div class="ame-alerts-list">
                    <?php foreach ( $alerts as $alert ) : ?>
                        <div class="ame-alert-item <?php echo $alert->is_read ? 'ame-alert-read' : 'ame-alert-unread'; ?>" data-alert-id="<?php echo intval( $alert->id ); ?>">
                            <div class="ame-alert-message"><?php echo esc_html( $alert->message ); ?></div>
                            <div class="ame-alert-time"><?php echo esc_html( date_i18n( 'd/m/Y H:i', strtotime( $alert->created_at ) ) ); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Push Notifications Section -->
            <div class="ame-section ame-push-section" id="ame-push-section">
                <div class="ame-section-header">
                    <h3>🔔 Υπενθυμίσεις Push</h3>
                </div>
                <div id="ame-push-status">Έλεγχος κατάστασης...</div>
                <button class="ame-btn ame-btn-primary" id="ame-enable-push" style="display:none;">Ενεργοποίηση Υπενθυμίσεων</button>
                <button class="ame-btn ame-btn-secondary" id="ame-test-push" style="display:none;">Δοκιμή Ειδοποίησης</button>
            </div>

        </div><!-- .ame-dashboard -->

        <!-- Add/Edit Medication Modal -->
        <div class="ame-modal" id="ame-medication-modal" style="display:none;">
            <div class="ame-modal-content">
                <div class="ame-modal-header">
                    <h3 id="ame-modal-title">Προσθήκη Φαρμάκου</h3>
                    <button class="ame-modal-close" id="ame-close-modal">&times;</button>
                </div>
                <form id="ame-medication-form">
                    <input type="hidden" name="medication_id" id="ame-medication-id" value="">
                    <div class="ame-form-group">
                        <label>Όνομα Φαρμάκου *</label>
                        <input type="text" name="medication_name" id="ame-medication-name" required>
                    </div>
                    <div class="ame-form-group">
                        <label>Δοσολογία</label>
                        <input type="text" name="dosage" id="ame-dosage" placeholder="π.χ. 100mg, 1 δισκίο">
                    </div>
                    <div class="ame-form-group">
                        <label>Τύπος Συχνότητας</label>
                        <select name="frequency_type" id="ame-frequency-type">
                            <option value="fixed_daily">Σταθερή Ημερήσια</option>
                            <option value="weekdays">Συγκεκριμένες Ημέρες</option>
                            <option value="interval_hours">Κάθε Χ Ώρες</option>
                            <option value="prn">Κατ' Ανάγκη (PRN)</option>
                            <option value="short_course">Βραχεία Αγωγή</option>
                            <option value="chronic">Χρόνια Αγωγή</option>
                        </select>
                    </div>
                    <div class="ame-form-group" id="ame-time-slots-group">
                        <label>Ώρες Λήψης</label>
                        <div id="ame-time-slots-container">
                            <input type="text" class="ame-time-slot" placeholder="09:00">
                        </div>
                        <button type="button" class="ame-btn ame-btn-small" id="ame-add-time-slot">+ Ώρα</button>
                    </div>
                    <div class="ame-form-group" id="ame-interval-group" style="display:none;">
                        <label>Κάθε πόσες ώρες;</label>
                        <input type="number" name="interval_hours" id="ame-interval-hours" min="1" max="24" value="8">
                    </div>
                    <div class="ame-form-group" id="ame-weekdays-group" style="display:none;">
                        <label>Ημέρες Εβδομάδας</label>
                        <div class="ame-weekdays-picker">
                            <label><input type="checkbox" name="weekdays[]" value="1"> Δευ</label>
                            <label><input type="checkbox" name="weekdays[]" value="2"> Τρι</label>
                            <label><input type="checkbox" name="weekdays[]" value="3"> Τετ</label>
                            <label><input type="checkbox" name="weekdays[]" value="4"> Πεμ</label>
                            <label><input type="checkbox" name="weekdays[]" value="5"> Παρ</label>
                            <label><input type="checkbox" name="weekdays[]" value="6"> Σαβ</label>
                            <label><input type="checkbox" name="weekdays[]" value="0"> Κυρ</label>
                        </div>
                    </div>
                    <div class="ame-form-row">
                        <div class="ame-form-group">
                            <label>Ημερομηνία Έναρξης *</label>
                            <input type="text" name="start_date" id="ame-start-date" placeholder="dd/mm/yyyy" required>
                        </div>
                        <div class="ame-form-group">
                            <label>Ημερομηνία Λήξης</label>
                            <input type="text" name="end_date" id="ame-end-date" placeholder="dd/mm/yyyy">
                        </div>
                    </div>
                    <div class="ame-form-group">
                        <label>Οδηγίες</label>
                        <textarea name="instructions" id="ame-instructions" rows="3" placeholder="π.χ. Με φαγητό"></textarea>
                    </div>
                    <div class="ame-form-group">
                        <label>Ένδειξη / Λόγος</label>
                        <input type="text" name="indication" id="ame-indication" placeholder="π.χ. Αρθρίτιδα">
                    </div>
                    <div class="ame-form-group">
                        <label><input type="checkbox" name="is_prn" id="ame-is-prn" value="1"> Κατ' ανάγκη (PRN)</label>
                    </div>
                    <div class="ame-modal-footer">
                        <button type="submit" class="ame-btn ame-btn-primary">Αποθήκευση</button>
                        <button type="button" class="ame-btn ame-btn-secondary" id="ame-cancel-modal">Ακύρωση</button>
                    </div>
                </form>
            </div>
        </div>

        <?php
        return ob_get_clean();
    }
}

<?php
/**
 * AME_Symptoms — v13.0.0
 * Symptom logging (delegates to existing mm_symptoms table if present).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_Symptoms {

    public static function log( $user_id, $symptom, $severity = 0, $description = '' ) {
        global $wpdb;
        $t = $wpdb->prefix . 'mm_symptoms';

        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$t}'" ) !== $t ) {
            return false;
        }

        return $wpdb->insert( $t, array(
            'user_id'     => intval( $user_id ),
            'symptom'     => sanitize_text_field( $symptom ),
            'severity'    => intval( $severity ),
            'description' => sanitize_textarea_field( $description ),
            'logged_at'   => current_time( 'mysql' ),
        ), array( '%d', '%s', '%d', '%s', '%s' ) );
    }
}

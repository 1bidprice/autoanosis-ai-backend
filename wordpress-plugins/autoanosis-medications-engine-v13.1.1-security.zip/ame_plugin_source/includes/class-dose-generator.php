<?php
/**
 * AME_DoseGenerator — v13.0.0
 *
 * Single dose generation engine. Writes ONLY to mm_doses.
 * Supports: fixed_daily, interval_hours, weekdays, prn, short_course, chronic.
 *
 * PRN medications do NOT generate scheduled doses — they are logged on-demand.
 * All times are stored in user home timezone; due_at_utc is the canonical sort key.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_DoseGenerator {

    /**
     * Generate doses for a single medication.
     *
     * @param int $medication_id
     * @param int $days_ahead  Rolling horizon (default 30)
     * @return int Number of new dose rows inserted
     */
    public static function generate_for_medication( $medication_id, $days_ahead = 30 ) {
        $med = AME_Medications::get( $medication_id );

        if ( ! $med || ! $med->active || $med->status === 'stopped' ) {
            return 0;
        }

        // PRN medications do not get pre-scheduled doses
        if ( $med->is_prn || $med->frequency_type === 'prn' ) {
            return 0;
        }

        $home_tz = new DateTimeZone( AME_Timezone::get_home_timezone( $med->patient_id ) );
        $utc_tz  = new DateTimeZone( 'UTC' );

        $today = new DateTime( 'today', $home_tz );
        $start = new DateTime( $med->start_date, $home_tz );

        // Start from today or medication start, whichever is later
        $gen_start = ( $start > $today ) ? clone $start : clone $today;

        // End: rolling horizon or medication end_date, whichever is sooner
        $gen_end = clone $gen_start;
        $gen_end->modify( "+{$days_ahead} days" );

        if ( $med->end_date ) {
            $med_end = new DateTime( $med->end_date, $home_tz );
            if ( $med_end < $gen_end ) {
                $gen_end = clone $med_end;
            }
        }

        switch ( $med->frequency_type ) {
            case 'fixed_daily':
            case 'short_course':
            case 'chronic':
                return self::generate_fixed_daily( $med, $gen_start, $gen_end, $home_tz, $utc_tz );

            case 'weekdays':
                return self::generate_weekdays( $med, $gen_start, $gen_end, $home_tz, $utc_tz );

            case 'interval_hours':
                return self::generate_interval_hours( $med, $gen_start, $gen_end, $home_tz, $utc_tz );

            default:
                // Fallback to fixed_daily if frequency_type is unrecognised
                return self::generate_fixed_daily( $med, $gen_start, $gen_end, $home_tz, $utc_tz );
        }
    }

    /**
     * Regenerate doses for ALL active medications.
     * Used by cron top-up job and on plugin activation.
     */
    public static function regenerate_all( $days_ahead = 30 ) {
        $medications = AME_Medications::get_all_active();
        $total       = 0;
        foreach ( $medications as $med ) {
            $total += self::generate_for_medication( $med->id, $days_ahead );
        }
        return $total;
    }

    // ─── GENERATORS ──────────────────────────────────────────────────────────

    /**
     * Fixed daily: one dose per time_slot per day.
     */
    private static function generate_fixed_daily( $med, $gen_start, $gen_end, $home_tz, $utc_tz ) {
        $time_slots = json_decode( $med->time_slots, true );
        if ( empty( $time_slots ) || ! is_array( $time_slots ) ) {
            return 0;
        }

        $count   = 0;
        $current = clone $gen_start;

        while ( $current <= $gen_end ) {
            foreach ( $time_slots as $slot ) {
                $count += self::insert_dose( $med, $current, $slot, $home_tz, $utc_tz );
            }
            $current->modify( '+1 day' );
        }

        return $count;
    }

    /**
     * Weekday-specific: doses only on specified weekdays.
     * weekdays stored as JSON array of integers (0=Sunday … 6=Saturday).
     */
    private static function generate_weekdays( $med, $gen_start, $gen_end, $home_tz, $utc_tz ) {
        $time_slots = json_decode( $med->time_slots, true );
        $weekdays   = json_decode( $med->weekdays, true );

        if ( empty( $time_slots ) || ! is_array( $time_slots ) ) {
            return 0;
        }
        if ( empty( $weekdays ) || ! is_array( $weekdays ) ) {
            return 0;
        }

        $count   = 0;
        $current = clone $gen_start;

        while ( $current <= $gen_end ) {
            $dow = intval( $current->format( 'w' ) ); // 0=Sun
            if ( in_array( $dow, $weekdays, true ) ) {
                foreach ( $time_slots as $slot ) {
                    $count += self::insert_dose( $med, $current, $slot, $home_tz, $utc_tz );
                }
            }
            $current->modify( '+1 day' );
        }

        return $count;
    }

    /**
     * Interval hours: e.g. every 8h or every 12h.
     * First dose at the first time_slot on start day; subsequent doses at +interval_hours.
     */
    private static function generate_interval_hours( $med, $gen_start, $gen_end, $home_tz, $utc_tz ) {
        $time_slots     = json_decode( $med->time_slots, true );
        $interval_hours = intval( $med->interval_hours );

        if ( empty( $time_slots ) || ! is_array( $time_slots ) || $interval_hours < 1 ) {
            return 0;
        }

        // First dose: first slot on gen_start day
        $first_slot = $time_slots[0];
        list( $h, $m ) = explode( ':', $first_slot );

        $current = clone $gen_start;
        $current->setTime( intval( $h ), intval( $m ), 0 );

        $count = 0;

        while ( $current <= $gen_end ) {
            $slot = $current->format( 'H:i' );
            $count += self::insert_dose( $med, $current, $slot, $home_tz, $utc_tz );
            $current->modify( "+{$interval_hours} hours" );
        }

        return $count;
    }

    // ─── CORE INSERT ─────────────────────────────────────────────────────────

    /**
     * Insert a single dose row (idempotent via unique_key).
     *
     * @param object    $med      Medication row
     * @param DateTime  $date     Date (in home_tz)
     * @param string    $slot     HH:MM
     * @param DateTimeZone $home_tz
     * @param DateTimeZone $utc_tz
     * @return int 1 if inserted, 0 if duplicate/skipped
     */
    private static function insert_dose( $med, $date, $slot, $home_tz, $utc_tz ) {
        global $wpdb;

        list( $h, $m ) = explode( ':', $slot );

        // Build local datetime
        $local_dt = clone $date;
        $local_dt->setTimezone( $home_tz );
        $local_dt->setTime( intval( $h ), intval( $m ), 0 );

        // Convert to UTC for canonical sort key
        $utc_dt = clone $local_dt;
        $utc_dt->setTimezone( $utc_tz );

        // Skip if due_at_utc is in the past (more than 5 min ago)
        $now_utc = new DateTime( 'now', $utc_tz );
        $cutoff  = clone $now_utc;
        $cutoff->modify( '-5 minutes' );
        if ( $utc_dt < $cutoff ) {
            return 0;
        }

        $unique_key = sprintf(
            '%d-%d-%s-%s',
            $med->patient_id,
            $med->id,
            $local_dt->format( 'Ymd' ),
            $local_dt->format( 'Hi' )
        );

        $doses_table = AME_Database::table( 'doses' );

        $result = $wpdb->query( $wpdb->prepare(
            "INSERT IGNORE INTO {$doses_table}
             (medication_id, user_id, medication_version, scheduled_local_date, scheduled_local_time,
              scheduled_timezone, due_at_utc, status, reminder_state, grace_window_minutes, unique_key, created_at)
             VALUES (%d, %d, %d, %s, %s, %s, %s, 'pending', 'not_sent', 60, %s, NOW())",
            $med->id,
            $med->patient_id,
            intval( $med->version ),
            $local_dt->format( 'Y-m-d' ),
            $local_dt->format( 'H:i:s' ),
            $home_tz->getName(),
            $utc_dt->format( 'Y-m-d H:i:s' ),
            $unique_key
        ) );

        return intval( $result );
    }

    // ─── PRN INTAKE ──────────────────────────────────────────────────────────

    /**
     * Log a PRN (as-needed) intake.
     * Creates a dose row on the fly and marks it taken immediately.
     *
     * @param int    $medication_id
     * @param int    $user_id
     * @param string $note Optional note
     * @return int|false dose_id or false
     */
    public static function log_prn_intake( $medication_id, $user_id, $note = '' ) {
        global $wpdb;

        $med = AME_Medications::get( $medication_id );
        if ( ! $med || $med->patient_id != $user_id ) {
            return false;
        }

        $home_tz  = new DateTimeZone( AME_Timezone::get_home_timezone( $user_id ) );
        $utc_tz   = new DateTimeZone( 'UTC' );
        $now_local = new DateTime( 'now', $home_tz );
        $now_utc   = new DateTime( 'now', $utc_tz );

        $unique_key = sprintf(
            'prn-%d-%d-%s',
            $user_id,
            $medication_id,
            $now_utc->format( 'YmdHis' )
        );

        $doses_table = AME_Database::table( 'doses' );

        $wpdb->insert( $doses_table, array(
            'medication_id'          => $medication_id,
            'user_id'                => $user_id,
            'medication_version'     => intval( $med->version ),
            'scheduled_local_date'   => $now_local->format( 'Y-m-d' ),
            'scheduled_local_time'   => $now_local->format( 'H:i:s' ),
            'scheduled_timezone'     => $home_tz->getName(),
            'due_at_utc'             => $now_utc->format( 'Y-m-d H:i:s' ),
            'status'                 => 'taken',
            'taken_at'               => $now_local->format( 'Y-m-d H:i:s' ),
            'confirmation_source'    => 'user_ui',
            'note'                   => sanitize_textarea_field( $note ),
            'reminder_state'         => 'suppressed',
            'unique_key'             => $unique_key,
            'created_at'             => current_time( 'mysql' ),
        ), array( '%d','%d','%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s' ) );

        return $wpdb->insert_id ?: false;
    }
}

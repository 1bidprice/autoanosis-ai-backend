<?php
/**
 * AME_Timezone — v13.0.0
 *
 * Timezone management for Medications Engine.
 *
 * Architecture:
 *   - home_timezone: user's permanent home timezone (stored in usermeta)
 *   - current_timezone: detected/active timezone (may differ when travelling)
 *   - travel_mode: boolean — when true, reminders use current_timezone
 *   - due_at_utc: canonical UTC datetime — always correct regardless of timezone
 *
 * All dose times are stored in home_timezone.
 * due_at_utc is the single source of truth for cron scheduling.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_Timezone {

    const META_HOME_TZ     = 'ame_home_timezone';
    const META_CURRENT_TZ  = 'ame_current_timezone';
    const META_TRAVEL_MODE = 'ame_travel_mode';
    const DEFAULT_TZ       = 'Europe/Athens';

    public static function get_home_timezone( $user_id ) {
        $tz = get_user_meta( $user_id, self::META_HOME_TZ, true );
        if ( ! $tz || ! self::is_valid_timezone( $tz ) ) {
            $tz = get_option( 'timezone_string', self::DEFAULT_TZ ) ?: self::DEFAULT_TZ;
        }
        return $tz;
    }

    public static function set_home_timezone( $user_id, $timezone ) {
        if ( ! self::is_valid_timezone( $timezone ) ) {
            return false;
        }
        update_user_meta( $user_id, self::META_HOME_TZ, $timezone );
        return true;
    }

    public static function get_current_timezone( $user_id ) {
        $travel = get_user_meta( $user_id, self::META_TRAVEL_MODE, true );
        if ( $travel ) {
            $tz = get_user_meta( $user_id, self::META_CURRENT_TZ, true );
            if ( $tz && self::is_valid_timezone( $tz ) ) {
                return $tz;
            }
        }
        return self::get_home_timezone( $user_id );
    }

    public static function set_current_timezone( $user_id, $timezone ) {
        if ( ! self::is_valid_timezone( $timezone ) ) {
            return false;
        }
        update_user_meta( $user_id, self::META_CURRENT_TZ, $timezone );
        return true;
    }

    public static function is_travel_mode( $user_id ) {
        return (bool) get_user_meta( $user_id, self::META_TRAVEL_MODE, true );
    }

    public static function toggle_travel_mode( $user_id ) {
        $current = self::is_travel_mode( $user_id );
        $new     = ! $current;
        update_user_meta( $user_id, self::META_TRAVEL_MODE, $new ? '1' : '0' );
        return self::get_timezone_info( $user_id );
    }

    /**
     * Get full timezone info for a user (for JS localization and UI).
     */
    public static function get_timezone_info( $user_id ) {
        $home_tz    = self::get_home_timezone( $user_id );
        $current_tz = self::get_current_timezone( $user_id );
        $travel     = self::is_travel_mode( $user_id );

        $home_dt    = new DateTime( 'now', new DateTimeZone( $home_tz ) );
        $current_dt = new DateTime( 'now', new DateTimeZone( $current_tz ) );

        $home_offset    = $home_dt->getOffset() / 3600;
        $current_offset = $current_dt->getOffset() / 3600;
        $diff           = $current_offset - $home_offset;

        return array(
            'home_timezone'    => $home_tz,
            'current_timezone' => $current_tz,
            'home_label'       => self::format_tz_label( $home_tz, $home_offset ),
            'current_label'    => self::format_tz_label( $current_tz, $current_offset ),
            'home_offset'      => $home_offset,
            'current_offset'   => $current_offset,
            'offset_hours'     => $diff,
            'travel_mode'      => $travel,
            'current_time'     => $current_dt->format( 'H:i' ),
            'home_time'        => $home_dt->format( 'H:i' ),
        );
    }

    private static function format_tz_label( $tz_name, $offset ) {
        $sign  = $offset >= 0 ? '+' : '-';
        $abs   = abs( $offset );
        $hours = floor( $abs );
        $mins  = ( $abs - $hours ) * 60;
        $utc   = sprintf( 'UTC%s%02d:%02d', $sign, $hours, $mins );
        return $tz_name . ' (' . $utc . ')';
    }

    public static function is_valid_timezone( $tz ) {
        if ( empty( $tz ) ) {
            return false;
        }
        try {
            new DateTimeZone( $tz );
            return true;
        } catch ( Exception $e ) {
            return false;
        }
    }
}

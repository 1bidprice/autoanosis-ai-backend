<?php
/**
 * AME_Medications — v13.0.0
 *
 * CRUD for mm_medications master table.
 * Supports: fixed_daily, interval_hours, weekdays, prn, short_course, chronic.
 * On add/update: triggers AME_DoseGenerator to populate mm_doses.
 * NEVER writes to mm_adherence.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_Medications {

    // ─── READ ────────────────────────────────────────────────────────────────

    public static function get( $id ) {
        global $wpdb;
        $t = AME_Database::table( 'medications' );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ) );
    }

    public static function get_by_patient( $patient_id, $active_only = true ) {
        global $wpdb;
        $t   = AME_Database::table( 'medications' );
        $sql = "SELECT * FROM {$t} WHERE patient_id = %d";
        if ( $active_only ) {
            $sql .= " AND active = 1 AND status != 'stopped'";
        }
        $sql .= ' ORDER BY medication_name ASC';
        return $wpdb->get_results( $wpdb->prepare( $sql, $patient_id ) );
    }

    public static function get_all_active() {
        global $wpdb;
        $t = AME_Database::table( 'medications' );
        return $wpdb->get_results(
            "SELECT * FROM {$t} WHERE active = 1 AND status = 'active' ORDER BY medication_name ASC"
        );
    }

    /**
     * Get today's schedule for a user from mm_doses (ONE TRUTH).
     * Returns dose rows joined with medication name/dosage.
     */
    public static function get_todays_schedule( $user_id ) {
        global $wpdb;
        $doses_table = AME_Database::table( 'doses' );
        $meds_table  = AME_Database::table( 'medications' );

        $tz   = AME_Timezone::get_home_timezone( $user_id );
        $today = ( new DateTime( 'today', new DateTimeZone( $tz ) ) )->format( 'Y-m-d' );

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT d.*, m.medication_name, m.dosage, m.instructions, m.is_prn
             FROM {$doses_table} d
             JOIN {$meds_table} m ON d.medication_id = m.id
             WHERE d.user_id = %d
               AND d.scheduled_local_date = %s
               AND d.status != 'cancelled'
             ORDER BY d.scheduled_local_time ASC",
            $user_id,
            $today
        ) );
    }

    // ─── WRITE ───────────────────────────────────────────────────────────────

    /**
     * Add a new medication.
     * Returns medication_id (int) or WP_Error.
     */
    public static function add( $data ) {
        global $wpdb;
        $t = AME_Database::table( 'medications' );

        $validated = self::validate_and_sanitize( $data );
        if ( is_wp_error( $validated ) ) {
            return $validated;
        }

        $result = $wpdb->insert( $t, $validated['db_data'], $validated['formats'] );

        if ( ! $result ) {
            return new WP_Error( 'db_error', 'Αποτυχία αποθήκευσης φαρμάκου: ' . $wpdb->last_error );
        }

        $medication_id = $wpdb->insert_id;

        // Generate dose instances — ONLY mm_doses, never mm_adherence
        AME_DoseGenerator::generate_for_medication( $medication_id, 30 );

        return $medication_id;
    }

    /**
     * Update an existing medication.
     * Increments version, regenerates future pending doses.
     * Returns true or WP_Error.
     */
    public static function update( $id, $data ) {
        global $wpdb;
        $t = AME_Database::table( 'medications' );

        $current = self::get( $id );
        if ( ! $current ) {
            return new WP_Error( 'not_found', 'Φάρμακο δεν βρέθηκε.' );
        }

        $validated = self::validate_and_sanitize( $data, true );
        if ( is_wp_error( $validated ) ) {
            return $validated;
        }

        // Increment version on schedule change
        $schedule_changed = isset( $data['time_slots'] ) || isset( $data['frequency_type'] )
            || isset( $data['interval_hours'] ) || isset( $data['weekdays'] )
            || isset( $data['start_date'] ) || isset( $data['end_date'] );

        if ( $schedule_changed ) {
            $validated['db_data']['version'] = intval( $current->version ) + 1;
            $validated['formats'][]          = '%d';
        }

        $result = $wpdb->update( $t, $validated['db_data'], array( 'id' => $id ), $validated['formats'], array( '%d' ) );

        if ( $result === false ) {
            return new WP_Error( 'db_error', 'Αποτυχία ενημέρωσης φαρμάκου: ' . $wpdb->last_error );
        }

        if ( $schedule_changed ) {
            // Cancel future pending doses for old schedule
            $doses_table = AME_Database::table( 'doses' );
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$doses_table}
                 SET status = 'cancelled', updated_at = NOW()
                 WHERE medication_id = %d
                   AND status = 'pending'
                   AND due_at_utc > NOW()",
                $id
            ) );
            // Generate new doses from today
            AME_DoseGenerator::generate_for_medication( $id, 30 );
        }

        return true;
    }

    /**
     * Soft-delete (set active = 0, status = stopped).
     * Cancels all future pending doses.
     */
    public static function delete( $id ) {
        global $wpdb;
        $t = AME_Database::table( 'medications' );

        $wpdb->update(
            $t,
            array( 'active' => 0, 'status' => 'stopped', 'updated_at' => current_time( 'mysql' ) ),
            array( 'id' => $id ),
            array( '%d', '%s', '%s' ),
            array( '%d' )
        );

        // Cancel all future pending doses
        $doses_table = AME_Database::table( 'doses' );
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$doses_table}
             SET status = 'cancelled', updated_at = NOW()
             WHERE medication_id = %d AND status = 'pending' AND due_at_utc > NOW()",
            $id
        ) );

        return true;
    }

    /**
     * Pause a medication (temporary stop).
     */
    public static function pause( $id ) {
        global $wpdb;
        $t = AME_Database::table( 'medications' );
        $wpdb->update(
            $t,
            array( 'status' => 'paused', 'updated_at' => current_time( 'mysql' ) ),
            array( 'id' => $id ),
            array( '%s', '%s' ),
            array( '%d' )
        );
        // Suppress future pending doses (set reminder_state = suppressed)
        $doses_table = AME_Database::table( 'doses' );
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$doses_table}
             SET reminder_state = 'suppressed', updated_at = NOW()
             WHERE medication_id = %d AND status = 'pending' AND due_at_utc > NOW()",
            $id
        ) );
        return true;
    }

    /**
     * Resume a paused medication.
     */
    public static function resume( $id ) {
        global $wpdb;
        $t = AME_Database::table( 'medications' );
        $wpdb->update(
            $t,
            array( 'status' => 'active', 'updated_at' => current_time( 'mysql' ) ),
            array( 'id' => $id ),
            array( '%s', '%s' ),
            array( '%d' )
        );
        // Restore suppressed pending doses
        $doses_table = AME_Database::table( 'doses' );
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$doses_table}
             SET reminder_state = 'not_sent', updated_at = NOW()
             WHERE medication_id = %d AND status = 'pending'
               AND reminder_state = 'suppressed' AND due_at_utc > NOW()",
            $id
        ) );
        return true;
    }

    // ─── VALIDATION ──────────────────────────────────────────────────────────

    /**
     * Validate and sanitize input data.
     * Returns array( 'db_data' => [...], 'formats' => [...] ) or WP_Error.
     *
     * @param array $data     Input data.
     * @param bool  $partial  If true, only validate fields that are present (for updates).
     */
    private static function validate_and_sanitize( $data, $partial = false ) {
        $db_data = array();
        $formats = array();
        $errors  = array();

        // medication_name (required on add)
        if ( isset( $data['medication_name'] ) ) {
            $val = sanitize_text_field( $data['medication_name'] );
            if ( empty( $val ) ) {
                $errors[] = 'Το όνομα φαρμάκου είναι υποχρεωτικό.';
            } else {
                $db_data['medication_name'] = $val;
                $formats[]                  = '%s';
            }
        } elseif ( ! $partial ) {
            $errors[] = 'Το όνομα φαρμάκου είναι υποχρεωτικό.';
        }

        // patient_id (required on add)
        if ( isset( $data['patient_id'] ) ) {
            $db_data['patient_id'] = intval( $data['patient_id'] );
            $formats[]             = '%d';
        } elseif ( ! $partial ) {
            $errors[] = 'patient_id είναι υποχρεωτικό.';
        }

        // Optional string fields
        $string_fields = array(
            'active_ingredient', 'dosage', 'unit', 'instructions',
            'frequency', 'prescribed_by', 'indication',
        );
        foreach ( $string_fields as $field ) {
            if ( isset( $data[ $field ] ) ) {
                $db_data[ $field ] = sanitize_text_field( $data[ $field ] );
                $formats[]         = '%s';
            }
        }

        // frequency_type
        $valid_freq_types = array( 'fixed_daily', 'interval_hours', 'weekdays', 'prn', 'short_course', 'chronic' );
        if ( isset( $data['frequency_type'] ) ) {
            if ( ! in_array( $data['frequency_type'], $valid_freq_types, true ) ) {
                $errors[] = 'Μη έγκυρος τύπος συχνότητας.';
            } else {
                $db_data['frequency_type'] = $data['frequency_type'];
                $formats[]                 = '%s';
            }
        }

        // time_slots (JSON array of HH:MM)
        if ( isset( $data['time_slots'] ) ) {
            $slots = is_array( $data['time_slots'] ) ? $data['time_slots'] : json_decode( stripslashes( $data['time_slots'] ), true );
            if ( ! is_array( $slots ) ) {
                $slots = array();
            }
            foreach ( $slots as $slot ) {
                if ( ! preg_match( '/^([01]?\d|2[0-3]):[0-5]\d$/', trim( $slot ) ) ) {
                    $errors[] = 'Λάθος μορφή ώρας: ' . esc_html( $slot ) . '. Χρησιμοποιήστε HH:MM.';
                }
            }
            $db_data['time_slots'] = wp_json_encode( array_values( $slots ) );
            $formats[]             = '%s';
        }

        // interval_hours
        if ( isset( $data['interval_hours'] ) ) {
            $ih = intval( $data['interval_hours'] );
            if ( $ih < 1 || $ih > 24 ) {
                $errors[] = 'interval_hours πρέπει να είναι 1–24.';
            } else {
                $db_data['interval_hours'] = $ih;
                $formats[]                 = '%d';
            }
        }

        // weekdays (JSON array of 0-6, 0=Sunday)
        if ( isset( $data['weekdays'] ) ) {
            $wd = is_array( $data['weekdays'] ) ? $data['weekdays'] : json_decode( stripslashes( $data['weekdays'] ), true );
            if ( ! is_array( $wd ) ) {
                $wd = array();
            }
            $db_data['weekdays'] = wp_json_encode( array_values( array_map( 'intval', $wd ) ) );
            $formats[]           = '%s';
        }

        // start_date (required on add)
        if ( isset( $data['start_date'] ) ) {
            $parsed = self::parse_date( $data['start_date'] );
            if ( $parsed === false ) {
                $errors[] = 'Λάθος μορφή ημερομηνίας έναρξης. Χρησιμοποιήστε dd/mm/yyyy ή yyyy-mm-dd.';
            } else {
                $db_data['start_date'] = $parsed;
                $formats[]             = '%s';
            }
        } elseif ( ! $partial ) {
            $errors[] = 'Η ημερομηνία έναρξης είναι υποχρεωτική.';
        }

        // end_date (optional)
        if ( isset( $data['end_date'] ) ) {
            if ( ! empty( $data['end_date'] ) ) {
                $parsed = self::parse_date( $data['end_date'] );
                if ( $parsed === false ) {
                    $errors[] = 'Λάθος μορφή ημερομηνίας λήξης.';
                } else {
                    $db_data['end_date'] = $parsed;
                    $formats[]           = '%s';
                }
            } else {
                $db_data['end_date'] = null;
                $formats[]           = '%s';
            }
        }

        // status
        $valid_statuses = array( 'active', 'paused', 'stopped', 'completed' );
        if ( isset( $data['status'] ) ) {
            if ( in_array( $data['status'], $valid_statuses, true ) ) {
                $db_data['status'] = $data['status'];
                $formats[]         = '%s';
            }
        }

        // is_prn
        if ( isset( $data['is_prn'] ) ) {
            $db_data['is_prn'] = intval( (bool) $data['is_prn'] );
            $formats[]         = '%d';
        }

        // timezone_mode
        if ( isset( $data['timezone_mode'] ) ) {
            $db_data['timezone_mode'] = in_array( $data['timezone_mode'], array( 'home', 'travel' ), true )
                ? $data['timezone_mode'] : 'home';
            $formats[] = '%s';
        }

        // active (soft-delete flag)
        if ( isset( $data['active'] ) ) {
            $db_data['active'] = intval( (bool) $data['active'] );
            $formats[]         = '%d';
        }

        // updated_at
        $db_data['updated_at'] = current_time( 'mysql' );
        $formats[]             = '%s';

        if ( ! $partial ) {
            $db_data['created_at'] = current_time( 'mysql' );
            $formats[]             = '%s';
        }

        if ( ! empty( $errors ) ) {
            return new WP_Error( 'validation_error', implode( ' ', $errors ) );
        }

        return array( 'db_data' => $db_data, 'formats' => $formats );
    }

    /**
     * Parse date from multiple formats to Y-m-d.
     * Returns false on failure, null on empty.
     */
    public static function parse_date( $date_string ) {
        if ( empty( $date_string ) ) {
            return null;
        }
        $date_string = trim( $date_string );

        // Already Y-m-d
        if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_string ) ) {
            return $date_string;
        }
        // d/m/Y
        $d = DateTime::createFromFormat( 'd/m/Y', $date_string );
        if ( $d ) {
            return $d->format( 'Y-m-d' );
        }
        // d-m-Y
        $d = DateTime::createFromFormat( 'd-m-Y', $date_string );
        if ( $d ) {
            return $d->format( 'Y-m-d' );
        }
        return false;
    }
}

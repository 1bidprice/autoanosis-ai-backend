<?php
/**
 * AME_Cron — v13.0.0
 *
 * Cron job engine for Medications Engine.
 *
 * READ CONTRACT:
 *   - Reads ONLY mm_doses (never mm_adherence)
 *   - Sends notifications ONLY for doses where status='pending' AND reminder_state NOT IN ('suppressed','sent','queued')
 *   - Marks missed doses (status=pending, past grace window)
 *   - Top-up dose generation (rolling 30-day horizon)
 *
 * SUPPRESSION RULES:
 *   - If dose.status = 'taken' → reminder_state = 'suppressed' (set at mark_taken time)
 *   - If dose.status = 'skipped' → reminder_state = 'suppressed'
 *   - If medication.status = 'paused' → reminder_state = 'suppressed'
 *   - If medication.status = 'stopped' → dose.status = 'cancelled'
 *   - If send_attempts >= 3 → reminder_state = 'failed' (no more retries)
 *
 * DUPLICATE PREVENTION:
 *   - Atomic claim via UPDATE WHERE reminder_state NOT IN ('queued','sent',...)
 *   - unique_key on mm_doses prevents duplicate dose rows
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AME_Cron {

    // Cron hook names
    const HOOK_SEND_REMINDERS  = 'ame_send_reminders';
    const HOOK_MARK_MISSED     = 'ame_mark_missed';
    const HOOK_TOPUP_DOSES     = 'ame_topup_doses';
    const HOOK_CLEANUP         = 'ame_cleanup';

    // How many minutes before due_at_utc to send the reminder
    const REMINDER_LEAD_MINUTES = 10;

    public static function init() {
        add_action( self::HOOK_SEND_REMINDERS, array( __CLASS__, 'run_send_reminders' ) );
        add_action( self::HOOK_MARK_MISSED,    array( __CLASS__, 'run_mark_missed' ) );
        add_action( self::HOOK_TOPUP_DOSES,    array( __CLASS__, 'run_topup_doses' ) );
        add_action( self::HOOK_CLEANUP,        array( __CLASS__, 'run_cleanup' ) );
    }

    public static function schedule_events() {
        if ( ! wp_next_scheduled( self::HOOK_SEND_REMINDERS ) ) {
            wp_schedule_event( time(), 'every_5_minutes', self::HOOK_SEND_REMINDERS );
        }
        if ( ! wp_next_scheduled( self::HOOK_MARK_MISSED ) ) {
            wp_schedule_event( time(), 'every_15_minutes', self::HOOK_MARK_MISSED );
        }
        if ( ! wp_next_scheduled( self::HOOK_TOPUP_DOSES ) ) {
            // Schedule at next midnight Athens time (Europe/Athens = UTC+2 or UTC+3 DST).
            // This ensures doses for the new day are ready when users check the app at 00:00 local.
            $athens_tz   = new DateTimeZone( 'Europe/Athens' );
            $utc_tz      = new DateTimeZone( 'UTC' );
            $midnight     = new DateTime( 'tomorrow midnight', $athens_tz );
            $midnight_utc = $midnight->setTimezone( $utc_tz );
            wp_schedule_event( $midnight_utc->getTimestamp(), 'daily', self::HOOK_TOPUP_DOSES );
        }
        if ( ! wp_next_scheduled( self::HOOK_CLEANUP ) ) {
            wp_schedule_event( time(), 'weekly', self::HOOK_CLEANUP );
        }
        // Register custom intervals
        add_filter( 'cron_schedules', array( __CLASS__, 'add_cron_intervals' ) );
    }

    public static function deactivate() {
        foreach ( array(
            self::HOOK_SEND_REMINDERS,
            self::HOOK_MARK_MISSED,
            self::HOOK_TOPUP_DOSES,
            self::HOOK_CLEANUP,
        ) as $hook ) {
            $ts = wp_next_scheduled( $hook );
            if ( $ts ) {
                wp_unschedule_event( $ts, $hook );
            }
        }
    }

    public static function add_cron_intervals( $schedules ) {
        $schedules['every_5_minutes'] = array(
            'interval' => 300,
            'display'  => 'Every 5 Minutes',
        );
        $schedules['every_15_minutes'] = array(
            'interval' => 900,
            'display'  => 'Every 15 Minutes',
        );
        return $schedules;
    }

    // ─── JOB: SEND REMINDERS ─────────────────────────────────────────────────

    /**
     * Main notification dispatch job.
     * Runs every 5 minutes.
     *
     * Finds doses due within the next REMINDER_LEAD_MINUTES minutes,
     * claims them atomically, sends push via OneSignal.
     */
    public static function run_send_reminders() {
        $start_time = microtime( true );
        $log_id     = self::log_start( 'send_reminders' );

        $utc_tz     = new DateTimeZone( 'UTC' );
        $now        = new DateTime( 'now', $utc_tz );
        $window_end = clone $now;
        $window_end->modify( '+' . self::REMINDER_LEAD_MINUTES . ' minutes' );

        // Window: from 5 min ago (catch any we missed) to +LEAD_MINUTES
        $window_start = clone $now;
        $window_start->modify( '-5 minutes' );

        $doses = AME_Doses::get_pending_in_window( $window_start, $window_end );

        $sent   = 0;
        $failed = 0;

        foreach ( $doses as $dose ) {
            // Atomic claim — prevents duplicate sends
            if ( ! AME_Doses::claim_for_sending( $dose->id ) ) {
                continue; // Already claimed by another process
            }

            $result = AME_OneSignal::send_dose_reminder( $dose );

            if ( $result && isset( $result['id'] ) ) {
                AME_Doses::mark_reminder_sent( $dose->id, $result['id'], $result );
                self::log_notification( $dose, 'sent', $result['id'] );
                $sent++;
            } else {
                $error = isset( $result['errors'] ) ? implode( ', ', (array) $result['errors'] ) : 'Unknown error';
                AME_Doses::mark_reminder_failed( $dose->id, $error );
                self::log_notification( $dose, 'failed', null, $error );
                $failed++;
            }
        }

        $elapsed = round( ( microtime( true ) - $start_time ) * 1000 );
        self::log_complete( $log_id, count( $doses ), $sent, $failed, $elapsed );
    }

    // ─── JOB: MARK MISSED ────────────────────────────────────────────────────

    /**
     * Mark overdue pending doses as missed.
     * Runs every 15 minutes.
     * A dose is missed if: status=pending AND due_at_utc + grace_window_minutes < NOW()
     */
    public static function run_mark_missed() {
        $log_id = self::log_start( 'mark_missed' );
        $count  = AME_Doses::mark_overdue_as_missed();
        self::log_complete( $log_id, $count, 0, 0, 0 );
    }

    // ─── JOB: TOP-UP DOSES ───────────────────────────────────────────────────

    /**
     * Generate doses for the next 30 days for all active medications.
     * Runs daily. Idempotent (INSERT IGNORE).
     */
    public static function run_topup_doses() {
        $log_id = self::log_start( 'topup_doses' );
        $count  = AME_DoseGenerator::regenerate_all( 30 );
        self::log_complete( $log_id, $count, 0, 0, 0 );
    }

    // ─── JOB: CLEANUP ────────────────────────────────────────────────────────

    /**
     * Remove old cancelled/failed/pending doses older than 90 days.
     * Runs weekly.
     */
    public static function run_cleanup() {
        $log_id = self::log_start( 'cleanup' );
        $count  = AME_Doses::cleanup_old( 90 );
        self::log_complete( $log_id, $count, 0, 0, 0 );
    }

    // ─── LOGGING ─────────────────────────────────────────────────────────────

    private static function log_start( $job_name ) {
        global $wpdb;
        $t = AME_Database::table( 'cron_log' );
        $wpdb->insert( $t, array(
            'job_name'   => $job_name,
            'status'     => 'started',
            'started_at' => current_time( 'mysql' ),
        ), array( '%s', '%s', '%s' ) );
        return $wpdb->insert_id;
    }

    private static function log_complete( $log_id, $checked, $sent, $failed, $elapsed_ms ) {
        global $wpdb;
        $t = AME_Database::table( 'cron_log' );
        $wpdb->update( $t, array(
            'status'               => 'completed',
            'doses_checked'        => $checked,
            'notifications_sent'   => $sent,
            'notifications_failed' => $failed,
            'execution_time_ms'    => $elapsed_ms,
            'completed_at'         => current_time( 'mysql' ),
        ), array( 'id' => $log_id ),
        array( '%s', '%d', '%d', '%d', '%d', '%s' ),
        array( '%d' ) );
    }

    private static function log_notification( $dose, $status, $onesignal_id = null, $error = null ) {
        global $wpdb;
        $t = AME_Database::table( 'notification_log' );
        $wpdb->insert( $t, array(
            'dose_id'                   => $dose->id,
            'user_id'                   => $dose->user_id,
            'medication_id'             => $dose->medication_id,
            'notification_type'         => 'dose_reminder',
            'channel'                   => 'push',
            'status'                    => $status,
            'title'                     => 'Υπενθύμιση Φαρμάκου',
            'message'                   => $dose->medication_name . ( $dose->dosage ? ' — ' . $dose->dosage : '' ),
            'onesignal_notification_id' => $onesignal_id,
            'error_message'             => $error,
            'sent_at'                   => $status === 'sent' ? current_time( 'mysql' ) : null,
            'created_at'                => current_time( 'mysql' ),
        ), array( '%d','%d','%d','%s','%s','%s','%s','%s','%s','%s','%s','%s' ) );
    }
}
